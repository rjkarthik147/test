<?php

namespace Commerceshop\Salesperson\Observer;

use Magento\Framework\Event\Observer as EventObserver;
use Magento\Framework\Event\ObserverInterface;

class SaveDataToOrderObserver implements ObserverInterface
{

protected  $_request;

public function __construct(
    \Magento\Framework\App\RequestInterface $request
) { 
    $this->_request = $request;
}

    public function execute(EventObserver $observer)
    {
    	$quote = $observer->getQuote();
        $order = $observer->getOrder();
        $salesperson = $this->_request->getPost('sales_person_key');
        $quote->setSalesPersonKey($salesperson);
        $order->setSalesPersonKey($salesperson);
        $quote->save();
        $order->save();
        return $this;
    }
}