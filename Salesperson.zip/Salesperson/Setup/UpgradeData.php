<?php


namespace Commerceshop\Salesperson\Setup;

use Magento\Framework\Setup\UpgradeDataInterface;
use Magento\Framework\Setup\ModuleContextInterface;
use Magento\Framework\Setup\ModuleDataSetupInterface;
use Magento\Quote\Setup\QuoteSetupFactory;
use Magento\Sales\Setup\SalesSetupFactory;


class UpgradeData implements UpgradeDataInterface
{

    protected $quoteSetupFactory;

    protected $salesSetupFactory;

    public function __construct(
        QuoteSetupFactory $quoteSetupFactory,
        SalesSetupFactory $salesSetupFactory
    ) {
        $this->quoteSetupFactory = $quoteSetupFactory;
        $this->salesSetupFactory = $salesSetupFactory;
    }
    /**
     * {@inheritdoc}
     */
    public function upgrade(
        ModuleDataSetupInterface $setup,
        ModuleContextInterface $context
    ) {

        $objectManager = \Magento\Framework\App\ObjectManager::getInstance(); // Instance of object manager
        $resource = $objectManager->get('Magento\Framework\App\ResourceConnection');
        $connection = $resource->getConnection();

        $sql = "ALTER TABLE `sales_order` add `sales_person_key` VARCHAR(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT 'ws' COMMENT 'Sales Person Key'";
        $connection->query($sql);

        $sql1 = "ALTER TABLE `quote` add `sales_person_key` VARCHAR(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT 'ws' COMMENT 'Sales Person Key'";
        $connection->query($sql1);

        $sql2 = "ALTER TABLE `sales_order_grid` add `sales_person_key` VARCHAR(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT 'ws' COMMENT 'Sales Person Key'";
        $connection->query($sql2);
        // $quoteInstaller = $this->quoteSetupFactory->create(['resourceName' => 'quote_setup', 'setup' => $setup]);

        // $salesInstaller = $this->salesSetupFactory->create(['resourceName' => 'sales_setup', 'setup' => $setup]);

        // $setup->startSetup();

        //     $quoteInstaller->addAttribute('quote', 'sales_person_key', ['type' => 'varchar', 'NOT NULL','nullable'=>false,'length'=> 255, 'default' => 'ws','visible' => false]);
        //      $salesInstaller->addAttribute('order', 'sales_person_key', ['type' => 'varchar', 'NOT NULL','nullable'=>false,'length'=> 255, 'default' => 'ws','visible' => false]);
        //           $setup->endSetup();
    }
}


