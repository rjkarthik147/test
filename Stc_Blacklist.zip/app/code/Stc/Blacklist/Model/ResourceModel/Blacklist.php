<?php
namespace Stc\Blacklist\Model\ResourceModel;

class Blacklist extends \Magento\Framework\Model\ResourceModel\Db\AbstractDb
{
    /**
     * Initialize resource model
     *
     * @return void
     */
    protected function _construct()
    {
        $this->_init('customer_blacklist', 'id');
    }
}
?>