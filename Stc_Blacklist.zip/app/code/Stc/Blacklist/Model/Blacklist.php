<?php
namespace Stc\Blacklist\Model;

class Blacklist extends \Magento\Framework\Model\AbstractModel
{
    /**
     * Initialize resource model
     *
     * @return void
     */
    protected function _construct()
    {
        $this->_init('Stc\Blacklist\Model\ResourceModel\Blacklist');
    }
}
?>