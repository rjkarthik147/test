<?php

namespace Ziffity\BulkProcurement\Helper;

class Data extends \Magento\Framework\App\Helper\AbstractHelper
{
    const CURRENT_BULK_PROCUREMENT         = 'current_bulk_procurement';
    const PROCUREMENT_DRAFT                = 0;
    const PROCUREMENT_NEW                  = 1;
    const PROCUREMENT_PICK_PROCESSING      = 2;
    const PROCUREMENT_PRODUCT_ARRIVED      = 3;
    const PROCUREMENT_MOVED_TO_PROCUREMENT = 4;
    
    public static $procuremetStatus  = [['value' => self::PROCUREMENT_NEW, 'label' => 'New'],
        ['value' => self::PROCUREMENT_PICK_PROCESSING, 'label' => 'Processing for Pickup'],
        ['value' => self::PROCUREMENT_PRODUCT_ARRIVED, 'label' => 'Product arrived'],
        ['value' => self::PROCUREMENT_MOVED_TO_PROCUREMENT, 'label' => 'Moved to Procurement']];

    /* For frontend */
    const CONSIGNED_TYPE_OWNED             = 3;
    const CONSIGNED_TYPE_CONSIGN           = 1;
    const CONSIGNED_TYPE_DONATE            = 2;
    /* Schedule Status Flag */
    const SCHEDULED_FALSE = 0;
    const SCHEDULED_TRUE = 1;
    /* Default Number of items */
    const NUMBEROFITEM_DEFAULT = 0;
    protected $session;
    public function __construct(
        \Magento\Catalog\Model\Session $session 
    ) {
        $this->session = $session;
    }
    /* To get bulk product count for a customer */
    public function getActiveProductCount() {
        return ( $this->session->getActiveBulkProducts() !=0 ) ? $this->session->getActiveBulkProducts() : 0 ;
    }
    
    public function setActiveProductCount( $count ) {
        $this->session->setActiveBulkProducts( $count );
    }
}