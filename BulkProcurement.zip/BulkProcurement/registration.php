<?php 
\Magento\Framework\Component\ComponentRegistrar::register(
   \Magento\Framework\Component\ComponentRegistrar::MODULE,
   'Ziffity_BulkProcurement',
   __DIR__
);