
define(['ko','Magento_Ui/js/modal/alert','mage/translate'], function (ko,alert,_) {
    'use strict';
    return {
        init: function (obj, conditions, prices,procurementTypes) {
            this.conditions = conditions;
            this.prices = prices;
            this.procurementTypes=procurementTypes;
            this.itemId = obj.itemId;
            this.name = obj.name;
            this.sku = obj.sku;
            this.image=obj.imageUrl;
            this.selectedCode = ko.observable(obj.selectedCode);
            this.selectedTypeInitial = ko.observable(obj.selectedType);
            this.selectedSize = ko.observable(obj.selectedSize);
            this.selectedQuality = ko.observable(obj.selectedQuality);
            this.qty = ko.observable(obj.qty);
             var self = this;
            this.isBrand = ko.observable(obj.isBrand);
         
            this.isRecommanedPriceOverride = ko.observable(obj.isRecommanedPriceOverride);
            this.overriddenRecommendedPrice = ko.observable(obj.overriddenRecommendedPrice);
            this.recommanedPrice = ko.observable(obj.recommanedPrice);
            this.isRetailPriceOverride = ko.observable(obj.isRetailPriceOverride);
            this.overriddenRetailPrice = ko.observable(obj.overriddenRetailPrice);
            this.retailPrice = ko.observable(obj.retailPrice);
            if(this.recommanedPrice()<1)
             this.isRecommanedPriceOverrideEnable=ko.observable(0);
         else
             this.isRecommanedPriceOverrideEnable=ko.observable(1);
          if(this.retailPrice()<1)
            this.isRetailPriceOverrideEnable=ko.observable(0);
        else
            this.isRetailPriceOverrideEnable=ko.observable(1);
            
            this.sellIndividually = obj.sellIndividually;
            this.sellingRetailPrice = ko.computed(this.getSellingRetailPrice.bind(this));
            this.IMU = ko.computed(this.getIMU.bind(this));
            this.MMU = ko.computed(this.getMMU.bind(this));
            this.bulkprocurementTypes = ko.computed(this.getBulkprocurementTypes.bind(this));
            this.selectedType = ko.computed({read:this.getSelectedType.bind(this),write: function (value) { self.selectedTypeInitial(value); return  2;}});

        },
        
        getBulkprocurementTypes: function () {

            var ownedTypes = this.procurementTypes.filter(function (obj) {
                if (obj.value == 3)
                    return obj;
            });
            var consignedTypes = this.procurementTypes.filter(function (obj) {
                if (obj.value != 3)
                    return obj;
            });
            if (this.selectedTypeInitial() == 3)
                return ownedTypes;
            else
                return consignedTypes;
        },
        
        getMMU: function () {
            var recommanedPrice = 0;
            if (this.isRecommanedPriceOverride()==1) {
                recommanedPrice = this.overriddenRecommendedPrice();

            } else {
                recommanedPrice = this.recommanedPrice();
            }

            return Math.round(((this.sellingRetailPrice()  - recommanedPrice)/this.sellingRetailPrice())*100) + "%";

        },
        getIMU: function () {

            var recommanedPrice = 0;
            if (this.isRecommanedPriceOverride()==1) {
                recommanedPrice = this.overriddenRecommendedPrice();

            } else {
                recommanedPrice = this.recommanedPrice();
            }
           var retailPrice = 0;
            if (this.isRetailPriceOverride()==1) {
                retailPrice = this.overriddenRetailPrice();

            } else {
                retailPrice = this.retailPrice();
            }

            return Math.round(((retailPrice  - recommanedPrice)/retailPrice) *100) + "%";

        },

        getSelectedType: function () {

            var recommanedPrice = 0;
            var selectedtype=this.selectedTypeInitial();
            if (this.isRecommanedPriceOverride()==1) {
                recommanedPrice = this.overriddenRecommendedPrice();

            } else {
                recommanedPrice = this.recommanedPrice();
            }
         
           
                 if(this.selectedTypeInitial()==1 && recommanedPrice<150)
            {
                     alert({
                    content: _('Items less than 150 cannot be consigned')
                   
                });
                this.selectedTypeInitial(2);
               return 2;
            } 
            return selectedtype;
        },
        
             getSellingRetailPrice: function () {

            var retailPrice = 0;
            if (this.isRetailPriceOverride()==1) {
                retailPrice = this.overriddenRetailPrice();

            } else {
                retailPrice = this.retailPrice();
            }
           
            return Math.round(retailPrice * 0.68);

        },   
        
        calculateOverPrice:function(){
             if(this.selectedType()==1 && this.isRecommanedPriceOverride()==1){
                   this.retailPrice(this.overriddenRecommendedPrice());
            }
             if(this.selectedType()==2 && this.isRecommanedPriceOverride()==1){
                   this.retailPrice(this.overriddenRecommendedPrice()*35/100);
            }
        },
        
       calculatePrice:function(){
           console.log("asdasd");
             var self = this;
             var retailCondition=null;
             var retailBasePrice=null;
             var basPrice =null;
               var condition =null;
             
               
              this.conditions.each(function (obj) {

            if (obj.quality == self.selectedQuality() && obj.type == 1 && obj.is_brand == self.isBrand())
                    retailCondition=obj;
                if (obj.quality == self.selectedQuality() && obj.type == self.selectedType() && obj.is_brand == self.isBrand()){
                    condition=obj;
                      
                }
            });

             this.prices.each(function (obj) {
                 
                   if (obj.category_id == self.selectedCode() && obj.type == 1 && obj.is_brand == self.isBrand() && obj.size == self.selectedSize())
                    retailBasePrice= obj;
                 
                if (obj.category_id == self.selectedCode() && obj.type == self.selectedType() && obj.is_brand == self.isBrand() && obj.size == self.selectedSize()){
                    basPrice=obj;
                    
                }
            });
            var retialValue=0;
               if(basPrice && condition){
               
                 retialValue =Math.round((basPrice.procurement_selling_price) * (condition.selling_price_percent));
             }
             
             
     if(retialValue<=1){
 
            self.isRetailPriceOverride(1);
            if(self.overriddenRetailPrice()<1)
            self.overriddenRetailPrice(null);
            self.retailPrice(null);
            self.isRetailPriceOverrideEnable(0);
      }
       else{
             self.isRetailPriceOverride(0); 
               self.retailPrice(retialValue* self.qty());
             self.isRetailPriceOverrideEnable(1);
         }
             

                 var recommanedValue=0;
               if(retailCondition && retailBasePrice){
             
                 recommanedValue =Math.round((retailBasePrice.procurement_selling_price) * (retailCondition.selling_price_percent));
             }
             
         if(recommanedValue<1){
            self.recommanedPrice(null);
           self.isRecommanedPriceOverride(1);
           if(self.overriddenRecommendedPrice()<1)
            self.overriddenRecommendedPrice(null);
           self.isRecommanedPriceOverrideEnable(0);
        }
        else{
           self.isRecommanedPriceOverride(0);  
           self.recommanedPrice(recommanedValue* self.qty());
          self.isRecommanedPriceOverrideEnable(1);
        }
        
         
 
        },
        

        getRecommanedPrice: function () {
            var self = this;

            var condition = this.conditions.find(function (obj) {

                if (obj.quality == self.selectedQuality() && obj.type == self.selectedTypeInitial() && obj.is_brand == self.isBrand())
                    return obj;
            });

            var basPrice = this.prices.find(function (obj) {
                if (obj.category_id == self.selectedCode() && obj.type == self.selectedTypeInitial() && obj.is_brand == self.isBrand() && obj.size == self.selectedSize())
                    return obj;
            });
            var amt=0;
              if(basPrice && condition){
             amt=Math.round((basPrice.procurement_selling_price) * (condition.selling_price_percent) )* self.qty();
         }
         if(amt==0){
             amt=null;
           self.isRecommanedPriceOverride(1);
           if(self.overriddenRecommendedPrice()<1)
            self.overriddenRecommendedPrice(null);
           self.isRecommanedPriceOverrideEnable(0);
        }
        else{
           self.isRecommanedPriceOverride(0);  
          self.isRecommanedPriceOverrideEnable(1);
        }
            return amt;
        },
        getRetailPrice: function () {
            var self = this;

            var condition = this.conditions.find(function (obj) {

                if (obj.quality == self.selectedQuality() && obj.type == 1 && obj.is_brand == self.isBrand())
                    return obj;
            });

            var basPrice = this.prices.find(function (obj) {
                if (obj.category_id == self.selectedCode() && obj.type == 1 && obj.is_brand == self.isBrand() && obj.size == self.selectedSize())
                    return obj;
            });
            var amt=0;
             if(basPrice && condition){
                amt= Math.round((basPrice.procurement_selling_price) * (condition.selling_price_percent))* self.qty();
            }
             if(amt==0){
                 amt=null;
            self.isRetailPriceOverride(1);
            if(self.overriddenRetailPrice()<1)
            self.overriddenRetailPrice(null);

            self.isRetailPriceOverrideEnable(0);
      }
       else{
             self.isRetailPriceOverride(0); 
             self.isRetailPriceOverrideEnable(1);
         }
      return amt;
        }
    };
}
);


 