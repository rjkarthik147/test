define(['jquery', 'ko', 'uiComponent', 'Ziffity_BulkProcurement/js/procurementitem'], function ($, ko, Component, procurementitem) {

    return Component.extend({
        initialize: function () {
            this._super();
            this.productCodes = ko.observableArray(this.productCodeOptions);
            this.size = ko.observableArray(this.sizeOptions);
            this.quality = ko.observableArray(this.qualityOptions);
            this.brand = ko.observableArray(this.brandOptions);
            this.yesNo = ko.observableArray(this.yesNoOptions);
            this.isSpinnerVisible = true;
            this.itemCollection = ko.observableArray(this.getItemCollection());
            this.ownedItemPrice = ko.computed(this.getOwnedItemPrice.bind(this));
            this.ownedItemGM = ko.computed(this.getOwnedItemGM.bind(this));
            this.hasOwnedItem=false;


        },
        getItemCollection: function () {
            var self = this;

            var items = this.procurementItems.map(function (obj) {
                var newObject = jQuery.extend({}, procurementitem);
                //console.log(self.procurementConditions);
                newObject.init(obj, self.procurementConditions, self.procurementPrices, self.bulkprocurementTypes);
                return newObject;
            });
            return items;
        }
        ,

        getOwnedItemPrice: function () {
            var amt = 0;
            var self=this;
            this.itemCollection().forEach(function (obj) {
                if (obj.selectedType() == 3) {
                self.hasOwnedItem=true;
                    if (obj.isRecommanedPriceOverride() == 1) {
                        amt = amt + Number(obj.overriddenRecommendedPrice());

                    } else {
                        amt = amt + Number(obj.recommanedPrice());
                    }

                }
            });
            return Math.round(amt);
        }

        ,

        getOwnedItemGM: function () {
            var totalrecommanedPrice = this.ownedItemPrice();
            var sellingRetailPrice = this.getSellingRetailPrice.call(this);
            return Math.round(((sellingRetailPrice - totalrecommanedPrice) / sellingRetailPrice) * 100) + "%";

        },

        getSellingRetailPrice: function () {

            var amt = 0;
            this.itemCollection().forEach(function (obj) {
                if (obj.selectedType() == 3) {

                    if (obj.isRetailPriceOverride() == 1) {
                        amt = amt + Number(obj.overriddenRetailPrice());

                    } else {
                        amt = amt + Number(obj.retailPrice());
                    }

                }
            });
          
            return Math.round(amt * 0.68);


        },

    });
});