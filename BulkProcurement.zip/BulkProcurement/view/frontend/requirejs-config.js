var config = {
    paths: {
            'timpicker' : 'Ziffity_BulkProcurement/js/wickedpicker',
             'selectize': 'Ziffity_BulkProcurement/js/selectize',
             'jquery-autocomplete' : 'Ziffity_Procurement/js/jquery-auto'
    },
    shim: {
        'selectize': {
            deps: ['jquery'],
            exports: 'Selectize'
        },
        'jquery-autocomplete': {
            deps: ['jquery']
        },
         'timpicker': {
            deps: ['jquery']
        }
    }
};

