/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */



define([
'jquery', 
'mage/validation',
'mage/translate',
'jquery/ui',
'timpicker',
'selectize'
],
function($){
    return function(values) {
    window.isPriceUpdateNeed = 0;    
    /*quantity*/
    var quantitiy = 1;
    
    $('.quantity-right-plus').click(function(e){
    e.preventDefault();
    var quantity = parseInt($(this).parent().parent().find('input').val());
    if(quantity < 100){
        ( $("#price_regular").val() ? ( $("#price_regular").val( window.regularPrice * (quantity + 1))) :'' );
        ( $("#retail_price").val() ? ( $("#retail_price").val( window.consignPrice * (quantity + 1))) :'' );
        $(this).parent().parent().find('input').val(quantity + 1);
    }
    });
    $('.quantity-left-minus').click(function(e){
    e.preventDefault();
    var quantity = parseInt($(this).parent().parent().find('input').val());
    if(quantity > 1){
        ($("#price_regular").val() ? ( $("#price_regular").val( window.regularPrice * (quantity - 1))) :'' );
        ( $("#retail_price").val() ? ( $("#retail_price").val( window.consignPrice * (quantity - 1))) :'' );
    $(this).parent().parent().find('input').val(quantity - 1);
    }
    });
    /*imagepload*/
    /*$('.imageupload').click(function(){
        $('#prev_img').css('opacity','1');
    });*/

    
    /*popup*/
    $('[data-popup-open]').on('click', function(e)  {
        $("#popup_product")[0].reset();
        window.category[0].selectize.clear();
        popupOpen(e,this);
    });
    
    function popupOpen(e,a){
         $('.alert-danger').hide();
        $('.category-validation.mage-error').remove();
        if($('div.mage-error').length > 0){
             $('div.mage-error').hide();
        }
        var targeted_popup_class = jQuery(a).attr('data-popup-open');
        if( jQuery(a).attr('class') == 'center_section' ) {
            $('.owned_option').hide();
            $("input.switch-input").attr('value', '0');
            $('#popup_product input[type="radio"]').attr("checked",false);
            $("#popup_product label").removeClass("checked");
            $('.switch').removeClass('togglecircle right');
            $('input#over_retail, input#over_regular').attr('readonly', true).removeClass('required-entry validate-my-value mage-error');
            $('.inner_bulk_main').addClass(' disabled').css({'opacity':'0.3'});
            /*$('label.switch .switch-input').val('0');
            $('.switch').find(".add-readonly").attr('readonly', true).removeClass('required-entry');
            $('#over_regular, #over_retail').attr("readonly", true).removeClass('required-entry');
            $(".inner_bulk_main").load(location.href+" .inner_bulk_main");*/
            $("#prev_img").attr( "src", "" );
            window.autoGenerateSku = Math.floor(Math.random() * 90000) + 10000; 
            window.activeItem = 0;
            window.activeEditMode = '';
            window.attributeSetId = ''; 
            window.brand = '';
            window.quality = '';
            window.size = '';
            window.consigntype = '';

            $(".switch").toggle(function() {
    $(this).addClass('togglecircle');
    $(this).find(".switch-input").attr('value', '1'); 
    $(this).parent().parent().find(".add-readonly").attr('readonly', false);
    $(this).parent().parent().find(".add-readonly").addClass('required-entry validate-my-value');
    grandTotal();
    $("#over_regular,#over_retail").on('change', function(){
        grandTotal();
    });
    }, function() {
    $(this).removeClass('togglecircle');
    $(this).find(".switch-input").attr('value', '0'); 
    $(this).parent().parent().find(".add-readonly").attr('readonly', true);
    $(this).parent().parent().find(".add-readonly").removeClass('required-entry validate-my-value mage-error');
    grandTotal();
    $("#over_regular,#over_retail").on('change', function(){
        grandTotal();
    });
    });


            
        }
        if( jQuery(a).attr('class') == 'remove' ) {
            window.activeItem = 0;
            window.activeEditMode = 0;
            var updateProductId = jQuery("input."+jQuery(a).attr('id')).val();
            if( updateProductId !== 0) {
                window.activeItem = updateProductId;
                window.activeEditMode =  jQuery(a).attr('class');
            }
        }
        if( jQuery(a).attr('class') == 'edit' ) { 
            $('.inner_bulk_main').removeClass(' disabled').css({'opacity':'1'});
            window.activeItem = 0;
            window.activeEditMode = 0;
            window.isPriceUpdateNeed = 0;
            var updateProductId = jQuery("input."+jQuery(a).attr('id')).val(); 
            if( updateProductId !== 0) {
                window.activeItem = updateProductId;
                window.activeEditMode =  jQuery(a).attr('class');
                updateProduct( window.activeItem, window.activeEditMode );
            }
        }

        $('[data-popup="' + targeted_popup_class + '"]').fadeIn(350);
        e.preventDefault();
    }
    jQuery("#deleteConfirmation").on("click",function(){
        if( window.activeItem !== 0 ) {
            updateProduct( window.activeItem, window.activeEditMode );
        }
    }); 
 function updateProduct( itemId, flag ) {
        jQuery.ajax({
            type:'POST',
            url: values.baseurl + 'procurement/bulkprocurement/updateitem',
            data:{
                'item' : itemId,
                'flag' : flag
            },
            dataType: 'json',
            showLoader: true,
            success:function(data){
                jQuery(".page.messages").html( data['messages'] ).show().delay(5000).fadeOut('slow');
                if( data['is_login'] == 0) {
                    window.setLocation(values.baseurl + 'procure/salesaccount/login');
                }
                if( data['is_edit'] == 1 ) {
                    window.consigntype = data['type_id'];
                    $('#is_edit').val(1);
                    $('.product_code').val( data['sku'] );
                    if( data['type_id'] == 1 ) {
                        $("#radio2").attr('checked',true).next('label').addClass('checked');
                         $('.owned_option').hide(); 
                    } else if( data['type_id'] == 2 ) {
                        $("#radio3").attr('checked',true).next('label').addClass('checked');
                        $('.owned_option').hide();
                    } else if( data['type_id'] == 3 ) {
                        $("#radio1").attr('checked',true).next('label').addClass('checked');
                         $('.owned_option').show(); 
                    }
                    $('.product_code').val( data['sku'] );
                    //$(".price-attr-consigntype").val( data['type_id'] );
                    $("#product_name").val( data['product_name'] );
                    $("#category").val( data['category_id'] );
                    window.attributeSetId = data['category_id'];
                    window.category[0].selectize.clear();
                    window.category[0].selectize.setValue(data['category_id']);
                    //$(".price-attr-brand").val( data['is_brand'] );
                    window.brand = data['is_brand'];
                    if( data['is_brand'] == 1) {
                        $("#brand-p1-1").attr('checked',true).next('label').addClass('checked');
                    } else {
                        $("#brand-p1-2").attr('checked',true).next('label').addClass('checked');
                    }
                    
                    //$(".price-attr-quality").val( data['procurement_quality_id'] );
                    window.quality = data['procurement_quality_id'];
                    if( data['procurement_quality_id'] == 1 ) {
                        $("#qty-p1-1").attr('checked',true).next('label').addClass('checked');
                    } else if (data['procurement_quality_id'] == 2 ) {
                        $("#qty-p1-2").attr('checked',true).next('label').addClass('checked');
                    } else if (data['procurement_quality_id'] == 3 ) {
                        $("#qty-p1-3").attr('checked',true).next('label').addClass('checked');
                    }
                    
                    //$(".price-attr-size").val( data['procurement_size_id'] );
                    window.size = data['procurement_size_id'];
                    if( data['procurement_size_id'] == 1 ) {
                        $("#size-p1-1").attr('checked',true).next('label').addClass('checked').trigger('click');
                    } else if (data['procurement_size_id'] == 2 ) {
                        $("#size-p1-2").attr('checked',true).next('label').addClass('checked').trigger('click');
                    } else if (data['procurement_size_id'] == 3 ) {
                        $("#size-p1-3").attr('checked',true).next('label').addClass('checked').trigger('click');
                    }
                    $("#quantity").val( data['qty'] );
                    if( parseInt(data['overridden_recommended_price']) > 0 ) {
                        $("#over_regular").attr("readonly", false).val( data['overridden_recommended_price'] );
                        $("label.switch.left").addClass("togglecircle");
                        $("input.switch-input.left").val(1);
                    } else {
                        $("#over_regular").attr("readonly", true);
                        $("label.switch.left").removeClass("togglecircle");
                        $("input.switch-input.left").val(0);
                    }           
                    if( parseInt(data['recommended_price']) == 0 ) {
                        $("label.switch.left").addClass(" disable-switch");
                    } else {
                        $("label.switch.left").removeClass(" disable-switch");
                    }
                    ( data['recommended_price'] > 0 ) ? $("#price_regular").val( data['recommended_price'] ) : $("#price_regular").val('');
                    
                    if( parseInt(data['overridden_retail_price']) > 0 ) {
                        $("#over_retail").attr("readonly", false).val( data['overridden_retail_price'] );
                        $("label.switch.over-right").addClass("togglecircle");
                        $("input.switch-input.right").val(1);
                    } else {
                        $("#over_retail").attr("readonly", true);
                        $("label.switch.over-right").removeClass("togglecircle");
                        $("input.switch-input.right").val(0);
                    }
                    if( parseInt(data['retail_price']) == 0 ) {
                        $("label.switch.over-right").addClass(" disable-switch");
                    } else {
                        $("label.switch.over-right").removeClass(" disable-switch");
                    }
                    ( data['retail_price'] > 0 ) ? $("#retail_price").val( data['retail_price'] ) : $("#retail_price").val('') ;
                    $("#comments").val( data['comments'] );
                    if( data['image'] != null ) {
                        $("#prev_img").attr( "src", data['image_path'] ).css('opacity','1');
                    }
                    //getPriceAttributes();
                    //popupOpen(e, this);
                } else {
                    $('#is_edit').val(0);
                    $('[data-popup-close]').trigger("click");
                    $('.product_list').css({'display': 'block', 'opacity': '1'});
                    
                }
         
                $('.product_list_content').html('');
                $('.product_list_content').html(data['products']); 
                $(".final_listing").html(data['overall']); 
                if( data['product_count'] > 0 ) {
                    jQuery(".product_list_content").html( data['products'] ).show();
                    jQuery(".product_select").css({'display': 'none', 'opacity': '0'});
                    jQuery(".final_listing").html(data['overall']); 
                    jQuery("span.view_list, button.next_button").removeClass("disabled");
                } else {
                    jQuery(".product_list_content").hide();
                    jQuery(".product_select").css({'display': 'block', 'opacity': '1'});
                    jQuery("span.view_list, button.next_button").addClass("disabled"); 
                }

                $('[data-popup-open]').on('click', function (e) {
                    $('#popup_product')[0].reset();
                    window.category[0].selectize.clear();
                    $('.radio-toolbar label').removeClass('checked');
                    $('#prev_img').css('opacity','0');
                    $('.imageupload').removeClass('remove-pseudo');
                    popupOpen(e, this);
                });
                taxType();
                grandTotal();
            },
            error: function(data){
                console.log("error");
                console.log(data);
            }
        });
    }
    jQuery('input[name="consigntype"]').on('change',function(){
        var consignType = jQuery(this).val();
        var customerRefercnce;
        window.customerId= $("#customer_id").val();
        console.log("wdsjwf"+window.customerId);
        var diffZeros = 5-window.customerId.length;
        var iteration = 1;
        var carryZero = '';
        for( iteration; iteration <= diffZeros ; iteration++){
            carryZero += "0";
        }
        customerRefercnce = carryZero + window.customerId;
        var prefix = '';
        if( consignType == 3 ) 
            prefix = '3'; 
        if ( consignType == 1 ) {
            prefix = "1"; 
        }  else if (consignType == 2) {
            prefix = "2"; 
        }
        if( consignType ) {
            var beforeCheckDigit = prefix+ customerRefercnce + window.autoGenerateSku;
            var lastdigit = checkDigit(beforeCheckDigit);
            
            jQuery("input.product_code").val(beforeCheckDigit + lastdigit);
        }
    }); 
    function checkDigit(val){ 
        var odd=0;
        var even=0; 
        for(var i=0;i<val.length;i++){
                if ((i % 2) != 1) {            
                odd += parseInt(val[i]);        
            } else {
                even += parseInt(val[i]) ;        
            }
        }
        var mulOdd= 3*odd;
        var tworesult=mulOdd+even;
        var cal=tworesult % 10;
        if( (cal) != 0 ){
                var out=10-cal ;
        } else {
                var out = 0 ;
        }
        return out;
    }
    jQuery(".print_label").on("click", function(){
        var mywindow = window.open('', '','height=600,width=600');
        mywindow.document.write('<html><head>');
       
        mywindow.document.write('</head><body >');
        mywindow.document.write("Sku "+$(".product_code").val()+"<br/>");
        mywindow.document.write("Product name "+$("#product_name").val()+"<br>");
        if( jQuery("#comments").val().length > 0 ) {
            mywindow.document.write("Special Instruction "+$("#comments").val());
        }
        mywindow.document.write('</body></html>');

        mywindow.print();
        mywindow.close();

        return true;
    });

    $('[data-popup-close]').on('click', function(e)  {
    var targeted_popup_class = jQuery(this).attr('data-popup-close');
    $('[data-popup="' + targeted_popup_class + '"]').fadeOut(350);
    e.preventDefault();
    });
    window.onkeydown = function( event ) {
        if ( event.keyCode == 27 ) {
            $('.bulkprocurement-bulkprocurement-index .popup').fadeOut(350);
            $('.bulkprocurement-bulkprocurement-index .message.warning').fadeOut(350);
            $('.bulkprocurement-bulkprocurement-index .message-success').fadeOut(350);
            $('.messages.submit_success_main').fadeOut(350);
        }
    };
    /*date seperator*/
    //$('#time_from').timepicker();
    //$('#time_to').timepicker();

        $('.timepicker').wickedpicker({
                twentyFour: false, 
                title:'My Timepicker', 
                showSeconds: false,
                clearable: false
            });

        $('.wickedpicker').bind('contextmenu', function(e) {
            return false;
        }); 
        $('.datepicker_input').click(function(){
            $('.date_placeholder').addClass('hide_now');
        });
        $('#from_time').click(function(){
            $('.from_placeholder').addClass('hide_now');
        });
        $('#to_time').click(function(){
            $('.to_placeholder').addClass('hide_now');
        });
        
    $( function() {
    var today = new Date();
    $( "#datepicker" ).datepicker({
        minDate: today
    }
    );

  } );
    /*checkbox*/
    $('.pickup_check').on('click', function()  {
        $(this).find('label').toggleClass('add_tick');
        $('.pref_date input').toggleClass('disabled required-entry');
        $('.pref_time input').toggleClass('disabled required-entry');
        $(this).find('.regular-checkbox').toggleClass('required-entry');
        $(".pref_date input").val("");
        $('.pref_time input').val("");
        $("#from_time, #to_time").attr("value",'');
        $('.hide_now').removeClass('hide_now');
        /*if ($(this).find('.regular-checkbox').attr('value','0')) {
                $(this).find('.regular-checkbox').attr('value','1');
            } else {
                $(this).find('.regular-checkbox').attr('value','0');
            }*/
            if($(this).find('.regular-checkbox').hasClass('disabled')){
                        $(this).find('.regular-checkbox').attr('value','1'); 
                        $("#is_pick_required").val(1);
                    } else {
                        $(this).find('.regular-checkbox').attr('value','0');
                        $("#is_pick_required").val(0);
                    }
    });
    /*print*/
    $("button.print").on("click",function () {
         window.print();
         return true;
    });
    /*override*/
    /*$('.switch').live('click', function(){*/
    $(".switch").toggle(function() {
    $(this).addClass('togglecircle');
    $(this).find(".switch-input").attr('value', '1');
    $(this).parent().parent().find(".add-readonly").attr('readonly', false);
    $(this).parent().parent().find(".add-readonly").addClass('required-entry validate-my-value');
    grandTotal();
    $("#over_regular,#over_retail").on('change', function(){
        grandTotal();
    });
    }, function() {
    $(this).removeClass('togglecircle');
    $(this).find(".switch-input").attr('value', '0');
    $(this).parent().parent().find(".add-readonly").attr('readonly', true);
    $(this).parent().parent().find(".add-readonly").removeClass('required-entry validate-my-value');
    grandTotal();
    $("#over_regular,#over_retail").on('change', function(){
        grandTotal();
    });
    });
    /*});*/
    function grandTotal() {
        var regularPrice;
        if( $(".switch-input.left").val() == 0 ) {
            regularPrice = $("#price_regular").val();
        } else {
            regularPrice = $("#over_regular").val();
        }
        var retailPrice;
        if( $(".switch-input.right").val() == 0 ) {
            retailPrice = $("#retail_price").val();
        } else {
            retailPrice = $("#over_retail").val();
        }
        if( retailPrice && regularPrice ) {
            var imu;
            imu = ((retailPrice - regularPrice) / retailPrice) * 100;
            $("#imu-percentage").val( Math.round( imu.toFixed(2) ) + "%");
            var d5;
            d5 = retailPrice * 0.68;
            var gm;
            gm = ((d5 - regularPrice) / d5 ) * 100;
            $("#mmu-percentage").val( Math.round(gm.toFixed(2)) + "%" );
        }
    }
    /*checked label*/
    $('.product_add_popup .radio-toolbar label').click(function() {
    $(this).addClass('checked');
    if($(this).hasClass('one')){
       $('.owned_option').show(); 
    }
    else if($(this).hasClass('two') || $(this).hasClass('three')){
        $('.owned_option').hide(); 
    }
    else{
         
    }
    $(this).parent().find('label').not($(this)).removeClass('checked');
    });
   $('.indicator_bar .view_list').click(function() {
    $(this).parent().find('.bar').addClass('full');
    $('.product_select').css('left','-100%');
    $('.product_list').css('left','-100%');
    $('.final_listing').css('left','0%');
    $('.prev_button').css('display','inline');
    $('.submit_button').css('display','inline');
    $('.next_button').css('display','none');
});
$('.indicator_bar .add_probk').click(function() {
    $(this).parent().find('.bar').removeClass('full');
    $('.product_select').css('left','0%');
    $('.product_list').css('left','0%');
    $('.final_listing').css('left','100%');
    $('.prev_button').css('display','none');
    $('.submit_button').css('display','none');
    $('.next_button').css('display','inline');
});

    $('.next_button').click(function() {
        /*$(this).attr('data-popup-open', 'popup-3');
        $(this).removeClass('next_button');
        $(this).addClass('next_button_temp');*/
        $(this).css('display','none');
        $(this).parent().find('.submit_button').css('display','inline');
        $('.product_select').css('left','-100%');
        $('.product_list').css('left','-100%');
        $('.final_listing').css('left','0%');
        $('.prev_button').css('display','inline');
        $('.indicator_bar .bar').addClass('full');
    });

    $('.prev_button').click(function() {
        /*$(this).parent().find('.next_button_temp').removeAttr('data-popup-open', 'popup-3');        
        $(this).parent().find('.next_button_temp').removeClass('next_button_temp');*/
        /* $(this).parent().find('#final_submit').addClass('next_button');*/
        $(this).parent().find('.next_button').css('display','inline');
        $(this).parent().find('.submit_button').css('display','none');
        $('.product_select').css('left','0%');
        $('.product_list').css('left','0%');
        $('.final_listing').css('left','100%');
        $('.prev_button').css('display','none');
        $('.indicator_bar .bar').removeClass('full');
    });
    $('#popup_product').on("submit",function(event) {
        event.preventDefault();       
                /*
                var is_img = $('#prev_img').attr('src') != "" ? true : false;
                console.log(is_img);
                if(!is_img) {
                    $('.imageupload').addClass('mage-error');
                    $('.mage-error-local').addClass('show-mage');
                }
                else{
                    $('.imageupload').removeClass('mage-error');
                    $('.mage-error-local').removeClass('show-mage');
                }
                */
        if( !jQuery(".selectize-input").hasClass("has-items") ) {
            jQuery('.category-validation').remove();
            jQuery('<div generated="true" class="category-validation mage-error" style="display: block !important;">This is a required field.</div>').insertAfter('.selectize-input'); 
        } else {
            jQuery('.category-validation').remove();
        }
        
          var priceFlag = parseInt($('input[name="product[is_recommended_price_overridden]"]').val());
        var regularprice = parseInt($('input[name="price_regular"]').val());
        var overregular = parseInt($('input[name="over_price_regular"]').val());
      
        
        if( jQuery("#popup_product").validation('isValid') && jQuery(".selectize-input").hasClass("has-items")) {
            /*Start Image Validate*/
            /*Request Start*/
            
              var finalProductPrice =  ( priceFlag === 0 ) ? regularprice : overregular;
           if( finalProductPrice < 150 && window.consigntype == 1 ) {
               $("div.alert-danger").show().delay(3000).fadeOut('slow'); 
               return false;
           } else {
               $("div.alert-danger").fadeIn('slow'); 
           }
            jQuery.ajax({
                type:'POST',
                url: values.baseurl + 'procurement/bulkprocurement/product?active_item='+window.activeItem,
                data:new FormData(this),
                cache:false,
                contentType: false,
                processData: false,
                showLoader: true,
                success:function(data){
                    if( data['is_login'] == 0) {
                        window.setLocation(values.baseurl + 'procure/salesaccount/login');
                    }
                    jQuery(".page.messages").html( data['messages'] ).show().delay(5000).fadeOut('slow');
                    if (data['products'] !== null) {
                        $('#prev_img').attr('src','');
                        $('.product_list_content').html('');
                        $('.product_list_content').html(data['products']);
                        $('.product_list').css({'display': 'block', 'opacity': '1'});
                        $(".final_listing").html(data['overall']);

                    }
                    if( data['product_count'] > 0 ) {
                        jQuery(".product_list_content").html( data['products'] ).show();
                        jQuery(".product_select").css({'display': 'none', 'opacity': '0'});
                        jQuery(".final_listing").html(data['overall']); 
                        jQuery("span.view_list, button.next_button").removeClass("disabled");
                    } else {
                        jQuery(".product_list_content").hide();
                        jQuery(".product_select").css({'display': 'block', 'opacity': '1'});
                        jQuery("span.view_list, button.next_button").addClass("disabled"); 
                    }
                    $('[data-popup-open]').on('click', function (e) {
                        window.category[0].selectize.clear();
                        $('#popup_product')[0].reset();
                        $('.radio-toolbar label').removeClass('checked');
                        $('#prev_img').css('opacity','0');
                        $('.imageupload').removeClass('remove-pseudo');
                        popupOpen(e, this);
                    });

                    $('#is_edit').val( 0 );
                    window.activeItem = 0;
                    taxType();
                    $("button.print").on("click",function () {
                         window.print();
                         return true;
                    });
                   
                },
                error: function(data){
                    console.log("error");
                    console.log(data);
                }
            });
            /*End Request*/
            $('.bulkprocurement-bulkprocurement-index .popup').fadeOut(350);
            $('.product_list').css({'display':'block','opacity':'1'});
            $('.product_select').css({'display':'none','opacity':'0'});
//            window.autoGenerateSku = Math.floor(Math.random() * 90000) + 10000;
//            var consignType = jQuery('input[name="consigntype"]').val();
//            if(consignType){
//                var prefix = '';
//                if( consignType == 3 ) 
//                    prefix = 'OB';
//                if ( consignType == 1 ) {
//                    prefix = "1"; 
//                }  else if (consignType == 2) {
//                        prefix = "2"; 
//                    }
//                if( consignType ) {
//                    jQuery("input.product_code").val(prefix+window.autoGenerateSku);
//                }
//            }
            /*End Image Validate*/
        } else {
            //alert("not valid");
        }
    });
    /*upload preview*/
    function readURL(input) {
        if (input.files && input.files[0]) {
            var reader = new FileReader();

            reader.onload = function (e) {
                $('#prev_img').attr('src', e.target.result);
            }

            reader.readAsDataURL(input.files[0]);
        }
    }

    $("#imgInp").change(function(){
        $('#prev_img').css('opacity','1');
        $('.imageupload').addClass('remove-pseudo');
        readURL(this);
    });
          
    $('.attributeset').on('change',function(e){ 
        window.attributeSetId = this.value;
        getPriceAttributes();
    });
    $('.price-attr-brand').on('change', function(e){
        window.brand = this.value;
        getPriceAttributes();
    });
    $('.price-attr-quality').on('change', function(e){
        window.quality = this.value;
        getPriceAttributes();
    });
    $('.price-attr-size').on('change', function(e){
        window.size = this.value;
        getPriceAttributes();
    });
     $("#over_regular").on("blur", function() {
         var price=$("#over_regular").val();
         if(window.consigntype==1){
                $("#retail_price").val(price);
            }
         if(window.consigntype==2){
                $("#retail_price").val(price%35/100);
            }  
            });
    $('.price-attr-consigntype').on('change', function(e){
        window.consigntype = this.value;
        if(window.consigntype==3){
          $('.owned-prices').show();  
        }else{
           $('.owned-prices').hide(); 
        }
        $('.inner_bulk_main').removeClass(' disabled').css({'opacity':'1'});
        getPriceAttributes();
    });
    /* To get all attributes like attr set id, brand, quality, size and type */
    function getPriceAttributes() {
        if( window.attributeSetId  && window.brand && window.quality && window.size && window.consigntype && window.isPriceUpdateNeed != 0 ) { 
            jQuery.ajax({
                url: values.baseurl + 'procurement/bulkprocurement/updateprice',
                data: {
                    'category_id': window.attributeSetId,
                    'brand': window.brand,
                    'quality': window.quality,
                    'size': window.size,
                    'consigntype': window.consigntype
                },
                showLoader: true,
                type: 'POST',
                dataType: 'json'
            }).done(function (data) {
                if( data['is_login'] == 0) {
                    window.setLocation(values.baseurl + 'procure/salesaccount/login');
                }
                var Quantity = $("#quantity").val();
                update_override_toggle(data['regular_price'], Quantity , 'regular');
                update_override_toggle(data['consign_price'], Quantity , 'retail');
                if( window.consigntype == 3 ){
                    jQuery("#imu-percentage").val( data['trade_imu'] );
                    jQuery("#mmu-percentage").val( data['trade_mmu'] );
                }
                $("#over_regular,#over_retail").on('change', function () {
                    grandTotal();
                });
            });
        }
        window.isPriceUpdateNeed = 1;
    }
    
    /*Toggle Price Update*/
    function update_override_toggle(price, qty, type) {
        if (type == 'regular') {
            if (price == 0) {
                $("#over_regular").attr("readonly", false).val(''); /*Overriden price*/
                $("label.switch.left").addClass("togglecircle disable-switch");
                $("input.switch-input.left").val(1);
                $('#over_regular').addClass('required-entry validate-my-value');
                jQuery("input#price_regular").val('');
            } else if (price > 0) {
                $("#over_regular").attr("readonly", true).val('');
                $("label.switch.left").removeClass("togglecircle disable-switch");
                $("input.switch-input.left").val(0);
                $('#over_regular').removeClass('required-entry validate-my-value mage-error');
                $('#over_regular').val('');
                if ($('#over_regular-error').length > 0) {
                    $('#over_regular-error').hide();
                }
                window.regularPrice = price;
                jQuery("input#price_regular").val(price*qty);
            }
        } else if (type == 'retail') {
            if (price == 0) {
                $("#over_retail").attr("readonly", false).val(''); /*Overriden Price*/
                $("label.switch.over-right").addClass("togglecircle disable-switch");
                $("input.switch-input.right").val(1);
                $('#over_retail').addClass('required-entry validate-my-value');
                jQuery("input#retail_price").val('');
            } else if (price > 0) {
                $("#over_retail").attr("readonly", true).val(''); /*Overriden Price*/
                $("label.switch.over-right").removeClass("togglecircle disable-switch");
                $("input.switch-input.right").val(0);
                $('#over_retail').removeClass('required-entry validate-my-value mage-error');
                $('#over_retail').val('');
                if ($('#over_retail-error').length > 0) {
                    $('#over_retail-error').hide();
                }
                window.consignPrice = price;
                jQuery("input#retail_price").val(price * qty);
            }
        }
    }
    /*End*/
    /* customerList */ 
    jQuery("#contact_search").autocomplete({
        source: this.customerList,
        minLength: 1,
        select: function (event, val) { 
            if(val.item.id) {
                jQuery("#customer_id, #customer_id_txt").val( val.item.id );
                jQuery("#master_contract_id, #master_contract_id_txt").val(''); 
                /*Enable and Disable the Next Button*/
                    jQuery('.next_button').removeClass("disabled");
                    jQuery('.next_button').removeClass("enabled");
                /*End*/
                jQuery.ajax({
                    url: values.baseurl + 'procurement/index/switchconsignor',
                    data: {
                        'consignor_id': val.item.id,
                        'is_bulk': 1
                    },
                    type: 'POST',
                    dataType: 'json',
                    showLoader: true,
                    success:function(data){
                        if( data['is_login'] == 0) {
                            window.setLocation(values.baseurl + 'procure/salesaccount/login');
                        }
                        $(".submit_button, .prev_button").attr("disabled",false);
                        jQuery("#filers_type_id, #taxable_income_brackets_id, #philanthropic_id").attr("disabled",false);
                        jQuery("span.view_list, span.add_probk").removeClass("disabled");
                        jQuery("span.add_probk").trigger("click");
                        $("#active_procure_user_id").val(data['procure_user_id']);
                        $("#active_customer_id").val(data['customer_id']);
                        if( data['mc_id'] !== 0 ) {
                            jQuery("#master_contract_id, #master_contract_id_txt").val( data['mc_id'] ); 
                            jQuery(".no-master-contract").removeClass("owed-disable-label");  
                            jQuery(".page.messages").html('');
                            jQuery("#filers_type_id, #taxable_income_brackets_id, #philanthropic_id").attr("disabled",true);
                            jQuery(".form_listing.tax").hide();
                            jQuery("#radio1").trigger('click').next('label').addClass('checked');
                        } else {
                            jQuery(".page.messages").html(data['messages']).show().delay(5000).fadeOut('slow');
                            jQuery(".no-master-contract").addClass("owed-disable-label");        
                            jQuery("#filers_type_id, #taxable_income_brackets_id, #philanthropic_id").attr("disabled",false);
                            jQuery(".form_listing.tax").show();
                            jQuery("#radio1").attr("checked", false).next('label').removeClass('checked');
                        }
                        if( data['product_count'] > 0 ) {
                            jQuery(".product_list_content").html( data['grid'] ).show();
                            jQuery(".product_select").css({'display': 'none', 'opacity': '0'});
                            jQuery(".final_listing").html(data['overall']); 
                            jQuery("span.view_list, button.next_button").removeClass("disabled");
                        } else {
                            jQuery(".product_list_content").hide();
                            jQuery(".product_select").css({'display': 'block', 'opacity': '1'});
                            jQuery("span.view_list, button.next_button").addClass("disabled"); 
                        }
                        $('[data-popup-open]').on('click', function (e) {
                            window.category[0].selectize.clear();
                            $('#popup_product')[0].reset();
                            $('.radio-toolbar label').removeClass('checked');
                            $('#prev_img').css('opacity','0');
                            $('.imageupload').removeClass('remove-pseudo');
                            popupOpen(e, this);
                        });
                        jQuery("#customer_id, #customer_id_txt").val( data['customer_id'] ); 
                        jQuery("#consignor_type").val( data['business_type'] );
                        taxType();
                        $('.bulkprocurement-bulkprocurement-index .warning_close').on('click', function(e)  {
                            $('.bulkprocurement-bulkprocurement-index .message.warning').fadeOut(350);
                            e.preventDefault();
                        });
                        $("button.print").on("click",function () {
                             window.print();
                             return true;
                        });
                       
                    },
                    error: function(data){
                        
                    }
                }); 
            }
        }
    }); 
    jQuery(window).on("load",function(){
        taxType(); 
    });
    function taxType(){
        $("#filers_type_id").on("change", function(){
            $("#hidden_tax_filer").val( this.value );
        });
        $("#taxable_income_brackets_id").on("change", function(){
            $("#hidden_tax_bracket").val( this.value );
        });
        $("#philanthropic_id").on("change", function(){
            $("#hidden_philanthorpic").val( this.value );
        });
    }
  }
});

function isiPhone(){
    return (
        //Detect iPhone
    //var isiPad = navigator.userAgent.match(/iPad/i) != null;
        (navigator.platform.indexOf("iPhone") != -1) ||
        //Detect iPod
        (navigator.platform.indexOf("iPad") != -1)
    );
}

if(isiPhone()){
   jQuery('.datepicker_input').attr('type', 'date');
   jQuery('.datepicker_input').removeAttr('readonly','true');
   jQuery('.datepicker_input').removeAttr('id','datepicker');
   jQuery('.pref_time input').removeClass('timepicker');
   jQuery('.pref_time input').attr('type', 'time');
   jQuery('.pref_time input').removeAttr('readonly','true');
   jQuery("<span class='date_placeholder'>Date</span>").insertAfter("input.datepicker_input");
   jQuery("<span class='from_placeholder'>From</span>").insertAfter("input#from_time");
   jQuery("<span class='to_placeholder'>To</span>").insertAfter("input#to_time");
}