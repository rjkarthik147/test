<?php
namespace Ziffity\BulkProcurement\Api;

use Ziffity\BulkProcurement\Api\Data\BulkProcurementInterface;
use Ziffity\BulkProcurement\Api\Data\BulkProcurementSearchResultInterface;

interface BulkProcurementRepositoryInterface
{
  
    public function save(BulkProcurementInterface $subContract);

    public function getById($Id);
    
    public function getList(BulkProcurementSearchResultInterface $searchCriteria);

    public function delete(BulkProcurementInterface $subContract);

    public function deleteById($Id);
}
