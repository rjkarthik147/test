<?php

namespace Ziffity\BulkProcurement\Api;

use Ziffity\BulkProcurement\Api\Data\ProductCodeInterface;
use Ziffity\BulkProcurement\Api\Data\ProductCodeSearchResultInterface;
use Magento\Framework\Api\SearchCriteriaInterface;

interface ProductCodeRepositoryInterface
{
  
    public function save(ProductCodeInterface $productcode);

    public function getById($Id);
    
    public function getList(SearchCriteriaInterface $searchCriteria);

    public function delete(ProductCodeInterface $productcode);

    public function deleteById($Id);
}
