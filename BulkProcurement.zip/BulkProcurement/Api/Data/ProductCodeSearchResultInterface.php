<?php

namespace Ziffity\BulkProcurement\Api\Data;

use Magento\Framework\Api\SearchResultsInterface;

interface ProductCodeSearchResultInterface  extends SearchResultsInterface{
 
    public function getItems();

    public function setItems(array $items);
  
}
