<?php

namespace Ziffity\BulkProcurement\Api\Data;

interface ProductCodeInterface {
	
	const ID = 'id';

	public function getId();
}