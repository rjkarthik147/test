<?php

namespace Ziffity\BulkProcurement\Api\Data;

use Magento\Framework\Api\SearchResultsInterface;

interface BulkProcurementSearchResultInterface  extends SearchResultsInterface{
 
    public function getItems();

    public function setItems(array $items);
  
}
