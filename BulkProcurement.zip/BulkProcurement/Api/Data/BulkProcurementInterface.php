<?php

namespace Ziffity\BulkProcurement\Api\Data;

interface BulkProcurementInterface
{
    const CLEANOUT_ID                = 'entity_id';
    const STATUS_ID                  = 'status_id';
    const NUMBER_OF_ITEMS            = 'number_of_items';
    const STORE_CODE                 = 'store_code';
    const CUSTOMER_ID                = 'customer_id';
    const PICKUP_DATE                = 'pickup_date';
    const PICKUP_TIME_FROM           = 'pickup_time_from';
    const PICKUP_TIME_TO             = 'pickup_time_to';
    const IS_SCHEDULED               = 'is_scheduled';
    const IS_PRODUCT_ARRIVED         = 'is_product_arrived';
    const ARRIVED_DATE               = 'arrived_date';
    const CREATED_AT                 = 'created_at';
    const PHILANTHROPIC_ID           = 'philanthropic_id';
    const TAXABLE_INCOME_BRACKETS_ID = 'taxable_income_brackets_id';
    const FILERS_TYPE_ID             = 'filers_type_id';

    public function getId();

    public function getFilersTypeId();

    public function getStatus();

    public function getPickupTimeFrom();

    public function getPickupTimeTo();

    public function getPickupDate();

    public function isScheduled();

    public function isProductArrived();

    public function getArrivedDate();

    public function getNumberOfItems();

    public function getStoreCode();

    public function getCustomerId();

    public function getCreatedAt();

    public function getPhilanthropicId();

    public function getTaxableIncomeBracketsId();
}