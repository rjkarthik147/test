<?php


namespace Ziffity\BulkProcurement\Controller\Cleanout;

use Magento\Framework\Controller\ResultFactory;
use Ziffity\Procurement\Model\ResourceModel\ProcurementCondition\CollectionFactory AS procureCondition;
use Ziffity\Procurement\Model\ResourceModel\ProcurementPrice\CollectionFactory AS procurePrice;
use Ziffity\BulkProcurement\Helper\Data AS bulkHelper;
use Magento\Framework\Controller\Result\JsonFactory;
use Magento\Catalog\Api\CategoryRepositoryInterface;
use Magento\Eav\Model\ResourceModel\Entity\Attribute\CollectionFactory as AttributeCollectionFactory;
use \Ziffity\BulkProcurement\Helper\Data;
class Updateprice extends \Magento\Framework\App\Action\Action {

    protected $resultPageFactory;

    protected $_helper;
    protected $procurecondition;
    protected $procureprice;
    protected $brand;
    protected $quality;
    protected $consigntype;
    protected $categoryId;
    protected $size;
    protected $bulkHelper;
    protected $resultJsonFactory;
    protected $attributeCollectionFactory;
    protected $categoryRepository;
   
    public function __construct(
        \Magento\Framework\App\Action\Context $context,
        \Ziffity\Procurement\Helper\Data $helper,
        \Magento\Framework\View\Result\PageFactory $resultPageFactory,
        procureCondition $procurecondition,
        procurePrice $procureprice,
        bulkHelper $bulkHelper,
        AttributeCollectionFactory $attributeCollectionFactory,
        CategoryRepositoryInterface $categoryRepository,
        JsonFactory $resultJsonFactory
    )
    {
        $this->resultPageFactory = $resultPageFactory;
        $this->_helper = $helper;
        $this->attributeCollectionFactory  = $attributeCollectionFactory;
        $this->categoryRepository = $categoryRepository;
        $this->procurecondition = $procurecondition;
        $this->procureprice = $procureprice;
        $this->bulkHelper = $bulkHelper;
        $this->resultJsonFactory = $resultJsonFactory;
        parent::__construct($context);
    }

    /**
     * Execute view action
     *
     * @return \Magento\Framework\Controller\ResultInterface
     */
    public function execute()
    {

        $resultRedirect = $this->resultFactory->create(ResultFactory::TYPE_REDIRECT);
        $resultJson = $this->resultJsonFactory->create();
        if( $this->_helper->isUserLoggedin() == 0 ) {
             $Json['is_login'] = 0;
            return $resultJson->setData($Json);
        }
        
        $params = $this->getRequest()->getParams(); 
        $this->brand = $params['brand'];
        $this->quality = $params['quality'];
        $this->consigntype = $params['consigntype'];
        $this->categoryId = $params['category_id'];
        $consigntype=$params['consigntype'];
        $deimension=$this->getDimension($params['category_id']);
        $this->size = $params['size'];
       
        $Json['regular_price'] = round($this->calculatePrice($consigntype,$consigntype));
        $this->consigntype = Data::CONSIGNED_TYPE_CONSIGN;
        $Json['consign_price'] = round($this->calculatePrice($consigntype,Data::CONSIGNED_TYPE_CONSIGN));
                
         $Json['deimension']=  $deimension;
        $Json['is_login'] = 0;
        if( $this->_helper->isUserLoggedin() != 0 ) {
            $Json['is_login'] = 1;
        }
        return $resultJson->setData( $Json );
    }

    private function getDimension($categoryId){

        $deimention=[];
        $category             = $this->categoryRepository->get($categoryId);
        $setId                = $category->getData('map_attribute');
        $attributeCollection = $this->attributeCollectionFactory->create();
        $attributeCollection->setAttributeSetFilter($setId);
        $attributeCollection->addFieldToFilter('is_user_defined', ['eq' => 1]);
 
        foreach ($attributeCollection as $attribute){
            if(in_array($attribute->getAttributeCode(), ['length','height','width','procure_weight'])){
                 $deimention[$attribute->getAttributeCode()]=true;
            }
        }
  
        return $deimention;
 
    }


    protected function calculatePrice($currentType,$priceFor) {
        $consignType=$priceFor;
        if($currentType==Data::CONSIGNED_TYPE_DONATE && $priceFor==Data::CONSIGNED_TYPE_CONSIGN){
            $consignType=Data::CONSIGNED_TYPE_DONATE;
        }
        $condition = $this->procureprice->create()
                     ->addFieldToFilter(
                             'main_table.category_id',['eq'=>$this->categoryId]
                       )
                     ->addFieldToFilter(
                             'main_table.procurement_size_id',['eq'=>$this->size]
                       )
                     ->addFieldToFilter(
                             'main_table.is_brand',['eq'=>$this->brand]
                       )
                     ->addFieldToFilter(
                             'main_table.cleanout_procurement_type_id', 
                             ['eq'=>$consignType]
                       );
        $condition->getSelect()->join(
            ['condition' => 'vntg_procurement_condition'],
            'main_table.cleanout_procurement_type_id = condition.cleanout_procurement_type_id',
            ['cleanout_procurement_type_id'=>'cleanout_procurement_type_id']
        )
        ->where(
            "condition.procurement_quality_id =". $this->quality . 
            " and condition.is_brand =".$this->brand
        )
        ->columns(new \Zend_Db_Expr("condition.selling_price_percent"));
        $result=$condition->getData()[0]['procurement_selling_price']
                * $condition->getData()[0]['selling_price_percent'];
        $retailPrice = $this->_helper->getScopeConfigValue('procurement/ipad_subcontract/consigned_from_donate_percentage');
        if($currentType==Data::CONSIGNED_TYPE_DONATE && $priceFor==Data::CONSIGNED_TYPE_CONSIGN){
            $result=round($result)*((100+((int)$retailPrice))/100);
        }

        return  round($result);
    }
}
