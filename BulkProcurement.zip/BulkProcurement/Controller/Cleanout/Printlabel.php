<?php


namespace Ziffity\BulkProcurement\Controller\Cleanout;

use Magento\Framework\Controller\ResultFactory;

class Printlabel extends \Magento\Framework\App\Action\Action {

	protected $resultPageFactory;

	protected $_helper;
        protected $printModel;

    /**
	 * Constructor
	 *
	 * @param \Magento\Framework\App\Action\Context  $context
	 * @param \Magento\Framework\View\Result\PageFactory $resultPageFactory
	 */
	public function __construct(
		\Magento\Framework\App\Action\Context $context,
		\Ziffity\Procurement\Helper\Data $helper,
            \Ziffity\Cleanout\Model\Printbarcode $printModel,
		\Magento\Framework\View\Result\PageFactory $resultPageFactory
	)
	{
		$this->resultPageFactory = $resultPageFactory;
		$this->_helper = $helper;
                 $this->printModel  = $printModel;
		parent::__construct($context);
	}

	/**
	 * Execute view action
	 *
	 * @return \Magento\Framework\Controller\ResultInterface
	 */
	public function execute() {
            $resultRedirect = $this->resultFactory->create(ResultFactory::TYPE_REDIRECT);
            if( $this->_helper->isUserLoggedin() == 0 ) {
                $resultRedirect->setPath('procure/salesaccount/login');
                return $resultRedirect;
            }
                $id= $this->getRequest()->getParam('id');
                $this->printModel->drawPdf($id);

	}
}