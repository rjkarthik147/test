<?php

namespace Ziffity\BulkProcurement\Controller\Index;
use Magento\Framework\View\LayoutFactory;
use Magento\Store\Model\StoreManagerInterface as storeManager;
use Ziffity\BulkProcurement\Model\ResourceModel\BulkProcurement\CollectionFactory as   BulkProcurement;
class Switchconsignor extends \Magento\Framework\App\Action\Action {

    protected $helper;
    protected $resultPageFactory;
    protected $customer;
    protected $resultJsonFactory;
    protected $mastercontract;
    protected $layoutFactory;
    protected $storeManager;
    protected $bulkProcurement;
    protected $bulkHelper;
    const OWNED_NOTIFICATION = "There is no Master contract associated with this contact.
You will only be able to add 'Owned Inventory' items to this contact.
If you need to add 'Donate' or 'Consign' products, please create 'Master Contract' first by clicking this link";
    public function __construct(
    \Magento\Framework\View\Result\PageFactory $resultPageFactory, 
    \Magento\Framework\App\Action\Context $context, 
    \Magento\Customer\Model\Customer $customer, 
    \Ziffity\Procurement\Helper\Data $helper, 
    \Magento\Framework\Controller\Result\JsonFactory $resultJsonFactory,
    \Ziffity\Procurement\Model\ResourceModel\Consignor\CollectionFactory $mastercontract,
    LayoutFactory $layoutFactory,
    storeManager $storeManager,
    BulkProcurement $bulkProcurement,
    \Ziffity\BulkProcurement\Helper\Data $bulkHelper
    ) {
        $this->storeManager = $storeManager;
        $this->helper = $helper;
        $this->resultPageFactory = $resultPageFactory;
        $this->customer = $customer;
        $this->resultJsonFactory = $resultJsonFactory;
        $this->mastercontract = $mastercontract;
        $this->layoutFactory = $layoutFactory;
        $this->bulkProcurement = $bulkProcurement;
        $this->bulkHelper = $bulkHelper;
        parent::__construct($context);
    }

    public function execute() {
        $blockMsg = $this->layoutFactory->create()->getMessagesBlock();
        $error = 0;
        $this->bulkHelper->setActiveProductCount( 0 );
        $_params = $this->getRequest()->getParams();
        $_consignorId = $_params['consignor_id'];
        if( $_consignorId ) {
           /*Bulk procurement bulk customer session storing*/
            $this->helper->setBulkCustomerSession($_consignorId);
            $_customerModel = $this->customer->load($_consignorId);
            $return['shipping_address'] = (  $_customerModel->getDefaultShippingAddress() != false ) ?  $_customerModel->getDefaultShippingAddress()->getId() : 0 ;
            $resultPage = $this->resultPageFactory->create();
            $businessType = ( $_customerModel->getBusinessType() == 1 ) ? 1 : 0 ;
            $return['customer_id'] = $_consignorId;
            $return['procure_user_id'] = $this->helper->isUserLoggedin();
            $return['business_type'] = ( $businessType == 1 ) ? 'Business' : 'Individual' ;
            $masterContractId = $this->mastercontract->create()->addFieldToFilter('consigner_id', ['eq' => $_consignorId]);
            $return['mc_id'] = 0;
            if( count($masterContractId->getData()) != 0 ) {
                $return['mc_id'] = $masterContractId->getData()[0]['master_contract_id'];
                 //$this->helper->setConsignorSession($_consignorId);
            } else {
                $mcUrl = $this->storeManager->getStore()->getBaseUrl().'procure/consignor/createMasterContract';
                $this->messageManager->addWarning(__(self::OWNED_NOTIFICATION ) . "<a href=" . $mcUrl .">  create contact</a> or else close this warning message to proceed". "<a class='warning_close'></a>");
            }
            $return['grid'] = $resultPage->getLayout()
                    ->createBlock('Ziffity\BulkProcurement\Block\BulkProcurement\ProductListing')
	      ->setTemplate('Ziffity_BulkProcurement::bulkprocurement/product_listing.phtml')
	      ->toHtml();
            $return['overall'] = $resultPage->getLayout()
            ->createBlock('Ziffity\BulkProcurement\Block\BulkProcurement\ViewListing')
            ->setTemplate('Ziffity_BulkProcurement::bulkprocurement/view_listing.phtml')
            ->toHtml();
            $blockMsg->setMessages( $this->messageManager->getMessages(true) );
            $return['messages'] = $blockMsg->getGroupedHtml();
            $result = $this->resultJsonFactory->create(); 
            $bulkProcurement = $this->bulkProcurement->create();
            $bulkProcurement->getSelect()->join('bulk_procurement_items as item', 'main_table.entity_id = item.entity_id',[])->where('main_table.customer_id='.$_consignorId . ' and main_table.procurement_user_id='.$this->helper->isUserLoggedin().' and main_table.status_id = 0');
            $return['product_count'] = $bulkProcurement->getSize();
            $this->bulkHelper->setActiveProductCount( $bulkProcurement->getSize() );
            $return['is_login'] = 0;
            if( $this->helper->isUserLoggedin() != 0 ) {
                $return['is_login'] = 1;
            }
            
            return $result->setData($return);
        }
    }

}
