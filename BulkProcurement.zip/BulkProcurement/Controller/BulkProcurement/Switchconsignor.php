<?php

namespace Ziffity\Procurement\Controller\BulkProcurement;

class Switchconsignor extends \Magento\Framework\App\Action\Action {

    protected $helper;
    protected $resultPageFactory;
    protected $customer;
    protected $resultJsonFactory;
    protected $mastercontract;

    public function __construct(
    \Magento\Framework\View\Result\PageFactory $resultPageFactory, 
    \Magento\Framework\App\Action\Context $context, 
    \Magento\Customer\Model\Customer $customer, 
    \Ziffity\Procurement\Helper\Data $helper, 
    \Magento\Framework\Controller\Result\JsonFactory $resultJsonFactory,
    \Ziffity\Procurement\Model\ResourceModel\Consignor\CollectionFactory $mastercontract
    ) {
        $this->helper = $helper;
        $this->resultPageFactory = $resultPageFactory;
        $this->customer = $customer;
        $this->resultJsonFactory = $resultJsonFactory;
        $this->mastercontract = $mastercontract;
        parent::__construct($context);
    }

    public function execute() {

        $_params = $this->getRequest()->getParams();
        $_consignorId = $_params['consignor_id'];
        if( $_consignorId ) {
            $this->helper->setConsignorSession($_consignorId);
            $_customerModel = $this->customer->load($_consignorId);
            $resultPage = $this->resultPageFactory->create();
            $businessType = ( $_customerModel->getBusinessType() == 1 ) ? 1 : 0 ;
            
            $return['business_type'] = ( $businessType == 1 ) ? 'Business' : 'Individual' ;
            $return['business_name'] = ( $_customerModel->getBusinessname() ) ? $_customerModel->getBusinessname() : '' ;
           
            $masterContractId = $this->mastercontract->create()->addFieldToFilter('consigner_id', ['eq' => $_consignorId]);
            $return['master_contract_id'] = $masterContractId->getData()[0]['master_contract_id'];
            
            $result = $this->resultJsonFactory->create();

           
            
            return $result->setData($return);
        }
    }

}
