<?php


namespace Ziffity\BulkProcurement\Controller\BulkProcurement;

use Magento\Framework\Controller\ResultFactory;
use Ziffity\Procurement\Model\ResourceModel\ProcurementCondition\CollectionFactory AS procureCondition;
use Ziffity\Procurement\Model\ResourceModel\ProcurementPrice\CollectionFactory AS procurePrice;
use Ziffity\BulkProcurement\Helper\Data AS bulkHelper;
use Magento\Framework\Controller\Result\JsonFactory;
use Magento\Catalog\Api\CategoryRepositoryInterface;
use Magento\Eav\Model\ResourceModel\Entity\Attribute\CollectionFactory as AttributeCollectionFactory;

class Updateprice extends \Magento\Framework\App\Action\Action {

    protected $resultPageFactory;

    protected $_helper;
    protected $procurecondition;
    protected $procureprice;
    protected $brand;
    protected $quality;
    protected $consigntype;
    protected $categoryId;
    protected $size;
    protected $bulkHelper;
    protected $resultJsonFactory;
    protected $attributeCollectionFactory;
    protected $categoryRepository;
   
    public function __construct(
        \Magento\Framework\App\Action\Context $context,
        \Ziffity\Procurement\Helper\Data $helper,
        \Magento\Framework\View\Result\PageFactory $resultPageFactory,
        procureCondition $procurecondition,
        procurePrice $procureprice,
        bulkHelper $bulkHelper,
        AttributeCollectionFactory $attributeCollectionFactory,
        CategoryRepositoryInterface $categoryRepository,
        JsonFactory $resultJsonFactory
    )
    {
        $this->resultPageFactory = $resultPageFactory;
        $this->_helper = $helper;
        $this->attributeCollectionFactory  = $attributeCollectionFactory;
        $this->categoryRepository = $categoryRepository;
        $this->procurecondition = $procurecondition;
        $this->procureprice = $procureprice;
        $this->bulkHelper = $bulkHelper;
        $this->resultJsonFactory = $resultJsonFactory;
        parent::__construct($context);
    }

    /**
     * Execute view action
     *
     * @return \Magento\Framework\Controller\ResultInterface
     */
    public function execute()
    {

        $resultRedirect = $this->resultFactory->create(ResultFactory::TYPE_REDIRECT);

        if( $this->_helper->isUserLoggedin() == 0 ) {
                $resultRedirect->setPath('procure/salesaccount/login');
                return $resultRedirect;
        }
        $resultJson = $this->resultJsonFactory->create();
        $params = $this->getRequest()->getParams(); 
        $this->brand = $params['brand'];
        $this->quality = $params['quality'];
        $this->consigntype = $params['consigntype'];
        $this->categoryId = $params['category_id'];
        
        $deimension=$this->getDimension($params['category_id']);
        $this->size = $params['size'];
       
        $Json['regular_price'] = round($this->calculatePrice());
        $this->consigntype = \Ziffity\BulkProcurement\Helper\Data::CONSIGNED_TYPE_CONSIGN;
        $Json['consign_price'] = round($this->calculatePrice()); 
        
        if(round($this->calculatePrice()) > 0 ){
            $Json['trade_imu'] = number_format( ( $Json['consign_price'] - $Json['regular_price'] ) * 100 / $Json['consign_price'] ) . "%"  ;
            $d5 = $Json['consign_price'] * 0.68;
            $Json['trade_mmu'] = number_format( ( $d5 - $Json['regular_price'] ) * 100 / $d5 ) . "%";
        }
         $Json['deimension']=  $deimension;
        $Json['is_login'] = 0;
        if( $this->_helper->isUserLoggedin() != 0 ) {
            $Json['is_login'] = 1;
        }
        return $resultJson->setData( $Json );
    }

    private function getDimension($categoryId){

        $deimention=[];
        $category             = $this->categoryRepository->get($categoryId);
        $setId                = $category->getData('map_attribute');
        $attributeCollection = $this->attributeCollectionFactory->create();
        $attributeCollection->setAttributeSetFilter($setId);
        $attributeCollection->addFieldToFilter('is_user_defined', ['eq' => 1]);
 
        foreach ($attributeCollection as $attribute){
            if(in_array($attribute->getAttributeCode(), ['length','height','width','procure_weight'])){
                 $deimention[$attribute->getAttributeCode()]=true;
            }
        }
  
        return $deimention;
 
    }


    protected function calculatePrice() {
        
        $condition = $this->procureprice->create()
                     ->addFieldToFilter(
                             'main_table.category_id',['eq'=>$this->categoryId]
                       )
                     ->addFieldToFilter(
                             'main_table.procurement_size_id',['eq'=>$this->size]
                       )
                     ->addFieldToFilter(
                             'main_table.is_brand',['eq'=>$this->brand]
                       )
                     ->addFieldToFilter(
                             'main_table.cleanout_procurement_type_id', 
                             ['eq'=>$this->consigntype]
                       );
        $condition->getSelect()->join(
            ['condition' => 'vntg_procurement_condition'],
            'main_table.cleanout_procurement_type_id = condition.cleanout_procurement_type_id',
            ['cleanout_procurement_type_id'=>'cleanout_procurement_type_id']
        )
        ->where(
            "condition.procurement_quality_id =". $this->quality . 
            " and condition.is_brand =".$this->brand
        )
        ->columns(new \Zend_Db_Expr("condition.selling_price_percent"));
        
        return $condition->getData()[0]['procurement_selling_price'] 
                * $condition->getData()[0]['selling_price_percent'] ;
    }
}
