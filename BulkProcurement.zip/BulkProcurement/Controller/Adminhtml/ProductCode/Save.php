<?php
namespace Ziffity\BulkProcurement\Controller\Adminhtml\ProductCode;

use Magento\Framework\Exception\LocalizedException;

class Save extends \Magento\Backend\App\Action
{
	protected $coreRegistry = null;
	protected $productCodeModelFactory;
	protected $collectionFactory;
	protected $dataPersistor;
	protected $productCodeRepository;

	public function __construct(
		\Magento\Backend\App\Action\Context $context,
		\Magento\Framework\Registry $registry,
		\Ziffity\BulkProcurement\Model\ResourceModel\ProductCode\CollectionFactory $collectionFactory,
		\Ziffity\BulkProcurement\Model\ProductCodeFactory $productCodeModelFactory,
		\Ziffity\BulkProcurement\Api\ProductCodeRepositoryInterface $productCodeRepository,
		\Magento\Framework\App\Request\DataPersistorInterface $dataPersistor
	) {
		parent::__construct($context);
		$this->coreRegistry            = $registry;
		$this->productCodeModelFactory = $productCodeModelFactory;
		$this->collectionFactory       = $collectionFactory;
		$this->dataPersistor           = $dataPersistor;
		$this->productCodeRepository   = $productCodeRepository;		
	}

	/*protected function _isAllowed()
	{
		return $this->_authorization->isAllowed('Ziffity_BulkProcurement::productcode');
	}*/

	/*
	* save Action 
	*/
	public function execute()
	{ 
		$resultRedirect = $this->resultRedirectFactory->create();
		$data = $this->getRequest()->getPostValue();
		if ($data) {
		    $id = $this->getRequest()->getParam('id');
		    $category_id = $this->getRequest()->getParam('category_id');

		    $model = $this->productCodeModelFactory->create();		

		    $collection = $this->collectionFactory->create();

		    $requestData = array();
		    
		    if($id) {
		    	//$model = $this->productCodeRepository->getById($id);

		    	// Check for existence of the Attribut set and upcycle size
		    	$result = $collection
		    				->addFieldToFilter('category_id', array('eq' => $category_id))
		    				->addFieldToFilter('id', array('neq' => $id));
		    } else {
		    	// Check for existence of the Attribut set and upcycle size
		   		$result = $collection->addFieldToFilter('category_id', array('eq' => $category_id));
		    }
		    
		    if($result->getSize() > 0) {
				$this->messageManager->addError(__('Product Code has been already created for this category.'));
			}
 			else {
		    	//unset($data['form_key']);
		    	$model->setData($data);
		    	
		    try {
		    	
		    	$model->save();		        
		        $this->messageManager->addSuccess(__('Product Code has been saved successfully.'));
		        $this->dataPersistor->clear('ziffity_bulkprocurement_productcode');
		
		        if ($this->getRequest()->getParam('back')) {
		            return $resultRedirect->setPath('*/*/edit', ['id' => $model->getId()]);
		        }
		        return $resultRedirect->setPath('*/*/');
		    } catch (LocalizedException $e) {
		        $this->messageManager->addError($e->getMessage());
		    } catch (\Exception $e) {
		        $this->messageManager->addException($e, __('Something went wrong while saving the User.'));
		    }
		}
		
		    $this->dataPersistor->set('ziffity_bulkprocurement_productcode', $data);
		    return $resultRedirect->setPath('*/*/edit', ['id' => $this->getRequest()->getParam('id'), 'data' => 1, 'formData' => json_encode($data)]);
		}
		return $resultRedirect->setPath('*/*/');
	}

}