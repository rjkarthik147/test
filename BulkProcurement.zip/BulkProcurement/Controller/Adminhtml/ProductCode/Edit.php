<?php

namespace Ziffity\BulkProcurement\Controller\Adminhtml\ProductCode;

use Magento\Backend\App\Action;
use Magento\Framework\Exception\NoSuchEntityException;

class Edit extends Action
{
	/*
	* Code Registry
	* @var \Amgento\Franework\Registry
	*/
	protected $_coreRegistry = null;

	/**
	* @var \Magento\Framework\View\Result\PageFactory
	*/
	protected $_resultPageFactory;
	protected $productCodeRepository;
	protected $productCodeFactory;

	/**
	 * @param Action\Context $context
	 * @param \Magento\Franework\View\Result\PageFactory $resultPageFactory
	 * @param \Magento\Framework\Registry $registry
	 * @param \Ziffity\BulkProcurement\Api\ProductCodeRepositoryInterface $productCodeRepository
	 */
	public function __construct(
		Action\Context $context,
		\Magento\Framework\View\Result\PageFactory $resultPageFactory,
		\Magento\Framework\registry $registry,
		\Ziffity\BulkProcurement\Api\ProductCodeRepositoryInterface $productCodeRepository,
		\Ziffity\BulkProcurement\Model\ProductCodeFactory $productCodeFactory
	) {
		$this->_resultPageFactory = $resultPageFactory;
		$this->_coreRegistry = $registry;
		$this->productCodeRepository = $productCodeRepository;
		$this->productCodeFactory = $productCodeFactory;

		parent::__construct($context);
	}

	/*
	* Check for logged user allowed to access this page
	*/
	protected function _isAllowed()
	{
		return $this->_authorization->isAllowed('Ziffity_BulkProcurement::productcode');
	}

	/*
	* Init Actions
	*/
	protected function _initAction()
	{
		// load layout, set active menu and breadcrumbs
		$resultPage = $this->_resultPageFactory->create();
		$resultPage->setActiveMenu('Ziffity_BulkProcurement::productcode')->addBreadcrumb(__('Procurement'), __('Product Code'));
		return $resultPage;
	}

	/**
	* Edit form
	*/
	public function execute()
	{
		$id = $this->getRequest()->getParam('id');

		$model=$this->productCodeFactory->create();
        $id = $this->getRequest()->getParam('id');
       
           if ($id) {
             $model->load($id);
            if (!$model->getId()) {
                $this->messageManager->addError(__('This Product Code does not exists.'));
                /** \Magento\Backend\Model\View\Result\Redirect $resultRedirect */
                $resultRedirect = $this->resultRedirectFactory->create();
 
                return $resultRedirect->setPath('*/*/');
            }
        }
        $data = $this->_getSession()->getFormData(true);
        if ($model!=null && !empty($data)) {
            $model->setData($data);
        }
       
        $this->_coreRegistry->register('ProductCode', $model);
           $resultPage=$this->_initAction();
           $resultPage->getConfig()->getTitle()->prepend( ($model!=null && $model->getId()) ? __('Edit Product Code') : __('New Product Code'));
      
         return $resultPage;


	}
}