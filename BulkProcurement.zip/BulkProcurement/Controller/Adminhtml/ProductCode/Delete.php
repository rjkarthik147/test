<?php

namespace Ziffity\BulkProcurement\Controller\Adminhtml\ProductCode;
 
use Magento\Backend\App\Action;
 
class Delete extends Action
{
    protected $productCodeRepository;
 
    /**
     * @param Action\Context $context
     * @ReposityInteface \Ziffity\BulkProcurement\Api\ProductCodeRepositoryInterface $productCodeRepository
     */
    public function __construct(
        Action\Context $context,
        \Ziffity\BulkProcurement\Api\ProductCodeRepositoryInterface $productCodeRepository
    ) {
        parent::__construct($context);
        $this->productCodeRepository = $productCodeRepository;
    }
 
    /**
     * {@inheritdoc}
     */
    protected function _isAllowed()
    {
        return $this->_authorization->isAllowed('Ziffity_BulkProcurement::productcode');
    }
 
    /**
     * Delete action
     *
     * @return \Magento\Framework\Controller\ResultInterface
     */
    public function execute()
    {
        $id = $this->getRequest()->getParam('id');
        /** @var \Magento\Backend\Model\View\Result\Redirect $resultRedirect */
        $resultRedirect = $this->resultRedirectFactory->create();
        if ($id) {
            try {
                $this->productCodeRepository->deleteById($id);

                $this->messageManager->addSuccess(__('Product Code has been deleted successfully'));
                return $resultRedirect->setPath('*/*/');
            } catch (\Exception $e) {
              
                $this->messageManager->addError($e->getMessage());
                return $resultRedirect->setPath('*/*/edit', ['id' => $id]);
            }
        }
        $this->messageManager->addError(__('Product Code does not exist'));
        return $resultRedirect->setPath('*/*/');
    }
}