<?php

namespace Ziffity\BulkProcurement\Controller\Adminhtml\BulkProcurement;

use Magento\Backend\App\Action;
use Magento\Framework\Exception\NoSuchEntityException;

class Edit extends Action
{
    /**
     * Core registry
     *
     * @var \Magento\Framework\Registry
     */
    protected $_coreRegistry = null;

    /**
     * @var \Magento\Framework\View\Result\PageFactory
     */
    protected $_resultPageFactory;
    protected $bulkprocurementRepository;

    /**
     * @param Action\Context $context
     * @param \Magento\Framework\View\Result\PageFactory $resultPageFactory
     * @param \Magento\Framework\Registry $registry
     * @param \Ziffity\BulkProcurement\Model\PhilanthropicRepository $modelRepository
     */
    public function __construct(
    Action\Context $context,
    \Magento\Framework\View\Result\PageFactory $resultPageFactory,
    \Magento\Framework\Registry $registry,
    \Ziffity\BulkProcurement\Api\BulkProcurementRepositoryInterface $bulkprocurementRepository
    )
    {
        $this->_resultPageFactory = $resultPageFactory;
        $this->_coreRegistry      = $registry;
        $this->bulkprocurementRepository = $bulkprocurementRepository;

        parent::__construct($context);
    }

    /**
     * {@inheritdoc}
     */
    protected function _isAllowed()
    {
        return $this->_authorization->isAllowed('Ziffity_BulkProcurement::bulkprocurement_view');
    }

    /**
     * Init actions
     *
     * @return \Magento\Backend\Model\View\Result\Page
     */
    protected function _initAction()
    {
        // load layout, set active menu and breadcrumbs
        /** @var \Magento\Backend\Model\View\Result\Page $resultPage */
        $resultPage = $this->_resultPageFactory->create();
        $resultPage->setActiveMenu('Ziffity_BulkProcurement::bulkprocurements')
            ->addBreadcrumb(__('Procurement'), __('BulkInventory'));
        return $resultPage;
    }

    /**
     * Edit Department
     *
     * @return \Magento\Backend\Model\View\Result\Page|\Magento\Backend\Model\View\Result\Redirect
     * @SuppressWarnings(PHPMD.NPathComplexity)
     */
    public function execute()
    {

        $id = $this->getRequest()->getParam('id');

        if ($id) {
            try {
                $model      = $this->bulkprocurementRepository->getById($id);
                $this->_coreRegistry->register(\Ziffity\BulkProcurement\Helper\Data::CURRENT_BULK_PROCUREMENT,
                    $model);
                $resultPage = $this->_initAction();
                $resultPage->getConfig()->getTitle()->prepend(__('BulkInventory #'.$model->getId()));
                return $resultPage;
            } catch (NoSuchEntityException $e) {
                $this->messageManager->addError(__('This BulkInventory Item not exists.'));
                /** \Magento\Backend\Model\View\Result\Redirect $resultRedirect */
                $resultRedirect = $this->resultRedirectFactory->create();

                return $resultRedirect->setPath('*/*/');
            }
        }
    }
}