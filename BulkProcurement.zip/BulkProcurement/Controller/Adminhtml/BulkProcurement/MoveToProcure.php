<?php

namespace Ziffity\BulkProcurement\Controller\Adminhtml\BulkProcurement;

use Ziffity\BulkProcurement\Api\BulkProcurementRepositoryInterface;
use Ziffity\BulkProcurement\Helper\Data as Helper;
use Magento\Backend\App\Action\Context;
use Ziffity\BulkProcurement\Model\ProcurementMigraterFactory;
use Ziffity\BulkProcurement\Model\ResourceModel\BulkProcurementItem\CollectionFactory;

class MoveToProcure extends \Magento\Backend\App\Action
{
    protected $pageFactory;
    protected $bulkprocurementItemsFactory;
    protected $procurementMigraterFactory;
    protected $bulkProcurementRepository;

    public function __construct(BulkProcurementRepositoryInterface $bulkProcurementRepository,
                                Context $context,
                                ProcurementMigraterFactory $procurementMigraterFactory,
                                CollectionFactory $bulkprocurementItemsFactory
    )
    {
        $this->procurementMigraterFactory  = $procurementMigraterFactory;
        $this->bulkprocurementItemsFactory = $bulkprocurementItemsFactory;
        $this->bulkProcurementRepository   = $bulkProcurementRepository;
        return parent::__construct($context);
    }

    public function execute()
    {
        $resultRedirect = $this->resultRedirectFactory->create();
        $id             = $this->getRequest()->getParam('id');
        try {
            $bulkProcurement      = $this->bulkProcurementRepository->getById($id);
            $bulkprocurementItems = $this->bulkprocurementItemsFactory->create();
            $bulkprocurementItems->addFieldToFilter('entity_id', ['eq' => $id]);
            $procurementMigrater  = $this->procurementMigraterFactory->create();
            foreach ($bulkprocurementItems as $item) {
                if (false && $item->getSellIndividually()) {
                    $procurementMigrater->migrateAsMultipleProcurement($item,
                        $bulkProcurement);
                } else {
                    $procurementMigrater->migrateAsSingleProcurement($item,
                        $bulkProcurement);
                }
            }
            $bulkProcurement->setStatusId(Helper::PROCUREMENT_MOVED_TO_PROCUREMENT);
            $this->bulkProcurementRepository->save($bulkProcurement);
            
            $this->messageManager->addSuccess(__('Moved to Procurement'));
        } catch (\Exception $e) {
       
            $this->messageManager->addException($e,
                __('Something went wrong while Moving item to Procurement'));
        } finally {
            return $resultRedirect->setPath('*/*/');
        }
    }

    /**
     * {@inheritdoc}
     */
    protected function _isAllowed()
    {
        return $this->_authorization->isAllowed('Ziffity_BulkProcurement::bulkprocurement_save');
    }
}