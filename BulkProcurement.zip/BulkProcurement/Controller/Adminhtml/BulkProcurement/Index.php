<?php
namespace Ziffity\BulkProcurement\Controller\Adminhtml\BulkProcurement;
use Magento\Framework\View\Result\PageFactory;
use Magento\Backend\App\Action\Context;

class Index extends \Magento\Backend\App\Action
{
    protected $pageFactory;
    public function __construct(Context $context, PageFactory $pageFactory)
    {
        $this->pageFactory = $pageFactory;
        return parent::__construct($context);
    }

    public function execute()
    {        
      
     	$page_object = $this->pageFactory->create();
	$page_object->setActiveMenu('Ziffity_BulkProcurement::bulkprocurements');
        $page_object->addBreadcrumb(__('Procurement'), __('Bulk Inventory'));
         $page_object->getConfig()->getTitle()->prepend(__('Bulk Inventory'));
		
		
		
        return $page_object;
    }
    /**
     * {@inheritdoc}
     */
    protected function _isAllowed()
    {
        return $this->_authorization->isAllowed('Ziffity_BulkProcurement::bulkprocurement');
    }
}