<?php

namespace Ziffity\BulkProcurement\Controller\Adminhtml\BulkProcurement;

use Magento\Backend\App\Action\Context;
use Ziffity\BulkProcurement\Helper\Data as Helper;
use Ziffity\BulkProcurement\Model\BulkProcurementItem;

/**
 * Description of Save
 *
 * @author Daiva
 */
class Save extends \Magento\Backend\App\Action
{
    protected $bulkprocurementRepository;
    protected $activityLogFactory;
    protected $helper;
    private $id;
    protected $bulkprocurementItem;
    protected $_timezoneInterface;
    protected $bulkPickup;

    public function __construct(
    Context $context,
    \Ziffity\Onfleet\Helper\Bulk\CreateBulkPickup $bulkPickup,
    \Magento\Framework\Stdlib\DateTime\TimezoneInterface $timezoneInterface,
    \Ziffity\BulkProcurement\Api\BulkProcurementRepositoryInterface $bulkprocurementRepository,
    \Ziffity\Procurement\Model\ActivityLogFactory $activityLogFactory,
    \Ziffity\Procurement\Helper\Data $helper,
    BulkProcurementItem $bulkprocurementItem)
    {
        $this->bulkPickup = $bulkPickup;
        $this->bulkprocurementRepository = $bulkprocurementRepository;
        $this->activityLogFactory        = $activityLogFactory;
        $this->helper                    = $helper;
        $this->bulkprocurementItem       = $bulkprocurementItem;
        $this->_timezoneInterface         = $timezoneInterface;
        return parent::__construct($context);
    }

    public function execute()
    {


        $resultRedirect = $this->resultRedirectFactory->create();

        $this->id = $this->getRequest()->getParam('id');

        try {

            if ($this->id) {

                $model = $this->bulkprocurementRepository->getById($this->id);
                $data  = $this->getRequest()->getPost();

                switch ($model->getStatus()) {

                    case Helper::PROCUREMENT_NEW:
                        $is_scheduled = $data->get('is_scheduled');
                        if ($is_scheduled) {
                            $this->schedule($model);
                        }
                        $this->updateBulkProcurement($data, $model);
                        break;
                    case Helper::PROCUREMENT_PICK_PROCESSING:
                        $is_arrived = $data->get('is_arrived');
                        if ($is_arrived) {
                            $this->arrived($model, $data);
                        }
                        $this->updateBulkProcurement($data, $model);
                        break;
                    default:
                        $this->updateBulkProcurement($data, $model);
                }
            } else {
                $this->messageManager->addError("Something went Wrong try Again");
            }
            if ($data->get('movetocatalog'))
                $this->_forward("movetoprocure", "bulkprocurement", "bulkprocurement",
                ['id' => $this->id]);
            return $resultRedirect->setPath('*/*/');
        } catch (\Exception $e) {
        
            $this->messageManager->addException($e,
                __('Something went wrong while saving the Data'));
            return $resultRedirect->setPath('*/*/');
        }
    }

    protected function schedule($model)
    {   
        $resultRedirect = $this->resultRedirectFactory->create();
        $success = $this->bulkPickup->schedule($model);
        if ($success) {
            $model->setIsScheduled(1);
            $model->setStatusId(Helper::PROCUREMENT_PICK_PROCESSING);
            $this->bulkprocurementRepository->save($model);
            $useId = $this->helper->getUserId();
            $logModel = $this->activityLogFactory->create();
            $logModel->setData(['entity_id' => $this->id, 'action' => 'Product Status Changed to Pickup from New',
                'perfomer' => $useId]);
            $logModel->save();
            $this->messageManager->addSuccess(__('Onfleet Task Created'));
            $this->messageManager->addSuccess(__('Pickup Scheduled for #' . $this->id));
        } else {
            $this->messageManager->addError("Something went Wrong try Again");
            return $resultRedirect->setPath('*/*/');
        }
    }

    protected function arrived($model, $data)
    {
        $arrivedDate = $this->_timezoneInterface->date()->format('Y-m-d H:i:s');;
        $model->setIsProductArrived(1);
        $model->setStatusId(Helper::PROCUREMENT_PRODUCT_ARRIVED);
        $model->setArrivedDate($arrivedDate);
        $useId       = $this->helper->getUserId();
        $logModel    = $this->activityLogFactory->create();
        $logModel->setData(['entity_id' => $this->id, 'action' => 'Product has been Arived',
            'perfomer' => $useId]);
        $logModel->save();

        $this->bulkprocurementRepository->save($model);
        $this->messageManager->addSuccess(__('Data Successfully Saved  for #'.$this->id));
    }

    protected function updateBulkProcurement($data, $model)
    {

        $itemsData = $data->get('product');
        $this->updateItems($itemsData, $model);
        $model->setEstimatedApprisalValue($data->get('estimated_apprisal_value'));
        $model->setPhilanthropicId($data->get('philanthropic_id'));
        $model->setFilersTypeId($data->get('filers_type_id'));
        $model->setTaxableIncomeBracketsId($data->get('taxable_income_brackets_id'));
        $this->bulkprocurementRepository->save($model);

    }

    protected function updateItems($itemsData, $model)
    {

        foreach ($itemsData as $id => $item) {
            $this->bulkprocurementItem->load($id);

            if ($this->bulkprocurementItem->getId()) {
                if( isset($item['type']) ) {
                    $this->bulkprocurementItem->setTypeId($item['type']);
                }
                $this->bulkprocurementItem->setProductName($item['name']);
                $this->bulkprocurementItem->setCategoryId($item['attribute_set_id']);
                $this->bulkprocurementItem->setIsBrand($item['is_brand']);
                $this->bulkprocurementItem->setProcurementQualityId($item['quality']);
                $this->bulkprocurementItem->setProcurementSizeId($item['size']);
                $this->bulkprocurementItem->setQty($item['qty']);
                if(isset($item['sell_individually']))
                    $this->bulkprocurementItem->setSellIndividually($item['sell_individually']);

                $this->bulkprocurementItem->setIsRecommendedPriceOverridden($item['is_recommended_price_overridden']);
                if ($item['is_recommended_price_overridden'] == 1) {
                    $this->bulkprocurementItem->setOverriddenRecommendedPrice($item['overridden_recommended_price']);
                } else {
                    $this->bulkprocurementItem->setRecommendedPrice($item['recommended_price']);
                }
                $this->bulkprocurementItem->setIsRetailPriceOverridden($item['is_retail_price_overridden']);
                if ($item['is_retail_price_overridden'] == 1) {
                    $this->bulkprocurementItem->setOverriddenRetailPrice($item['overridden_retail_price']);
                } else {
                    $this->bulkprocurementItem->setRetailPrice($item['retail_price']);
                }
                $this->bulkprocurementItem->save();
                //$this->bulkprocurementItem->unsetData();
            }
        }
        $this->messageManager->addSuccess(__('Data Updated Successfully  for #'.$this->id));
    }

    /**
     * {@inheritdoc}
     */
    protected function _isAllowed()
    {
        return $this->_authorization->isAllowed('Ziffity_BulkProcurement::bulkprocurement_save');
    }
}