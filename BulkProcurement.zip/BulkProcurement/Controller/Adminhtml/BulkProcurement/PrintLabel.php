<?php

namespace Ziffity\BulkProcurement\Controller\Adminhtml\BulkProcurement;

use Magento\Backend\App\Action;
use Magento\Framework\Exception\NoSuchEntityException;

class PrintLabel extends Action
{
    protected $printModel;
    protected $fileFcatory;

    /**
     * @param Action\Context $context
     * @param \Ziffity\Cleanout\Model\Printbarcode $printModel
     */
    public function __construct(
    Action\Context $context, \Ziffity\BulkProcurement\Model\Printbarcode $printModel,
    \Magento\Framework\App\Response\Http\FileFactory $fileFactory
    )
    {
        $this->printModel  = $printModel;
        $this->fileFactory = $fileFactory;
        parent::__construct($context);
    }

    /**
     * {@inheritdoc}
     */
    protected function _isAllowed()
    {
        return $this->_authorization->isAllowed('Ziffity_Cleanout::cleanout_events_save');
    }

    public function execute()
    {

        $id             = $this->getRequest()->getParam('id');
        $resultRedirect = $this->resultRedirectFactory->create();
        if ($id) {
            try {
                $this->printModel->drawPdf($id);

               /* if ($pdf) {
                    return $this->fileFactory->create(
                            'PriceChange'.$data['selected_date'].'.pdf',
                            $pdf->render(), DirectoryList::VAR_DIR,
                            'application/pdf'
                    );
                } else {
                    $resultRedirect = $this->resultRedirectFactory->create();
                    $this->messageManager->addNotice(__('No items Found'));
                }*/

                $resultRedirect->setPath('cleanout/cleanout/edit', ['id' => $id]);
            } catch (NoSuchEntityException $e) {
                $this->messageManager->addError(__('This Transitional Service not exists.'));

                $resultRedirect->setPath('*/*/');
            }
        }
        return $resultRedirect;
    }
}