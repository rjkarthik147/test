<?php
namespace Ziffity\BulkProcurement\Block\Cleanout;
use Magento\Customer\Model\ResourceModel\Customer\CollectionFactory as custColl;
use Magento\Customer\Model\Customer as customer;
use Ziffity\Procurement\Model\ResourceModel\SubContract\CollectionFactory as SubContractsFactory;
use Ziffity\Procurement\Model\ResourceModel\Owneditem\CollectionFactory as OwneditemsFactory;
use Ziffity\Procurement\Model\ResourceModel\Consignor\CollectionFactory as Mc;
use Ziffity\Cleanout\Model\ResourceModel\Cleanout\CollectionFactory as   CleanoutsFactory;
use Ziffity\BulkProcurement\Model\ResourceModel\ProductCode\CollectionFactory as productCode;
use Ziffity\Cleanout\Helper\Data as cleanoutHelper;
class Index extends \Magento\Framework\View\Element\Template {
    protected $attrCollect;
    protected $option = '';
    protected $procureSize;
    protected $input = '';
    protected $procureQty;
    protected $qty = '';
    protected $category;
    protected $custCollection;
    protected $helper;
    protected $customerModel;
    protected $mastercontract;
    protected $cleanoutsFactory;
    protected $productCode;
    protected $bulkHelper;
    private $subContractsFactory;
    private $owneditemsFactory;
    public function __construct(
        \Magento\Framework\View\Element\Template\Context $context, 
        \Ziffity\Procurement\Model\Attributeset $attrCollection,
        \Ziffity\Procurement\Model\ResourceModel\ProcurementSize\CollectionFactory $size,
        \Ziffity\Procurement\Model\ResourceModel\ProcurementQuality\CollectionFactory $qty,
        \Magento\Catalog\Model\ResourceModel\Category\CollectionFactory $category,
        custColl $customerCollection,
        \Ziffity\Procurement\Helper\Data $helper,
        customer $customer,
        Mc $mastercontract,
        SubContractsFactory $subContractsFactory,
        OwneditemsFactory $owneditemsFactory,
        CleanoutsFactory $cleanoutsFactory,
        productCode $productCode,
        \Ziffity\BulkProcurement\Helper\Data $bulkHelper,
         array $data = array()
    ) {
        $this->attrCollect = $attrCollection ;
        $this->procureSize = $size;
        $this->procureQty = $qty;
        $this->category = $category;
        $this->owneditemsFactory=$owneditemsFactory;
        $this->subContractsFactory=$subContractsFactory;
        $this->custCollection = $customerCollection;
        $this->helper = $helper;
        $this->customerModel = $customer;
        $this->mastercontract = $mastercontract;
        $this->cleanoutsFactory = $cleanoutsFactory;
        $this->productCode = $productCode;
        $this->bulkHelper = $bulkHelper;
        parent::__construct($context, $data);
    }
    
    /* To display the attribute sets  */
    public function attributeSetOption(){
        $categoryCollection = $this->productCode->create();
        $categoryCollection->getSelect()->Order('label','ASC');
        foreach ($categoryCollection as $category) { 
            $this->option .= "<option value=". $category->getCategoryId() . " >" . $category->getLabel() . "</option>";
        } 
        return $this->option;
    }
    public function qualityOption(){
        $procureSizes = $this->procureQty->create();
        foreach( $procureSizes as $procureSize ) {

            $this->qty .= "<input id='qty-p1-". $procureSize->getId() ."' class='price-attr-quality orm-control input-text required-entry'  name='product[quality]' value=" . $procureSize->getId() . " type='radio' /><label for=qty-p1-". $procureSize->getId() .">" . $procureSize->getQuality() . "</label>" ; 

        }
        return $this->qty;
    }
    public function sizeOption() {
        $procureSizes = $this->procureSize->create();
        foreach( $procureSizes as $procureSize ) {
            $this->input .= "<input id='size-p1-". $procureSize->getId() ."' class='price-attr-size form-control input-text required-entry'  name='product[size]' value=" . $procureSize->getId() . " type='radio' /><label for=size-p1-". $procureSize->getId() .">" . $procureSize->getSize() . "</label>" ; 
        }
        return $this->input;
    }
    public function getCustomerList() { 
        $html = '';
        $customerCollection = $this->custCollection->create();
            foreach ($customerCollection as $cust) {
                $firstname = preg_replace('/[^A-Za-z0-9\-]/', '', $cust->getFirstname());
                $lastname = preg_replace('/[^A-Za-z0-9\-]/', '', $cust->getLastname());
                $html .= sprintf('{ "id": "%u" , "value": "%s" , "label": "%s" },',$cust->getId(),$firstname . " " . $lastname , $firstname . " " . $lastname . "  ( " .$cust->getEmail() ." )" );
                
            }
        return $html; 
    }
    /* Active bulk procurement customer */
    public function getActiveBulkCustomer() {
        //return $this->helper->getBulkCustomerId();
        if( $this->helper->getBulkCustomerId() ) {
            $_customerModel = $this->customerModel->load( $this->helper->getBulkCustomerId() );
            $return['name'] = $_customerModel->getFirstname() . " " .
                              $_customerModel->getLastname();
            $return['customer_id'] = $_customerModel->getId();
            $businessType = $_customerModel->getBusinessType();
            $return['business_type'] = ( $businessType == 1 ) ? 'Business' : 'Individual' ;
            $masterContract = $this->mastercontract->create()
                                ->addFieldToFilter('consigner_id', 
                                    ['eq' => $_customerModel->getId()]
                                );
            if( count($masterContract->getData()) > 0 ) {
                $return['master_contract_id'] = $masterContract->getData()[0]['master_contract_id'];
            }
            $return['procurement_user_id'] = $this->helper->isUserLoggedin();
            return $return;
        }
        return 0;
    }
    
    public function customerInfo( $key ) {
        if( isset( $this->getActiveBulkCustomer()[$key] ) ) {
            return $this->getActiveBulkCustomer()[$key];
        } else {
            return '';
        }
    }
    /*Changes */
    public function getProductCount(){
        $customerId = $this->customerInfo('customer_id');
       
        $cleanout = $this->cleanoutsFactory->create()
                          ->addFieldToFilter(
                                  'customer_id',['eq'=> $customerId ]
                            )->addFieldToFilter(
                                  'is_draft',['eq'=> 1 ]
                            )->addFieldToFilter(
                                  'source',['eq'=> 3 ]
                            )
                          ->getLastItem();
         
         
         $subcontractItem    =   $this->subContractsFactory->create()
                                ->addFieldToFilter(
                                   'cleanout_id',[
                                       'eq'=>$cleanout->getId()
                                   ]
                                )
                                ->getData();
        $ownedItem          =   $this->owneditemsFactory->create()
                                ->addFieldToFilter(
                                  'cleanout_id',[
                                      'eq'=>$cleanout->getId()
                                  ]
                                )
                                ->getData();
                            
        $collection_count = count($subcontractItem)+count($ownedItem);
        
        return $collection_count;
    }

    public function offerHolding() {
        return json_encode( cleanoutHelper::$offerMapping );
    }
    
    public function productCount() {
        return $this->bulkHelper->getActiveProductCount();
    }
    public function getMinConsignValue() {
        $storeScope = \Magento\Store\Model\ScopeInterface::SCOPE_STORE;
        $value      = $this->_scopeConfig->getValue('procurement/ipad_subcontract/minimum_consignment_share',
            $storeScope);
        return $value;
    }
    public function getValue($configValue = null) {
        $storeScope = \Magento\Store\Model\ScopeInterface::SCOPE_STORE;
        $value      = $this->_scopeConfig->getValue($configValue,
            $storeScope);
        return $value;
    }
}