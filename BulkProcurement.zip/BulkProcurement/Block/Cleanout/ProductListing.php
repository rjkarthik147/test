<?php
namespace Ziffity\BulkProcurement\Block\Cleanout;
use Magento\Framework\UrlInterface;

class ProductListing extends \Magento\Framework\View\Element\Template
{
    protected $helper;
    protected $mediaUrl;
    protected $session;
    private $subcontractModel;
    private $ownedModel;
    private $product;
    public function __construct(
	\Magento\Framework\View\Element\Template\Context $context,
        \Ziffity\Procurement\Helper\Data $helper,
        \Magento\Catalog\Model\Session $session,
        \Ziffity\Procurement\Model\SubContractFactory $subcontractModel,
        \Ziffity\Procurement\Model\OwneditemFactory $ownedItem,
        \Magento\Catalog\Model\Product $product
    ) {
        $this->helper = $helper;
        $this->mediaUrl = $context->getStoreManager()->getStore()->getBaseUrl( UrlInterface::URL_TYPE_MEDIA );
        $this->session = $session;
        $this->subcontractModel = $subcontractModel;
        $this->ownedModel = $ownedItem;
        $this->product = $product;
	parent::__construct($context);
    }

    public function CleanoutItemCollection() {

        $subcontractItem    =   $this->subcontractModel->create()->getCollection()
                                ->addFieldToFilter(
                                   'cleanout_id',[
                                       'eq'=>$this->helper->getCleanoutCustomerId()
                                   ]
                                )
                                ->getData();
        $ownedItem          =   $this->ownedModel->create()->getCollection()
                                ->addFieldToFilter(
                                  'cleanout_id',[
                                      'eq'=>$this->helper->getCleanoutCustomerId()
                                  ]
                                )
                                ->getData();
                           
        $cleanoutItems      = array_merge( $subcontractItem, $ownedItem);
        $cleanoutItems = $this->helper->sortingArray($cleanoutItems, 'product_id');
        return $cleanoutItems;
    }
    
    public function product( $productId ){
       
        return  $this->product->load( $productId );
    }

    public function getEntityId() {
        return $this->helper->getCleanoutCustomerId();

    }
    public function getCustomerinfo($key) {
        return (isset($this->session->getCustomerInfo()[$key]) && $this->session->getCustomerInfo()[$key] != '') ? $this->session->getCustomerInfo()[$key] : '';
    }
    public function placeholderImage() {
        return $this->mediaUrl ."catalog/product/placeholder/default/image.jpg";
    }
    /**
     * @return string
     * @param int $productId
     */
    public function productImage( $productId ){
        $subcontract = $this->subcontractModel->create()->load($productId, "product_id");
        $owned = $this->ownedModel->create()->load($productId, "product_id");
        if ( $subcontract->getId() &&
             $subcontract->getImage() !== NULL && trim($subcontract->getImage())!=""
        ) {
            return $this->mediaUrl . "/procurement/transitional/resized/".$subcontract->getImage();
        } elseif ( $owned->getId() &&
               $owned->getImage() !== NULL && trim($owned->getImage())!=""
        ) {
            return $this->mediaUrl . "/procurement/transitional/resized/".$owned->getImage();
        }
        return $this->placeholderImage();
    }
}