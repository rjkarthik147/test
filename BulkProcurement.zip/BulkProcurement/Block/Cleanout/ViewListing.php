<?php
namespace Ziffity\BulkProcurement\Block\Cleanout;

use \Ziffity\BulkProcurement\Model\ResourceModel\BulkProcurementItem\CollectionFactory as BulkProcurementItemCollectionFactory;
use \Ziffity\BulkProcurement\Model\ResourceModel\BulkProcurement\CollectionFactory as BulkProcurementCollectionFactory;
use \Ziffity\Procurement\Model\ResourceModel\Taxfilers\CollectionFactory as FilersTypeCollectionFactory;
use \Ziffity\Procurement\Model\ResourceModel\Philanthropic\CollectionFactory as PhilanthropicCollectionfactory;
use \Ziffity\Procurement\Model\ResourceModel\Incomebrackets\CollectionFactory as IncomebracketsCollectionFactory;
use Ziffity\Procurement\Model\ResourceModel\SubContract\CollectionFactory as SubContractsFactory;
use Ziffity\Procurement\Model\ResourceModel\Owneditem\CollectionFactory as OwneditemsFactory;
use Ziffity\Cleanout\Model\ResourceModel\Cleanout\CollectionFactory as   CleanoutsFactory;
class ViewListing extends \Magento\Framework\View\Element\Template
{

    
    protected $cleanoutsFactory;
    protected $_filersTypeCollectionFactory;
    protected $_philanthropicCollectionfactory;
    protected $_incomebracketsCollectionFactory;
    protected $_productListing;
    protected $helper;
    private $subContractsFactory;
    private $owneditemsFactory;
    public function __construct(SubContractsFactory $subContractsFactory,
        OwneditemsFactory $owneditemsFactory,
        CleanoutsFactory $cleanoutsFactory,
    \Magento\Framework\View\Element\Template\Context $context,
        FilersTypeCollectionFactory $filersTypeCollectionFactory,
        PhilanthropicCollectionfactory $philanthropicCollectionfactory,
        IncomebracketsCollectionFactory $incomebracketsCollectionFactory,
        \Ziffity\BulkProcurement\Block\BulkProcurement\ProductListing $productListing,
    \Ziffity\Procurement\Helper\Data $helper
    )
    {

        $this->_filersTypeCollectionFactory = $filersTypeCollectionFactory;
        $this->_philanthropicCollectionfactory = $philanthropicCollectionfactory;
        $this->_incomebracketsCollectionFactory = $incomebracketsCollectionFactory;
        $this->cleanoutsFactory = $cleanoutsFactory;
        $this->owneditemsFactory=$owneditemsFactory;
        $this->subContractsFactory=$subContractsFactory;
        $this->_productListing = $productListing;
        $this->helper = $helper;
        parent::__construct($context);
    }
    /*
     * Scope : Get product data based on the type ID
     * Request param : Type ID (Integer)
     * Return : array
     */

    public function getProductsByTypeId($typeId = null, $cleanoutId = null)
    {
        $result = array();
        if (!empty($typeId) && !empty($cleanoutId)) {
            if($typeId==3){
            $ownedItem=$this->owneditemsFactory->create();
            $ownedItemList = $ownedItem
                ->addFieldToFilter('procurement_type_id', array('eq' => $typeId))
                ->addFieldToFilter('cleanout_id', array('eq' => $cleanoutId));
            $result   = $ownedItemList->getData();
            }
            else{
            $subContract=$this->subContractsFactory->create();
            $subContractList = $subContract
                ->addFieldToFilter('procurement_type_id', array('eq' => $typeId))
                ->addFieldToFilter('cleanout_id', array('eq' => $cleanoutId));
            
           $result   =    $subContractList->getData();
            }
        }
        return $result;
    }
    /*
     * --Bulk Procurement Details--
     * Scope: Fetch the Bulk Procurement data
     * Request param: interger - Bulk procurement ID
     * Return : array
     */

    public function BulkProcurementData($cleanoutId = null)
    {
        $result = array();
        if (!empty($cleanoutId)) {
            $cleanout = $this->cleanoutsFactory->create();
            $cleanoutData = $cleanout->addFieldToFilter('entity_id', array('eq' => $cleanoutId));
            if ($cleanoutData->getSize() > 0) {
                $cleanoutData = $cleanoutData->getData();
                $result = $cleanoutData[0];
            }
        }
        return $result;
    }
    /*
     * -- Get Tax Filers Type --
     * Scope : Fetch Tax filers type to build a drop down
     * Request param: -
     * Return: array
     */

    public function getTaxFilersType()
    {
        $filersType = $this->_filersTypeCollectionFactory->create()->setOrder('filers_type_id', 'ASC');
        ;
        return $filersType->getData();
    }
    /*
     * -- Get Philanthropic choice --
     * Scope : Fetch Tax filers type to build a drop down
     * Request param: -
     * Return: array
     */

    public function getPhilanthropicChoice()
    {
        $philanthropicCollection = $this->_philanthropicCollectionfactory->create()->setOrder('name', 'ASC');
        return $philanthropicCollection->getData();
    }
    /*
     * -- Get tax income brackets rate --
     * Scope: Fetch tax income brackets rate to build a drop down
     * Request param: -
     * Return: array
     */

    public function getTaxIncomeBracketRate()
    {
        $taxincomeBracketRate = $this->_incomebracketsCollectionFactory->create()->setOrder('taxable_income_brackets_id', 'ASC');
        return $taxincomeBracketRate->getData();
    }
    /*
     * -- Get BulkProcurementId --
     *      */

    public function getCleanoutId()
    {   $process_items_id = NULL;
        $consignerId = $this->_productListing->getCustomerId();
        if (isset($consignerId)) {
            $bulk = $this->cleanoutsFactory->create()
                    ->addFieldToFilter("customer_id", ['eq'=> $consignerId])
                    ->addFieldToFilter("is_draft", ['eq'=> 1])
                ->addFieldToFilter("source", ['eq'=> 3]);
            return $bulk->getLastItem()->getId();
        }
    }
}
