<?php
namespace Ziffity\BulkProcurement\Block\BulkProcurement;

use \Ziffity\BulkProcurement\Model\ResourceModel\BulkProcurementItem\CollectionFactory as BulkProcurementItemCollectionFactory;
use \Ziffity\BulkProcurement\Model\ResourceModel\BulkProcurement\CollectionFactory as BulkProcurementCollectionFactory;
use \Ziffity\Procurement\Model\ResourceModel\Taxfilers\CollectionFactory as FilersTypeCollectionFactory;
use \Ziffity\Procurement\Model\ResourceModel\Philanthropic\CollectionFactory as PhilanthropicCollectionfactory;
use \Ziffity\Procurement\Model\ResourceModel\Incomebrackets\CollectionFactory as IncomebracketsCollectionFactory;

class Printlabel extends \Magento\Framework\View\Element\Template
{

    protected $_bulkprocurementItemCollectionFactory;
    protected $_bulkprocurementCollectionFactory;
    protected $_filersTypeCollectionFactory;
    protected $_philanthropicCollectionfactory;
    protected $_incomebracketsCollectionFactory;
    protected $_productListing;
    protected $helper;
    public function __construct(
    \Magento\Framework\View\Element\Template\Context $context, BulkProcurementItemCollectionFactory $bulkProcurementItemCollectionFactory, BulkProcurementCollectionFactory $bulkprocurementCollectionFactory, FilersTypeCollectionFactory $filersTypeCollectionFactory, PhilanthropicCollectionfactory $philanthropicCollectionfactory, IncomebracketsCollectionFactory $incomebracketsCollectionFactory, \Ziffity\BulkProcurement\Block\BulkProcurement\ProductListing $productListing,
    \Ziffity\Procurement\Helper\Data $helper
    )
    {

        $this->_bulkprocurementItemCollectionFactory = $bulkProcurementItemCollectionFactory;
        $this->_bulkprocurementCollectionFactory = $bulkprocurementCollectionFactory;
        $this->_filersTypeCollectionFactory = $filersTypeCollectionFactory;
        $this->_philanthropicCollectionfactory = $philanthropicCollectionfactory;
        $this->_incomebracketsCollectionFactory = $incomebracketsCollectionFactory;
        $this->_productListing = $productListing;
        $this->helper = $helper;
        parent::__construct($context);
    }
    /*
     * Scope : Get product data based on the type ID
     * Request param : Type ID (Integer)
     * Return : array
     */

    public function getProductsByTypeId($typeId = null, $bulkProcurementId = null)
    {
        $result = array();
        if (!empty($typeId) && !empty($bulkProcurementId)) {
            $bulkProcurementItem = $this->_bulkprocurementItemCollectionFactory->create();
            $bulkProcurementItemList = $bulkProcurementItem
                ->addFieldToFilter('type_id', array('eq' => $typeId))
                ->addFieldToFilter('entity_id', array('eq' => $bulkProcurementId))
            ;
            $result = $bulkProcurementItemList->getData();
        }
        return $result;
    }
    /*
     * --Bulk Procurement Details--
     * Scope: Fetch the Bulk Procurement data
     * Request param: interger - Bulk procurement ID
     * Return : array
     */

    public function BulkProcurementData($bulkProcurementId = null)
    {
        $result = array();
        if (!empty($bulkProcurementId)) {
            $bulkProcurement = $this->_bulkprocurementCollectionFactory->create();
            $bulkProcurementData = $bulkProcurement->addFieldToFilter('entity_id', array('eq' => $bulkProcurementId));
            if ($bulkProcurementData->getSize() > 0) {
                $bulkProcurementData = $bulkProcurementData->getData();
                $result = $bulkProcurementData[0];
            }
        }
        return $result;
    }
    /*
     * -- Get Tax Filers Type --
     * Scope : Fetch Tax filers type to build a drop down
     * Request param: -
     * Return: array
     */

    public function getTaxFilersType()
    {
        $filersType = $this->_filersTypeCollectionFactory->create()->setOrder('filers_type_id', 'ASC');
        ;
        return $filersType->getData();
    }
    /*
     * -- Get Philanthropic choice --
     * Scope : Fetch Tax filers type to build a drop down
     * Request param: -
     * Return: array
     */

    public function getPhilanthropicChoice()
    {
        $philanthropicCollection = $this->_philanthropicCollectionfactory->create()->setOrder('name', 'ASC');
        return $philanthropicCollection->getData();
    }
    /*
     * -- Get tax income brackets rate --
     * Scope: Fetch tax income brackets rate to build a drop down
     * Request param: -
     * Return: array
     */

    public function getTaxIncomeBracketRate()
    {
        $taxincomeBracketRate = $this->_incomebracketsCollectionFactory->create()->setOrder('taxable_income_brackets_id', 'ASC');
        return $taxincomeBracketRate->getData();
    }
    /*
     * -- Get BulkProcurementId --
     *      */

    public function getBulkProcurementId()
    {   $process_items_id = NULL;
        $consignerId = $this->_productListing->getCustomerId();
        if (isset($consignerId)) {
            $bulk = $this->_bulkprocurementCollectionFactory->create()
                    ->addFieldToFilter("customer_id", ['eq'=> $consignerId])
                    ->addFieldToFilter("procurement_user_id", ['eq'=> $this->helper->isUserLoggedin()])
                    ->addFieldToFilter("status_id", ['eq'=> \Ziffity\BulkProcurement\Helper\Data::PROCUREMENT_DRAFT]);
            return $bulk->getLastItem()->getId();
        }
    }
    
    public function items(){
        $params = $this->getRequest()->getParams();
        $bulkProcurementItem = $this->_bulkprocurementItemCollectionFactory->create();
        $bulkProcurementItem->addFieldToFilter('entity_id',['eq'=>$params['id']]);
        return $bulkProcurementItem;
    }
}
