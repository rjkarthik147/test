<?php
namespace Ziffity\BulkProcurement\Block\BulkProcurement;

use \Ziffity\BulkProcurement\Model\ResourceModel\BulkProcurementItem\CollectionFactory as BulkProcurementItemCollectionFactory;
use \Ziffity\BulkProcurement\Model\ResourceModel\BulkProcurement\CollectionFactory as   BulkProcurementCollectionFactory;
use Magento\Framework\UrlInterface;
class ProductListing extends \Magento\Framework\View\Element\Template {
	protected $_bulkprocurementItemCollectionFactory;
	protected $_bulkprocurementCollectionFactory;
    protected $_helper;
    protected $mediaUrl;    
    protected $placeHolder;
    public function __construct(
		\Magento\Framework\View\Element\Template\Context $context,
		BulkProcurementItemCollectionFactory $bulkProcurementItemCollectionFactory,
		BulkProcurementCollectionFactory $bulkprocurementCollectionFactory,
        \Ziffity\Procurement\Helper\Data $helper
	) { 

		$this->_bulkprocurementItemCollectionFactory = $bulkProcurementItemCollectionFactory;
		$this->_bulkprocurementCollectionFactory = $bulkprocurementCollectionFactory;
        $this->_helper = $helper;
        $this->mediaUrl = $context->getStoreManager()->getStore()->getBaseUrl( UrlInterface::URL_TYPE_MEDIA );
        $this->placeHolder = $context->getScopeConfig()->getValue('catalog/placeholder/image_placeholder');
		parent::__construct($context);
	}

	/* 
	* --Product Listing--
	* Scope: Fetch the product details for listing
	* Request param: interger - Bulk procurement ID
	* Return : array
	*/
	public function BulkProcurementProductItems($bulkProcurementId = null){
		$result = array();
		if(!empty($bulkProcurementId)) {
			$bulkProcurementItems = $this->_bulkprocurementItemCollectionFactory->create();
			$bulkProcurementItemList = $bulkProcurementItems->addFieldToFilter('entity_id', array('eq' => $bulkProcurementId));
			$result = $bulkProcurementItemList->getData();
		}
		return $result;
	}

	/* 
	* --Bulk Procurement Details--
	* Scope: Fetch the Bulk Procurement data
	* Request param: interger - Bulk procurement ID
	* Return : array
	*/
	public function BulkProcurementData($consignerId = null){
		$result = array();
		if(!empty($consignerId)) {
			$bulkProcurement = $this->_bulkprocurementCollectionFactory->create();
			$bulkProcurementData = $bulkProcurement->addFieldToFilter('customer_id', ['eq' => $consignerId])
                                ->addFieldToFilter("procurement_user_id", ['eq'=> $this->_helper->isUserLoggedin()])
                    ->addFieldToFilter("status_id", ['eq'=> \Ziffity\BulkProcurement\Helper\Data::PROCUREMENT_DRAFT]);
			$result = $bulkProcurementData->getData();
		}
		return $result;
	}
    public function getCustomerId(){
       $id= $this->_helper->getBulkCustomerId();
       return $id;
    }
    public function getMediaUrl(){
        return  $this->mediaUrl."procurement/bulk/";
    }
    public function getPlaceHolderImage() {
        return $this->mediaUrl ."catalog/product/placeholder/default/image.jpg";
    }
}