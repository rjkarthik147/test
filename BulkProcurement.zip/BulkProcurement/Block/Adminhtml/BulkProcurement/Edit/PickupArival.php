<?php

namespace Ziffity\BulkProcurement\Block\Adminhtml\BulkProcurement\Edit;

/**
 * Description of PickupArival
 *
 * @author Daiva
 */
class PickupArival extends \Magento\Backend\Block\Template {

    protected $bulkprocurementRepository;

    protected $_datePicker = null;
    protected $_select = null;

    public function __construct(

        \Ziffity\BulkProcurement\Api\BulkProcurementRepositoryInterface $subContractRepository,
        \Magento\Backend\Block\Widget\Context $context,
        \Magento\Framework\Registry $registry,
        \Ziffity\Procurement\Block\Adminhtml\Form\Date $datePicker,
        \Ziffity\Procurement\Block\Adminhtml\Form\Select $select,
        array $data = []
    ) {
        $this->bulkprocurementRepository = $subContractRepository;
        $this->_coreRegistry = $registry;
        $this->_datePicker = $datePicker;
        $this->_datePicker->setFormat("MM/dd/y");

        $this->_select = $select;
        $this->_select->setOptions([['value' => '0', 'label' => 'No'], ['value' => '1', 'label' => 'Yes']]);
        parent::__construct($context, $data);
    }

    public function getBulkProcurement() {
        $subContract = $this->_coreRegistry->registry(\Ziffity\BulkProcurement\Helper\Data::CURRENT_BULK_PROCUREMENT);
        return $subContract;
    }

    public function getArrivedDateHtml() {
        $this->_datePicker->setCustId('procurement-arrived-date');
        $this->_datePicker->setCustName('arrived_date');
        return $this->_datePicker->getElementHtml();
    }

    public function getIsArrivedHtml() {
        $this->_select->setCustId('procurement-is-arrived');
        $this->_select->setCustName('is_arrived');
        $this->_select->setValue($this->getIsProdcutArrived());
        return $this->_select->getElementHtml();
    }

    public function isPickupScheduledHtml() {
        $this->_select->setCustId('procurement-is-pickup-schedule');
        $this->_select->setCustName('is_scheduled');
        $this->_select->setValue($this->isPickupScheduled());
        return $this->_select->getElementHtml();
    }

    public function getIsProdcutArrived() {
        return $this->getBulkProcurement()->isProductArrived();
    }

    public function getProdcutArrivedDetails() {
        return $this->convertToTimeZone($this->getBulkProcurement()->getArrivedDate());
    }
    public function getPickupDate($farmat = 'Y-m-d H:i:s A'){
        $dateString =$this->getBulkProcurement()->getPickupDate() ."".$this->getBulkProcurement()->getPickupTimeFrom();
        $date = $this->_localeDate->date(new \DateTime($dateString));
        if (!$this->_localeDate->getConfigTimezone('store', $this->getStore())) {
            $date = new \DateTime($dateString);
        }
        return $date->format($farmat)." - ".$date->format("H:i:s A");
    }

    protected function convertToTimeZone($dateString, $farmat = 'Y-m-d H:i:s A')
    {
        $date = $this->_localeDate->date(new \DateTime($dateString));
        if (!$this->_localeDate->getConfigTimezone('store', $this->getStore())) {
            $date = new \DateTime($dateString);
        }
        return $date->format($farmat);
    }

    public function isPickupScheduled() {
        return $this->getBulkProcurement()->isScheduled();
    }

}