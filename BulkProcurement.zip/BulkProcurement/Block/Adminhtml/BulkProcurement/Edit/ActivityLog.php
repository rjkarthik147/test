<?php

namespace Ziffity\BulkProcurement\Block\Adminhtml\BulkProcurement\Edit;

/**
 * Description of ActivityLog
 *
 * @author Daiva
 */
class ActivityLog extends \Magento\Backend\Block\Template {

  
    protected $_activityLogCollection;
    protected $helper;
    public function __construct(\Ziffity\Procurement\Helper\Data $helper,
            \Ziffity\BulkProcurement\Model\ResourceModel\ActivityLog\CollectionFactory  $activityLogCollectionFactory,
            \Ziffity\BulkProcurement\Api\BulkProcurementRepositoryInterface $bulkprocurementRepository,
            \Magento\Backend\Block\Widget\Context $context,
            \Magento\Framework\Registry $registry, array $data = []
    ) {
        $this->_coreRegistry         = $registry;
        $this->helper                = $helper;
        $this->bulkprocurementRepository= $bulkprocurementRepository;
        $this->_activityLogCollection= $activityLogCollectionFactory->create();
        parent::__construct($context, $data);
    }

    public function getSubContract() {
        $bulkprocurement = $this->_coreRegistry->registry(\Ziffity\BulkProcurement\Helper\Data::CURRENT_BULK_PROCUREMENT);
        return $bulkprocurement;
    }

    public function getActivityLogCollection() {
        
        $id=$this->getSubContract()->getId();
          return $this->_activityLogCollection
                  ->addFieldToFilter('entity_id', $id );
    }
    public function getLogDate($date){
        return $this->helper->convertToTimeZone($date);
    }

}
