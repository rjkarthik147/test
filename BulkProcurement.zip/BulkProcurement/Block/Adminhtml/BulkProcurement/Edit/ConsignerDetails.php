<?php

namespace Ziffity\BulkProcurement\Block\Adminhtml\BulkProcurement\Edit;

/**
 * Description of ConsignerDetails
 *
 * @author Daiva
 */
class ConsignerDetails extends \Magento\Backend\Block\Template
{
    protected $_customerRepository = null;
    protected $_consigner          = null;
    protected $_coreRegistry;
    protected $helper;

    public function __construct(
    \Ziffity\Procurement\Helper\Data $helper,
    \Magento\Customer\Api\CustomerRepositoryInterface $customerRepository,
    \Magento\Backend\Block\Widget\Context $context,
    \Magento\Framework\Registry $registry, array $data = []
    )
    {
        $this->helper              = $helper;
        $this->_customerRepository = $customerRepository;
        $this->_coreRegistry       = $registry;
        parent::__construct($context, $data);
    }

    public function getBulkProcurementStatus($id)
    {

        $key = array_search($id,
            array_column(\Ziffity\BulkProcurement\Helper\Data::$procuremetStatus, 'value'));
        return \Ziffity\BulkProcurement\Helper\Data::$procuremetStatus[$key]['label'];
    }

    public function getBulkProcurement()
    {

        $subContract = $this->_coreRegistry->registry(\Ziffity\BulkProcurement\Helper\Data::CURRENT_BULK_PROCUREMENT);
        return $subContract;
    }

    public function getHelper()
    {
        return $this->helper;
    }

    public function getConsigner()
    {
        $customerId = $this->getBulkProcurement()->getCustomerId();
        return $this->_customerRepository->getById($customerId);
        ;
    }

    public function getConsignerAddress()
    {
        $address = $this->getConsigner()->getAddresses();
        foreach ($address as $add) {
            if ($add->isDefaultShipping()) {
                return $add;
            }
        }
    }

    public function getConsignerMobile()
    {
        if ($this->getConsigner()->getCustomAttribute("mobile") != null) {
            return $this->getConsigner()->getCustomAttribute("mobile")->getValue();
        } else {
            return "";
        }
    }
}