<?php

namespace Ziffity\BulkProcurement\Block\Adminhtml\BulkProcurement\Edit;

/**
 * Adminhtml attachment edit form block
 *
 */
class Form extends \Magento\Backend\Block\Widget\Form\Generic
{
    

    /**
     * custom template
     */
     protected $_template = 'Ziffity_BulkProcurement::bulkprocurement/form.phtml';

 

    public function getSaveUrl()
    {
         $bulkprocurement=$this->_coreRegistry->registry(\Ziffity\BulkProcurement\Helper\Data::CURRENT_BULK_PROCUREMENT);
        return $this->getUrl('bulkprocurement/*/save',['id' => $bulkprocurement->getId()]);
    }
    
    
}
