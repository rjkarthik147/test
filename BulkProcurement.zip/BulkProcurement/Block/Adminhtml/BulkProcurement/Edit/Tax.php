<?php

namespace Ziffity\BulkProcurement\Block\Adminhtml\BulkProcurement\Edit;


/**
 * Description of Tax
 *
 * @author Daiva
 */
class Tax extends \Magento\Backend\Block\Template
{
    
    protected $_philanthropicCollection;

    protected $_incomebracketsCollection;
    protected $_filersCollection;
    protected $jsonEncoder;
    protected $_historyCollection;
    protected $bulkprocurementItemsFactory;
    public function __construct(
                                \Ziffity\BulkProcurement\Model\ResourceModel\BulkProcurementItem\CollectionFactory $bulkprocurementItemsFactory,
                                \Magento\Framework\Json\EncoderInterface $jsonEncoder,
                                \Ziffity\Procurement\Model\ResourceModel\Taxfilers\CollectionFactory $filersCollectionFactory,
                                \Ziffity\Procurement\Model\ResourceModel\Incomebrackets\CollectionFactory $incomebracketsCollectionFactory,
                                \Ziffity\Procurement\Model\ResourceModel\Philanthropic\CollectionFactory $philanthropicCollectionFactory,
                                \Magento\Backend\Block\Widget\Context $context,
                                \Magento\Framework\Registry $registry,
                                array $data = []
    )
    {
        $this->_incomebracketsCollection = $incomebracketsCollectionFactory->create();
         $this->bulkprocurementItemsFactory  = $bulkprocurementItemsFactory;
        $this->_filersCollection         = $filersCollectionFactory->create();
        $this->_coreRegistry             = $registry;
        $this->jsonEncoder               = $jsonEncoder;
        $this->_philanthropicCollection  = $philanthropicCollectionFactory->create();
        parent::__construct($context, $data);
    }


    public function getPhilanthropicOrgs()
    {

        $disabled = "";
        if (!$this->isEditable()) $disabled = "disabled";

        $html = "<select ".$disabled." class='admin__control-select required-entry _required' id='philanthropic_id' name='philanthropic_id'>";
        $pid  = $this->getBulkProcurement()->getPhilanthropicId();
        foreach ($this->_philanthropicCollection as $org) {
            $sel  = "";
            if ($pid == $org->getData('entity_id')) $sel  = "selected";
            $html .= "<option ".$sel." value='".$org->getData('entity_id')."'>".$org->getData('name')."</oprion>";
        }

        $html .= "</select>";
        return $html;
    }

    public function getFilerstypes()
    {

        $disabled = "";
        if (!$this->isEditable()) $disabled = "disabled";

        $html = "<select ".$disabled." class='admin__control-select required-entry _required' id='filers_type_id' name='filers_type_id'>";
        $fid  = $this->getBulkProcurement()->getFilersTypeId();
        foreach ($this->_filersCollection as $item) {
            $sel = "";
            if ($fid == $item->getData('filers_type_id')) $sel = "selected";

            $html .= "<option ".$sel." value='".$item->getData('filers_type_id')."'>".$item->getData('name')."</oprion>";
        }

        $html .= "</select>";
        return $html;
    }

    public function getTaxableBracketsSelect()
    {

        $disabled = "";
        if (!$this->isEditable()) $disabled = "disabled";

        $html = "<select ".$disabled." class='admin__control-select required-entry _required' id='taxable_income_brackets_id' name='taxable_income_brackets_id'>";

        $html .= "</select>";
        return $html;
    }

    public function getTaxableBrackets()
    {

        return $this->jsonEncoder->encode($this->_incomebracketsCollection->getData());
    }


    public function getBulkProcurement()
    {     
        $subContract = $this->_coreRegistry->registry(\Ziffity\BulkProcurement\Helper\Data::CURRENT_BULK_PROCUREMENT);
        return $subContract;
    }
    


    public function isEditable()
    {
        $bulkprocurementItems = $this->bulkprocurementItemsFactory->create();
        $bulkprocurementItems->addFieldToFilter('entity_id',
                ['eq' => $this->getBulkProcurement()->getId()])
            ->addFieldToFilter('type_id', ['in' => [1, 2]]);
        ;
        if ($bulkprocurementItems->getSize() > 0) {
            return true;
        } else {
            return false;
        }
    }
}