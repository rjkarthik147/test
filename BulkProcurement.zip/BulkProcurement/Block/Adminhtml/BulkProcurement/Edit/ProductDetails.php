<?php

namespace Ziffity\BulkProcurement\Block\Adminhtml\BulkProcurement\Edit;

/**
 * Description of ProductDetails
 *
 * @author Daiva
 */
class ProductDetails extends \Magento\Backend\Block\Template
{
    protected $helper;
    protected $_coreRegistry;
    protected $bulkprocurementItemsFactory;
    protected $bulkprocurementProcurementTypesFactory;
    protected $procurementQualitiesFactory;
    protected $procurementSizesFactory;
    protected $procurementTypesFactory;
    protected $jsonEncoder;
    protected $productCodesFactory;
    protected $procurementConditionsFactory;
    protected $procurementPricesFactory;
    protected $filesystem;
    protected $imageFactory;
    protected $storeManager;

    public function __construct(
    \Ziffity\Procurement\Helper\Data $helper,
    \Ziffity\Procurement\Model\ResourceModel\ProcurementPrice\CollectionFactory $procurementPricesFactory,
    \Ziffity\Procurement\Model\ResourceModel\ProcurementCondition\CollectionFactory $procurementConditionsFactory,
    \Ziffity\BulkProcurement\Model\ResourceModel\ProductCode\CollectionFactory $productCodesFactory,
    \Magento\Framework\Json\EncoderInterface $jsonEncoder,
    \Ziffity\Procurement\Model\ResourceModel\ProcurementType\CollectionFactory $procurementTypesFactory,
    \Ziffity\Procurement\Model\ResourceModel\ProcurementQuality\CollectionFactory $procurementQualitiesFactory,
    \Ziffity\Procurement\Model\ResourceModel\ProcurementSize\CollectionFactory $procurementSizesFactory,
    \Ziffity\BulkProcurement\Model\ResourceModel\BulkProcurementItem\CollectionFactory $bulkprocurementItemsFactory,
    \Magento\Backend\Block\Widget\Context $context,
    \Magento\Framework\Image\AdapterFactory $imageFactory,
    \Magento\Framework\Registry $registry, array $data = []
    )
    {
        $this->_coreRegistry                = $registry;
        $this->filesystem                   = $context->getFilesystem();
        $this->storeManager                 = $context->getStoreManager();
        $this->imageFactory                 = $imageFactory;
        $this->helper                       = $helper;
        $this->procurementTypesFactory      = $procurementTypesFactory;
        $this->bulkprocurementItemsFactory  = $bulkprocurementItemsFactory;
        $this->procurementQualitiesFactory  = $procurementQualitiesFactory;
        $this->procurementSizesFactory      = $procurementSizesFactory;
        $this->jsonEncoder                  = $jsonEncoder;
        $this->productCodesFactory          = $productCodesFactory;
        $this->procurementConditionsFactory = $procurementConditionsFactory;
        $this->procurementPricesFactory     = $procurementPricesFactory;
        parent::__construct($context, $data);
    }

    public function getBulkProcurement()
    {
        $bulkprocurement = $this->_coreRegistry->registry(\Ziffity\BulkProcurement\Helper\Data::CURRENT_BULK_PROCUREMENT);
        return $bulkprocurement;
    }

    public function getProcurementConditions()
    {

        $procurementConditions = $this->procurementConditionsFactory->create();
        $result                = [];

        foreach ($procurementConditions as $procurementCondition) {

            $result [] = [
                'quality' => $procurementCondition->getProcurementQualityId(),
                'type' => $procurementCondition->getCleanoutProcurementTypeId(),
                'is_brand' => $procurementCondition->getIsBrand(),
                'selling_price_percent' => $procurementCondition->getSellingPricePercent()];
        }

        return $this->jsonEncoder->encode($result);
    }

    public function getProcurementPrices()
    {

        $procurementPrices = $this->procurementPricesFactory->create();
        $result            = [];

        foreach ($procurementPrices as $procurementPrice) {

            $result [] = [
                'category_id' => $procurementPrice->getCategoryId(),
                'type' => $procurementPrice->getCleanoutProcurementTypeId(),
                'is_brand' => $procurementPrice->getIsBrand(),
                'size' => $procurementPrice->getProcurementSizeId(),
                'procurement_selling_price' => $procurementPrice->getProcurementSellingPrice()
            ];
        }

        return $this->jsonEncoder->encode($result);
    }

    public function getBulkProcurementItems()
    {
        $bulkprocurementItems = $this->bulkprocurementItemsFactory->create();
        $bulkprocurementItems->addFieldToFilter('entity_id',
            ['eq' => $this->getBulkProcurement()->getId()]);
        $result               = [];

        foreach ($bulkprocurementItems as $item) {

            $result [] = ['itemId' => $item->getId(),
                'selectedCode' => $item->getCategoryId(),
                'selectedSize' => $item->getProcurementSizeId(),
                'selectedType' => $item->getTypeId(),
                'name' => $item->getProductName(),
                'selectedQuality' => $item->getProcurementQualityId(),
                'qty' => $item->getQty(),
                'isBrand' => $item->getIsBrand(),
                 'recommanedPrice' => number_format($item->getRecommendedPrice(),2,'.',''),
                'isRecommanedPriceOverride' => $item->getIsRecommendedPriceOverridden(),
                'overriddenRecommendedPrice' => number_format($item->getOverriddenRecommendedPrice(),2,'.',''),
                'retailPrice' => number_format($item->getRetailPrice(),2,'.',''),
                'isRetailPriceOverride' => $item->getIsRetailPriceOverridden(),
                'overriddenRetailPrice' => number_format($item->getOverriddenRetailPrice(),2,'.',''),
                'sellIndividually' => $item->getSellIndividually(),
                'sku' => $item->getSku(),
                'imageUrl' => $this->getProductImage($item)
            ];
        }


        return $this->jsonEncoder->encode($result);
    }

     protected function getMediaUrl()
    {

        return $this->storeManager ->getStore()->getBaseUrl(\Magento\Framework\UrlInterface::URL_TYPE_MEDIA);
    }

    public function getConfig($config_path)
    {
            return $this->storeManager->getStore()->getConfig($config_path);
    }

    protected function getImageUrl($item)
    {
        $imageSrc = $this->getMediaUrl()."procurement/bulk/".$item->getImage();

        return $imageSrc;
    }

    public function getProductImage($item)
    {

        if(!$item->getImage()){
            return  $this->getMediaUrl().'catalog/product/placeholder/'.$this->getConfig("catalog/placeholder/thumbnail_placeholder");
        }
        $imageSrc = $this->getImageUrl($item);
       return $imageSrc;
        try {
            $absolutePath = $imageSrc;
            $image        = new \Imagick($imageSrc);
            $orientaion   = $image->getimageorientation();

            $imageResized = $this->filesystem->getDirectoryRead(\Magento\Framework\App\Filesystem\DirectoryList::MEDIA)->getAbsolutePath('procurement/bulk/resized/'.$item->getId()).$item->getImage();
            //create image factory...
            $imageResize  = $this->imageFactory->create();
            $imageResize->open($absolutePath);
            $imageResize->constrainOnly(TRUE);
            $imageResize->keepTransparency(TRUE);
            $imageResize->keepFrame(FALSE);
            $imageResize->keepAspectRatio(TRUE);
            switch ($orientaion) {
                case $image::ORIENTATION_BOTTOMRIGHT:
                    //$imageResize->rotate(180); // rotate 180 degrees
                    break;

                case $image::ORIENTATION_RIGHTTOP:
                    $imageResize->rotate(270); // rotate 270 degrees CW
                    break;

                case $image::ORIENTATION_LEFTBOTTOM:
                    //$imageResize->rotate(-90); // rotate 90 degrees CCW
                    break;
            }
            //  $imageResize->resize(250,250);
            //destination folder
            $destination = $imageResized;
            //save image
            $imageResize->save($destination);

            $resizedURL = $this->_storeManager->getStore()->getBaseUrl(\Magento\Framework\UrlInterface::URL_TYPE_MEDIA)."procurement/bulk/resized/".$item->getId().$item->getImage();
            return $resizedURL;
        } catch (\Exception $e) {

            return $imageSrc;
        }
    }

    public function getBulkProcurementProcurementTypes()
    {
        $bulkprocurementProcurementTypes = $this->bulkprocurementProcurementTypesFactory->create();
        return $bulkprocurementProcurementTypes;
    }

    public function getProcurementQualities()
    {
        $procurementQualities = $this->procurementQualitiesFactory->create();

        $result = [];

        foreach ($procurementQualities as $quality) {

            $result [] = ['value' => $quality->getId(), 'label' => $quality->getQuality()];
        }

        return $this->jsonEncoder->encode($result);
    }

    public function getBrandOptions()
    {

        $result = [];

        $result [] = ['value' => 0, 'label' => "No Brand"];
        $result [] = ['value' => 1, 'label' => "Fine Furnishing"];

        return $this->jsonEncoder->encode($result);
    }

    public function getYesNoOptions()
    {

        $result = [];

        $result [] = ['value' => 0, 'label' => "No"];
        $result [] = ['value' => 1, 'label' => "Yes"];


        return $this->jsonEncoder->encode($result);
    }

    public function getProcurementSizes()
    {
        $procurementSizes = $this->procurementSizesFactory->create();

        $result = [];

        foreach ($procurementSizes as $procurementSize) {

            $result [] = ['value' => $procurementSize->getId(),
                'label' => $procurementSize->getSize()];
        }

        return $this->jsonEncoder->encode($result);
    }

    public function getCategoriesCollection()
    {
        $productCodes = $this->productCodesFactory->create();

        $result = [];
        foreach ($productCodes as $productCode) {

            $result [] = ['value' => $productCode->getCategoryId(),
                'label' => $productCode->getLabel()];
        }

        return $this->jsonEncoder->encode($result);
    }

    public function getBulkProcurementTypes()
    {
        $bulkprocurementTypes = $this->procurementTypesFactory->create();
        $bulkprocurementTypes->addFieldToFilter('used_for_bulk', ['eq' => 1]);
        $result               = [];

        foreach ($bulkprocurementTypes as $bulkprocurementType) {

            $result [] = ['value' => $bulkprocurementType->getId(),
                'label' => $bulkprocurementType->getValue()];
        }

        return $this->jsonEncoder->encode($result);
    }
}