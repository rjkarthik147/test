<?php

namespace Ziffity\BulkProcurement\Block\Adminhtml\BulkProcurement;

use Magento\Backend\Block\Template;

use Ziffity\BulkProcurement\Api\BulkProcurementRepositoryInterface;
use Ziffity\BulkProcurement\Model\ResourceModel\BulkProcurementItem\CollectionFactory;

class Printlabel extends Template
{
    protected $bulkprocurementItemsFactory;
    protected $bulkProcurementRepository;
    public function __construct(

            BulkProcurementRepositoryInterface $bulkProcurementRepository,
           CollectionFactory $bulkprocurementItemsFactory,
            \Magento\Backend\Block\Widget\Context $context,
            array $data = []
    ) {
        $this->bulkprocurementItemsFactory = $bulkprocurementItemsFactory;
        $this->bulkProcurementRepository   = $bulkProcurementRepository;
        parent::__construct($context, $data);
    }

    
    public function greet()
    {
        $id  = $this->getRequest()->getParam('id');

        $bulkProcurement      = $this->bulkProcurementRepository->getById($id);
        $bulkprocurementItems = $this->bulkprocurementItemsFactory->create();
        $bulkprocurementItems->addFieldToFilter('entity_id', ['eq' => $id]);
        return $bulkprocurementItems;

    }


}
