<?php

namespace Ziffity\BulkProcurement\Block\Adminhtml\ProductCode\Edit;

class Form extends \Magento\Backend\Block\Widget\Form\Generic
{
	protected $productCodeCollectionfactory;
	protected $_categories;

	/**
	* Custom Template 
	*/
	protected $_template = 'Ziffity_BulkProcurement::productcode/form.html';

	public function __construct(
			\Magento\Backend\Block\Template\Context $context,
			\Magento\Framework\Registry $registry,
			\Magento\Framework\Data\FormFactory $formFactory,
			\Ziffity\BulkProcurement\Model\ResourceModel\ProductCode\CollectionFactory $productCodeCollectionfactory,
			\Magento\Catalog\Model\ResourceModel\Category\CollectionFactory $categories,
			array $data = []
	)
	{
		$this->productCodeCollectionfactory = $productCodeCollectionfactory;
		$this->_categories = $categories;
		parent::__construct($context, $registry, $formFactory, $data);
	}

	/**
	* Get Url for save
	*/
	public function getsaveUrl()
	{
		return $this->getUrl('bulkprocurement/*/save');
	}

	/**
	* Get Collection Details for the edit form
	*/
	public function getProductCodeCollectiondetail()
	{
		$result = array();
		$id = $this->getId();
		$collectionData = $this->productCodeCollectionfactory->create()->addFieldToFilter('id', array('eq' => $id))->getData();
		if(count($collectionData) > 0) {
			$result = $collectionData[0];
		}
		return $result;
	}

	/* category options */

    public function getCategories() {

		$categoriesArray =  $this->_categories->create()
								->addAttributeToSelect('name')
					            ->addAttributeToSort('path', 'asc')
					            ->addFieldToFilter('is_active', array('eq'=>'1'))
					            ->addFieldToFilter('children_count', array('eq' => 0))
					            ->load()
					            ->toArray();

        foreach ($categoriesArray as $categoryId => $category) {
        
	        if (isset($category['name'])) {
	            $categories[] = array(
	                'label' => $category['name'],
	                'level'  =>$category['level'],
	                'value' => $categoryId
	            );
	        }
	    }

    	return $categories;
    }

	/**
	* Get the Requested ID
	*/
	public function getId()
	{
		return $this->getRequest()->getParam('id');
	}
}