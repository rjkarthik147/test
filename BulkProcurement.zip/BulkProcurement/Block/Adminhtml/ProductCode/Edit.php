<?php

namespace Ziffity\BulkProcurement\Block\Adminhtml\ProductCode;

class Edit extends \Magento\Backend\Block\Widget\Form\Container
{
	protected $coreRegistry = null;
	protected $helper;

	public function __construct(
		\Magento\Backend\Block\Widget\Context $context,
		\Magento\Framework\Registry $registry,
		\Ziffity\BulkProcurement\Helper\Data $helper,
		array $data = []
	) {
		$this->helper = $helper;
		$this->coreRegistry = $registry;
		parent::__construct($context, $data);
	}

	/*
	* Initial edit Block
	*/
	protected function _construct()
	{
		$this->_objectId = 'id';
		$this->_objectGroup = 'Ziffity_BulkProcurement';
		$this->_controller = 'adminhtml_productcode';

		parent::_construct();

		$this->buttonList->remove('delete');
		$this->buttonList->remove('reset');

		$this->buttonList->update('save', 'label', __('Submit') );
	}

	/*
	* Getter Url for Save and Continue button
	*/
	protected function _getSaveAndContinueUrl()
	{
		return $this->getUrl('bulkprocurement/*/save');
	}

	/*
	* Retrieve Url for form submitting
	*/
	protected function getUpdateUrl()
	{
		return$this->getUrl('bulkprocurement/*/update');
	}

	/*
	* Get form Key
	* @return string
	*/
	public function getFormKey()
	{
		return $this->_formKey->getFormKey();
	}

	/*
	* Get Url for Back button
	*/
	public function getBackUrl()
	{
		return $this->getUrl('bulkprocurement/productcode/');
	}

}