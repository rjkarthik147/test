<?php

namespace Ziffity\BulkProcurement\Model;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

use Magento\Framework\Data\OptionSourceInterface;
use Ziffity\BulkProcurement\Helper\Data as Helper;
/**
 * Description of Type
 *
 * @author Daiva
 */
class BulkProcurementStatus implements OptionSourceInterface {
 

    //put your code here
    public function toOptionArray() {
        return Helper::$procuremetStatus;
    }

}
