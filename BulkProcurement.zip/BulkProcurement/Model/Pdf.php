<?php


namespace Ziffity\BulkProcurement\Model;

use Ziffity\BulkProcurement\Model\ResourceModel\BulkProcurementItem\CollectionFactory;
/**
 * Description of Pdf
 *
 * @author Daiva
 */
class Pdf
{
    public function __construct( CollectionFactory $bulkprocurementItemsFactory)
    {
        $this->bulkprocurementItemsFactory = $bulkprocurementItemsFactory;;
    }

    public function getPdf($id){
            $bulkprocurementItems = $this->bulkprocurementItemsFactory->create();
            $bulkprocurementItems->addFieldToFilter('entity_id', ['eq' => $id]);
            $pdf                  = new \Zend_Pdf();
            $page                 = $pdf->newPage(144,72);

            $font = \Zend_Pdf_Font::fontWithName(\Zend_Pdf_Font::FONT_HELVETICA);

            $i = 0;
            foreach ($bulkprocurementItems as $item) {
               
                    $page->setFont($font, 5);
                    $x = 10; //default PDF page height
                    $y = 40;
               
                //$page->drawText($item->getProductName(), $x , $y,'UTF-8');

                $this->wrapText($item->getProductName(),$page);
                $page->drawText($item->getSku(), $x, $y + 10,
                    'UTF-8');

                $i++;
              
                    $pdf->pages[] = $page;
                    $page         = $pdf->newPage(144,72);
               
                $y = $y - 250;
            }
         
            return $pdf;
    }


       protected function wrapText($text,$page)
    {
        $wrappedText = wordwrap($text, 50, "\n", false);
        $token = strtok($wrappedText, "\n");
        $yPosition = 40;
        while ($token !== false) {
            $page->drawText($token,
                    10,
                    $yPosition);
            $token = strtok("\n");
            $yPosition -= 7;
        }
    }
}