<?php

namespace Ziffity\BulkProcurement\Model;

use \Ziffity\BulkProcurement\Api\Data\BulkProcurementInterface;
use \Ziffity\BulkProcurement\Api\Data\BulkProcurementSearchResultInterfaceFactory;
use \Ziffity\BulkProcurement\Api\Data\BulkProcurementInterfaceFactory;
use Ziffity\BulkProcurement\Api\Data\BulkProcurementSearchResultInterface;
use \Ziffity\BulkProcurement\Api\BulkProcurementRepositoryInterface;
use Ziffity\BulkProcurement\Model\ResourceModel\BulkProcurement as BulkProcurementResource;
use Ziffity\BulkProcurement\Model\ResourceModel\BulkProcurement\CollectionFactory as BulkProcurementCollectionFactory;
use Magento\Framework\Api\DataObjectHelper;
use Magento\Framework\Api\SearchCriteriaInterface;
use Magento\Framework\Api\SortOrder;
use Magento\Framework\Exception\CouldNotDeleteException;
use Magento\Framework\Exception\CouldNotSaveException;
use Magento\Framework\Exception\NoSuchEntityException;
use Magento\Framework\Model\AbstractModel;
use Magento\Framework\Reflection\DataObjectProcessor;

class BulkProcurementRepository implements BulkProcurementRepositoryInterface{
   
   
    protected $resource;

    protected $cleanoutCollectionFactory;

 
    protected $searchResultsFactory;

   
    protected $dataObjectHelper;

  
    protected $dataObjectProcessor;

   
    protected $cleanoutFactory;

 
    protected $instances = [];

    
    public function __construct(
        BulkProcurementResource $resource,
        BulkProcurementCollectionFactory $cleanoutCollectionFactory,
        BulkProcurementSearchResultInterfaceFactory $searchResultsFactory,
        DataObjectHelper $dataObjectHelper,
        DataObjectProcessor $dataObjectProcessor,
        BulkProcurementInterfaceFactory $cleanoutFactory
    ) {
        $this->resource = $resource;
        $this->cleanoutCollectionFactory = $cleanoutCollectionFactory;
        $this->searchResultsFactory = $searchResultsFactory;
        $this->dataObjectHelper = $dataObjectHelper;
        $this->dataObjectProcessor = $dataObjectProcessor;
        $this->cleanoutFactory = $cleanoutFactory;
    }
    
    public function save(BulkProcurementInterface $cleanout)
    {
        if (false === ($cleanout instanceof AbstractModel)) {
            throw new CouldNotSaveException(__('Invalid Model'));
        }

        try {
            $this->resource->save($cleanout);
        } catch (\Exception $exception) {
            throw new CouldNotSaveException(__($exception->getMessage()));
        }

        return $cleanout;
    }
    public function getById($cleanoutId)
    {
        if (false === array_key_exists($cleanoutId, $this->instances)) {
          
            $cleanout = $this->cleanoutFactory->create();
            $this->resource->load($cleanout, $cleanoutId);
            if (!$cleanout->getId()) {
                throw new NoSuchEntityException(__('BulkProcurement with id "%1" does not exist.', $cleanoutId));
            }

            $this->instances[$cleanoutId] = $cleanout;
        }

        return $this->instances[$cleanoutId];
    }
    
    public function delete(BulkProcurementInterface $cleanout)
    {
        if (false === ($cleanout instanceof AbstractModel)) {
            throw new CouldNotDeleteException(__('Invalid Model'));
        }

        try {
            $this->resource->delete($cleanout);
        } catch (\Exception $exception) {
            throw new CouldNotDeleteException(__($exception->getMessage()));
        }

        return true;
    }
    public function deleteById($cleanoutId)
    {
        return $this->delete($this->getById($cleanoutId));
    }
    
    public function getList(BulkProcurementSearchResultInterface $searchCriteria)
    {
     
        $searchResults = $this->searchResultsFactory->create();
        $searchResults->setSearchCriteria($searchCriteria);

        $collection = $this->cleanoutCollectionFactory->create();

        foreach ($searchCriteria->getFilterGroups() as $filterGroup) {
            foreach ($filterGroup->getFilters() as $filter) {
                $condition = $filter->getConditionType() ?: 'eq';
                $collection->addFieldToFilter($filter->getField(), [$condition => $filter->getValue()]);
            }
        }

        $searchResults->setTotalCount($collection->getSize());
        $sortOrders = $searchCriteria->getSortOrders();

        if ($sortOrders) {
            foreach ($sortOrders as $sortOrder) {
                $collection->addOrder(
                    $sortOrder->getField(),
                    ($sortOrder->getDirection() == SortOrder::SORT_ASC) ? 'ASC' : 'DESC'
                );
            }
        }

        $collection->setCurPage($searchCriteria->getCurrentPage());
        $collection->setPageSize($searchCriteria->getPageSize());
        $cleanouts = [];
        
        foreach ($collection as $cleanoutModel) {
            $cleanout = $this->cleanoutFactory->create();
            $this->dataObjectHelper->populateWithArray(
                $cleanout,
                $cleanoutModel->getData(),
                Data\BulkProcurementInterface::class
            );

            $cleanouts[] = $this->dataObjectProcessor->buildOutputDataArray(
                $cleanout,
                Data\BulkProcurementInterface::class
            );
        }

        $searchResults->setItems($cleanouts);

        return $searchResults;
    }
    
}
