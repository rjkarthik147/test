<?php

namespace Ziffity\BulkProcurement\Model;

use \Magento\Framework\Model\AbstractModel;
use \Ziffity\BulkProcurement\Api\Data\BulkProcurementInterface;

/**
 * Description of BulkProcurement
 *
 * @author Daiva
 */
class BulkProcurement extends AbstractModel implements BulkProcurementInterface
{

    protected function _construct()
    {
        $this->_init('Ziffity\BulkProcurement\Model\ResourceModel\BulkProcurement');
    }

    public function getCreatedAt()
    {
        return $this->getData(static::CREATED_AT);
    }

    public function getId()
    {
        return $this->getData(static::CLEANOUT_ID);
    }

    public function getArrivedDate()
    {
        return $this->getData(static::ARRIVED_DATE);
    }

    public function getPhilanthropicId()
    {
        return $this->getData(static::PHILANTHROPIC_ID);
    }

    public function getPickupTimeFrom()
    {
        return $this->getData(static::PICKUP_TIME_FROM);
    }

    public function getPickupTimeTo()
    {
        return $this->getData(static::PICKUP_TIME_TO);
    }

    public function getStatus()
    {
        return $this->getData(static::STATUS_ID);
    }

    public function getStoreId()
    {
        return $this->getData(static::STORE_CODE);
    }

    public function isProductArrived()
    {
        return $this->getData(static::IS_PRODUCT_ARRIVED);
    }

    public function isScheduled()
    {
        return $this->getData(static::IS_SCHEDULED);
    }

    public function getPickupDate()
    {
        return $this->getData(static::PICKUP_DATE);
    }

    public function getCustomerId()
    {
        return $this->getData(static::CUSTOMER_ID);
    }

    public function getNumberOfItems()
    {
        return $this->getData(static::NUMBER_OF_ITEMS);
    }

    public function getStoreCode()
    {
        return $this->getData(static::STORE_CODE);
    }

    public function getFilersTypeId()
    {
        return $this->getData(static::FILERS_TYPE_ID);
    }

    public function getTaxableIncomeBracketsId()
    {
        return $this->getData(static::TAXABLE_INCOME_BRACKETS_ID);
    }

}