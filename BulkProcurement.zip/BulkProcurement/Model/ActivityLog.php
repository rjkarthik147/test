<?php

namespace Ziffity\BulkProcurement\Model;

use \Magento\Framework\Model\AbstractModel;

/**
 * Description of ActivityLog
 *
 * @author Daiva
 */
class ActivityLog extends AbstractModel
{

    protected function _construct()
    {
        $this->_init('Ziffity\BulkProcurement\Model\ResourceModel\ActivityLog');
    }
}