<?php

namespace Ziffity\BulkProcurement\Model;

use \Ziffity\BulkProcurement\Api\Data\ProductCodeInterface;
use \Ziffity\BulkProcurement\Api\Data\ProductCodeSearchResultInterfaceFactory;
use \Ziffity\BulkProcurement\Api\Data\ProductCodeInterfaceFactory;
use \Ziffity\BulkProcurement\Api\ProductCodeRepositoryInterface;
use \Ziffity\BulkProcurement\Model\ResourceModel\ProductCode as ProductCodeResource;
use \Ziffity\BulkProcurement\Model\ResourceModel\ProductCode\CollectionFactory as ProductCodeCollectionFactory;
use Magento\Framework\Api\DataObjectHelper;
use Magento\Framework\Api\SearchCriteriaInterface;
use Magento\Framework\Api\SortOrder;
use Magento\Framework\Exception\CouldNotDeleteException;
use Magento\Framework\Exception\CouldNotSaveException;
use Magento\Framework\Exception\NoSuchEntityException;
use Magento\Framework\Model\AbstractModel;
use Magento\Framework\Reflection\DataObjectProcessor;

class ProductCodeRepository implements ProductCodeRepositoryInterface {
   
    
    protected $resource;

    protected $productCodeCollectionFactory;


    protected $searchResultsFactory;

   
    protected $dataObjectHelper;

  
    protected $dataObjectProcessor;

   
    protected $productCodeFactory;

 
    protected $instances = [];

    
    public function __construct(
        ProductCodeResource $resource,
        ProductCodeCollectionFactory $productCodeCollectionFactory,
        ProductCodeSearchResultInterfaceFactory $searchResultsFactory,
        DataObjectHelper $dataObjectHelper,
        DataObjectProcessor $dataObjectProcessor,
        ProductCodeInterfaceFactory $productCodeFactory
    ) {
        $this->resource = $resource;
        $this->productCodeCollectionFactory = $productCodeCollectionFactory;
        $this->searchResultsFactory = $searchResultsFactory;
        $this->dataObjectHelper = $dataObjectHelper;
        $this->dataObjectProcessor = $dataObjectProcessor;
        $this->productCodeFactory = $productCodeFactory;
    }
    
    public function save(ProductCodeInterface $productcode)
    {
        if (false === ($productcode instanceof AbstractModel)) {
            throw new CouldNotSaveException(__('Invalid Model'));
        }

        try {
            $this->resource->save($productcode);
        } catch (\Exception $exception) {
            throw new CouldNotSaveException(__($exception->getMessage()));
        }

        return $productcode;
    }
    public function getById($productcodeId)
    {
        if (false === array_key_exists($productcodeId, $this->instances)) {
          
            $productcode = $this->productCodeFactory->create();
            $this->resource->load($productcode, $productcodeId);
            if (!$productcode->getId()) {
                throw new NoSuchEntityException(__('productcode with id "%1" does not exist.', $productcodeId));
            }

            $this->instances[$productcodeId] = $productcode;
        }

        return $this->instances[$productcodeId];
    }
    
    public function delete(ProductCodeInterface $productcode)
    {
        if (false === ($productcode instanceof AbstractModel)) {
            throw new CouldNotDeleteException(__('Invalid Model'));
        }

        try {
            $this->resource->delete($productcode);
        } catch (\Exception $exception) {
            throw new CouldNotDeleteException(__($exception->getMessage()));
        }

        return true;
    }
    public function deleteById($productcodeId)
    {
        return $this->delete($this->getById($productcodeId));
    }
    
    public function getList(SearchCriteriaInterface $searchCriteria)
    {
     
    
    }
    
}
