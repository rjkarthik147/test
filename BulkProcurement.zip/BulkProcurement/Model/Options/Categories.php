<?php

namespace Ziffity\BulkProcurement\Model\Options;

use Magento\Framework\Data\OptionSourceInterface;
use Magento\Catalog\Model\ResourceModel\Category\CollectionFactory;


/**
 * Class Categories
 */
class Categories implements OptionSourceInterface
{
    

    protected $_categories;
    /**
     * @param ContextInterface $context
     * @param UiComponentFactory $uiComponentFactory
     * @param UrlInterface $urlBuilder
     * @param array $components
     * @param array $data
     */
    public function __construct(CollectionFactory $categories    )
    {
        
        $this->_categories = $categories;

    }


    //put your code here
    public function toOptionArray()
    {
        $categories = $this->_categories->create()->addAttributeToSelect('name')
					            ->addAttributeToSort('path', 'asc')
					            ->addFieldToFilter('is_active', array('eq'=>'1'))
					            ->addFieldToFilter('children_count', array('eq' => 0))
					            ->load()
					            ->toArray();
        $result    = [];


               foreach ($categories as $categoryId => $category) {
        	
	        if (isset($category['name'])) {
	            $result[] = array(
	                'label' => $category['name'],
	                'value' => $categoryId
	            );
	        }
	    }

        return $result;
    }
}