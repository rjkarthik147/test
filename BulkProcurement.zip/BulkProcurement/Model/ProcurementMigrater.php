<?php

namespace Ziffity\BulkProcurement\Model;

use Ziffity\Procurement\Model\Procurement\Status;
use Magento\Catalog\Api\CategoryRepositoryInterface;
use Ziffity\Procurement\Model\SubContractFactory;
use Ziffity\Procurement\Model\OwneditemFactory;
use Ziffity\Procurement\Model\MasterContract;
use Ziffity\Procurement\Model\Procurement\ProcurementSource;
use Ziffity\Procurement\Model\ResourceModel\OfferCycle\CollectionFactory as OfferCycleCollectionFactory;
use Magento\Eav\Model\ResourceModel\Entity\Attribute\CollectionFactory as AttributeCollectionFactory;

/**
 * Description of ProcurementMigrater
 *
 * @author Daiva
 */
class ProcurementMigrater
{
    protected $categoryRepository;
    protected $subContractFactory;
    protected $owneditemFactory;
    protected $attributeCollectionFactory;
    protected $offerCycleCollectionFactory;
    protected $masterContract;
    protected $resource;
    public function __construct(
    AttributeCollectionFactory $attributeCollectionFactory,
    CategoryRepositoryInterface $categoryRepository,
    SubContractFactory $subContractFactory, OwneditemFactory $owneditemFactory,
    MasterContract $masterContract,
    OfferCycleCollectionFactory $offerCycleCollectionFactory,
    \Magento\Framework\App\ResourceConnection $resource)
    {
        $this->attributeCollectionFactory  = $attributeCollectionFactory;
        $this->categoryRepository          = $categoryRepository;
        $this->subContractFactory          = $subContractFactory;
        $this->owneditemFactory            = $owneditemFactory;
        $this->offerCycleCollectionFactory = $offerCycleCollectionFactory;
        $this->masterContract              = $masterContract;
        $this->resource                    = $resource;
    }

    protected function getConnection()
    {
        $connection = $this->resource->getConnection(\Magento\Framework\App\ResourceConnection::DEFAULT_CONNECTION);
        return $connection;
    }

    public function migrateAsSingleProcurement($model, $bulkProcurement)
    {

        switch ($model->getTypeId()) {
            case 1;
            case 2:
                $this->createSubContract($model, $bulkProcurement);
                break;
            case 3:
                $this->createOwnedItem($model, $bulkProcurement);
        }
    }

    public function migrateAsMultipleProcurement($model, $bulkProcurement)
    {


        switch ($model->getTypeId()) {
            case 1;
            case 2:
                $this->createMultipleSubContract($model, $bulkProcurement);
                break;
            case 3:
                $this->createMultipleOwnedItem($model, $bulkProcurement);
        }
    }

    public function createMultipleSubContract($model, $bulkProcurement)
    {

        $qty = $model->getQty();
        while ($qty) {
            $this->createSubContract($model, $bulkProcurement);
            $qty--;
        }
    }

    public function createMultipleOwnedItem($model, $bulkProcurement)
    {

        $qty = $model->getQty();
        while ($qty) {
            $this->createOwnedItem($model, $bulkProcurement);
            $qty--;
        }
    }

    public function createOwnedItem($model, $bulkProcurement)
    {
        $ownedItem=[];
        $customerId           = $bulkProcurement->getCustomerId();
        $category             = $this->categoryRepository->get($model->getCategoryId());
        $setId                = $category->getData('map_attribute');
        $productData          = $this->getProductData($model, $category, $setId);
        $connection           = $this->getConnection();
        $ownedItem['product_name']=$model->getProductName();
        $ownedItem['product_data']=serialize($productData);
        $ownedItem['attribute_set_id']=$setId;
        $ownedItem['customer_id']=$customerId;
        $ownedItem['bulk_item_id']=$model->getId();
        $ownedItem['pricing_type_id']=\Ziffity\Procurement\Controller\Constants::OWNED_PRICING_TYPE_WITH_OFFER;
        $procurementType      = $model->getTypeId();
        $ownedItem['procurement_type_id']=$procurementType;
        $ownedItem['current_procurement_type_id']=$procurementType;
        $offerCycleCollection = $this->offerCycleCollectionFactory->create();
        $offerCycleCollection->addFieldToFilter('procurement_type_id',
            ['eq' => $procurementType]);
        $offerCycleCollection->addFieldToFilter('number_of_months', ['eq' => 12]);
        
       $ownedItem['offer_cycle_id']=$offerCycleCollection->getFirstItem()->getId();
        $ownedItem['procurement_status_id']=Status::PROCUREMENT_PRODUCT_ARRIVED;
        $ownedItem['auto_increment_id']=$model->getSku();
        $ownedItem['is_brand']=$model->getIsBrand();;
        $ownedItem['size']=$model->getProcurementSizeId();;
        $ownedItem['quality']=$model->getProcurementQualityId();
        $ownedItem['source']=ProcurementSource::BULK_PROCUREMENT_ID;
        $ownedItem['arrived_date']=$bulkProcurement->getArrivedDate();
        $ownedItem['store_code']=$bulkProcurement->getStoreCode();
        $ownedItem['admin_user_id']=$bulkProcurement->getProcurementUserId();
        if ($model->getIsRecommendedPriceOverridden() == 1) {
            $ownedItem['purchase_price']=$model->getOverriddenRecommendedPrice();
        } else {
             $ownedItem['purchase_price']=$model->getRecommendedPrice();
        }
        if ($model->getIsRetailPriceOverridden() == 1) {
            $ownedItem['sale_price']=$model->getOverriddenRetailPrice();
        } else {
            $ownedItem['sale_price']=$model->getRetailPrice();
        }
        $connection->insert('procurement_owned',$ownedItem);
       

        $sql = "UPDATE ".$connection->getTableName('procurement_owned')." po
                SET  po.entity_id = CONCAT('O - ', procurement_owned_id)
            WHERE  po.auto_increment_id = ?";
                $connection->query($sql,
                    array($model->getSku()));

    }

    public function createSubContract($model, $bulkProcurement)
    {

        $subContract=[];
        $this->masterContract->getByConsignerId($bulkProcurement->getCustomerId());
        $masterContractId = $this->masterContract->getId();
        $category         = $this->categoryRepository->get($model->getCategoryId());
        $setId            = $category->getData('map_attribute');
        $productData      = $this->getProductData($model, $category, $setId);
        $connection           = $this->getConnection();
        $subContract['product_name']=$model->getProductName();
        $subContract['product_data']=serialize($productData);
        $subContract['attribute_set_id']=$setId;
        $subContract['bulk_item_id']=$model->getId();
        $subContract['master_contract_id']=$masterContractId;
        $subContract['philanthropic_id']=$bulkProcurement->getPhilanthropicId();
        $procurementType  = $model->getTypeId();
        $subContract['pricing_type_id']=\Ziffity\Procurement\Controller\Constants::PRICING_TYPE_WITH_OFFER;
        $subContract['procurement_type_id']=$procurementType;
        $subContract['current_procurement_type_id']=$procurementType;

        $offerCycleCollection = $this->offerCycleCollectionFactory->create();
        $offerCycleCollection->addFieldToFilter('procurement_type_id',
            ['eq' => $procurementType]);
      
        $period = \Ziffity\Cleanout\Helper\Data::$offerCycleId[$procurementType][$model->getIsBrand()];
       
        $offerCycleCollection->addFieldToFilter('number_of_months', ['eq' => $period]);
        $subContract['offer_cycle_id']=$offerCycleCollection->getFirstItem()->getId();
        $subContract['procurement_status_id']=Status::PROCUREMENT_PRODUCT_ARRIVED;
        $subContract['taxable_income_brackets_id']=$bulkProcurement->getTaxableIncomeBracketsId();
        $subContract['filers_type_id']=$bulkProcurement->getFilersTypeId();
        $subContract['auto_increment_id']=$model->getSku();
        $subContract['is_brand']=$model->getIsBrand();;
        $subContract['size']=$model->getProcurementSizeId();;
        $subContract['quality']=$model->getProcurementQualityId();
        $subContract['source']=ProcurementSource::BULK_PROCUREMENT_ID;
        $subContract['arrived_date']=$bulkProcurement->getArrivedDate();
        if ($model->getIsRetailPriceOverridden() == 1) {
            $subContract['consinged_price']=$model->getOverriddenRetailPrice();
            $subContract['list_price']=$model->getOverriddenRetailPrice();
        } else {
            $subContract['consinged_price']=$model->getRetailPrice();
            $subContract['list_price']=$model->getRetailPrice();
        }
        if ($model->getIsRecommendedPriceOverridden() == 1) {
            $subContract['estimated_apprisal_value']=$model->getOverriddenRecommendedPrice();
       } else {
            $subContract['estimated_apprisal_value']=$model->getRecommendedPrice();
        }
        $subContract['store_code']=$bulkProcurement->getStoreCode();
        $subContract['admin_user_id']=$bulkProcurement->getProcurementUserId();
        $connection->insert('procurement_sub_contracts',$subContract);
  
        $sql = "UPDATE ".$connection->getTableName('procurement_sub_contracts')." sc
                SET  sc.entity_id = CONCAT_WS(' - ', master_contract_id,sub_contract_id)
            WHERE  sc.auto_increment_id = ?";
                $connection->query($sql,
                    array($model->getSku()));
    }

    public function getProductData($model, $category, $setId)
    {


        $parentIds = $category->getParentIds();
        $parentIds = array_slice($parentIds, 3);

        $productData = [];
        if (isset($parentIds[0])) {
            $productData[] = array('label' => 'Category', 'frontend_input' => 'category',
                'attribute_code' => 'category', 'value' => $parentIds[0]);
        }
        if (isset($parentIds[1])) {
            $productData[] = array('label' => 'Sub Category', 'frontend_input' => 'category',
                'attribute_code' => 'sub_category', 'value' => $parentIds[1]);
            $productData[] = array('label' => 'Sub Category2', 'frontend_input' => 'category',
                'attribute_code' => 'sub_category1', 'value' => $model->getCategoryId());
        } else {
            $productData[] = array('label' => 'Sub Category', 'frontend_input' => 'category',
                'attribute_code' => 'sub_category', 'value' => $model->getCategoryId());
        }


        $productData[] = ['label' => 'Product Name', 'frontend_input' => 'text',
            'attribute_code' => 'product_name', 'value' => $model->getProductName()];
        /*  $productData[] = ['label' => 'Original Purchase Date', 'frontend_input' => 'date',
          'attribute_code' => 'original_purchase_date', 'value' => '']; */

        $productData[] = ['label' => 'Description', 'frontend_input' => 'textarea',
            'attribute_code' => 'short_description', 'value' => ''];
        $productData[] = ['label' => 'Quantity', 'frontend_input' => 'text',
            'attribute_code' => 'consigned_qty', 'value' => 1];


        $attributeCollection = $this->attributeCollectionFactory->create();
        $attributeCollection->setAttributeSetFilter($setId);
        $attributeCollection->addFieldToFilter('is_user_defined', ['eq' => 1])
            ->addFieldToFilter('attribute_code', ['nin' => ['original_price','tolerance_percentage','cost','consigned_qty']]);
        $dimesions           = [];
        $upcycle             = [];

        foreach ($attributeCollection as $attribute) {

            $code = $attribute->getData('attribute_code');
            if ($this->isDimesions($code)) {
                $dimesions[] = $this->processAttribute($attribute);
                continue;
            }
            if ($this->isUpcycle($code)) {
                $upcycle[] = $this->processAttribute($attribute);
                continue;
            }
            $productData[] = $this->processAttribute($attribute);
        }
        if (count($dimesions) > 0) {
            $productData[] = array('label' => 'Dimension', "frontend_input" => "group",
                "attribute_code" => "dimension", 'value' => $dimesions);
        }
        if (count($upcycle) > 0) {
            $productData[] = array('label' => 'Upcycle', "frontend_input" => "group",
                "attribute_code" => "upcycle", 'value' => $upcycle);
        }
        $productData[] = array('label' => 'Image', 'frontend_input' => 'image', 'attribute_code' => 'image',
            'value' => $model->getImage());
        return $productData;
    }

    protected function isDimesions($code)
    {
        return in_array($code, ['height', 'width', 'procure_weight', 'length']);
    }

    protected function isUpcycle($code)
    {
        return in_array($code, ['paint', 'upholstery']);
    }

    protected function processAttribute($attribute)
    {
        $val = ucwords(implode(" ",
                explode("_", $attribute->getData('attribute_code'))));
        if (strpos($val, 'Weight')){
            $val="Weight";
        }
        return ['label' => $val, 'frontend_input' => $attribute->getData('frontend_input'),
            'attribute_code' => $attribute->getData('attribute_code'), 'value' => ''];
    }
}