<?php

namespace Ziffity\BulkProcurement\Model;

/**
 * Description of Printbarcode
 *
 * @author Rajasekar Senguttuvan
 */
class Printbarcode
{
    private $bulkitemsFactory;

    public function __construct(
    \Ziffity\BulkProcurement\Model\ResourceModel\BulkProcurementItem\CollectionFactory $bulkitemsFactory)
    {
        $this->bulkitemsFactory = $bulkitemsFactory;
    }

    public function drawPdf($bulkProcurementId)
    {
        $pdf             = new \Zend_Pdf();
        \Zend_Barcode::setBarcodeFont(__DIR__.'/Fonts/LinLibertineC_Re-2.8.0.ttf');
        $i               = 1;
        $rendererOptions = array('leftOffset' => 13, 'topOffset' => 1);
        $bulkItems       = $this->bulkitemsFactory->create();
        $bulkItems->addFieldToFilter('entity_id', ['eq' => $bulkProcurementId]);

        if ($bulkItems->getSize() <= 0) {
            echo "Sorry No Result Found";
            exit;
        }
        foreach ($bulkItems as $item) {
            $text           = $item->getSku();
            $name           = $item->getProductName();
            $text           = substr($text, 0, -1);
            $pdf->pages[$i] = $pdf->newPage('144:72')
                ->setFont(\Zend_Pdf_Font::fontWithName(\Zend_Pdf_Font::FONT_HELVETICA),
                    8)
                ->drawText($name, (50 - strlen($name)), 2);

            $barcodeOptions = array('text' => $text, 'barHeight' => 50, 'factor' => 2);
            $pdfWithBarcode = \Zend_Barcode::factory('upca', 'pdf',
                    $barcodeOptions, $rendererOptions);
            $pdfWithBarcode->setResource($pdf, $i)->draw();
            $i++;
        }
        $pdfWithBarcode->render();
    }
}