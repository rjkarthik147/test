<?php

namespace Ziffity\BulkProcurement\Model;

use \Magento\Framework\Model\AbstractModel;

/**
 * Description of BulkProcurementItem
 *
 * @author Daiva
 */
class BulkProcurementItem extends AbstractModel
{

    protected function _construct()
    {
        $this->_init('Ziffity\BulkProcurement\Model\ResourceModel\BulkProcurementItem');
    }
}