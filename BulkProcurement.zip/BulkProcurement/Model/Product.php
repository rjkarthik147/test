<?php

namespace Ziffity\BulkProcurement\Model;

use Magento\Catalog\Api\ProductRepositoryInterface;
use Magento\Catalog\Model\ProductFactory;
use Ziffity\Procurement\Model\Procurement\Status;
use Magento\Catalog\Api\CategoryRepositoryInterface;
use Ziffity\Procurement\Model\SubContractFactory;
use Ziffity\Procurement\Model\OwneditemFactory;
use Ziffity\Procurement\Model\MasterContract;
use Wyomind\AdvancedInventory\Api\StockRepositoryInterface;
use Ziffity\Procurement\Model\Procurement\ProcurementSource;
use Ziffity\Procurement\Model\ResourceModel\OfferCycle\CollectionFactory as OfferCycleCollectionFactory;
use Magento\Eav\Model\ResourceModel\Entity\Attribute\CollectionFactory as AttributeCollectionFactory;

/**
 * Description of Product
 *
 * @author Daiva
 */
class Product
{
    protected $categoryRepository;
    protected $subContractFactory;
    protected $owneditemFactory;
    protected $attributeCollectionFactory;
    protected $offerCycleCollectionFactory;
    protected $masterContract;
    protected $resource;
    private $productFactory;
    private $productRepository;
    private $stoctRepository;

    public function __construct(ProductFactory $productFactory,
                                ProductRepositoryInterface $productRepository,
                                AttributeCollectionFactory $attributeCollectionFactory,
                                CategoryRepositoryInterface $categoryRepository,
                                SubContractFactory $subContractFactory,
                                OwneditemFactory $owneditemFactory,
                                MasterContract $masterContract,
                                StockRepositoryInterface $stockRepository,
                                OfferCycleCollectionFactory $offerCycleCollectionFactory,
                                \Magento\Framework\App\ResourceConnection $resource)
    {
        $this->attributeCollectionFactory  = $attributeCollectionFactory;
        $this->categoryRepository          = $categoryRepository;
        $this->subContractFactory          = $subContractFactory;
        $this->owneditemFactory            = $owneditemFactory;
        $this->offerCycleCollectionFactory = $offerCycleCollectionFactory;
        $this->masterContract              = $masterContract;
        $this->resource                    = $resource;
        $this->stoctRepository             = $stockRepository;
        $this->productFactory              = $productFactory;
        $this->productRepository           = $productRepository;
    }

    protected function getConnection()
    {
        $connection = $this->resource->getConnection(\Magento\Framework\App\ResourceConnection::DEFAULT_CONNECTION);
        return $connection;
    }


    private function updateProduct($productId,$data, $category){
        
        $parentIds   = $category->getParentIds();
        $categoryIds = array_slice($parentIds, 3);
        $categoryIds[]=$category->getId();
        
        $price       = round($this->getProductPrice($data));
        $product=$this->productRepository->getById($productId,true,0);
         $product->setSku($data['sku']); // Set your sku here
        $product->setName($data['product_name']); // Name of Product
        $product->setAttributeSetId($category->getData('map_attribute')); // Attribute set id
        $product->setCategoryIds($categoryIds);
        $product->setPrice($price); // price of product
        $product->setOriginalPrice($price); // Original Price of product
        $product->setUrlKey($data['sku']);
        if(isset($data['length']))
            $product->setLength($data['length']);

        if(isset($data['height']))
            $product->setHeight($data['height']);

        if(isset($data['width']))
            $product->setWidth($data['width']);
        if(isset($data['weight']))
            $product->setProcureWeight($data['weight']);
      
        $this->productRepository->save($product);

    }

    public function updateOwnedItem($data)
    {
        $ownedItem                                = [];
        $category                                 = $this->categoryRepository->get($data['category_id']);
        $setId                                    = $category->getData('map_attribute');
        $this->updateProduct($data['product_id'],$data,$category);
        $connection                               = $this->getConnection();
        $ownedItem['product_name']                = $data['product_name'];
        $ownedItem['category_id']                = $data['category_id'];
        if(isset($data['image']))
         $ownedItem['image']                       = $data['image'];
        $ownedItem['attribute_set_id']            = $setId;
      
        $ownedItem['pricing_type_id']             = \Ziffity\Procurement\Controller\Constants::OWNED_PRICING_TYPE_WITH_OFFER;
        $procurementType                          = $data['type_id'];
        $ownedItem['procurement_type_id']         = $procurementType;
        $ownedItem['current_procurement_type_id'] = $procurementType;
        $offerCycleCollection                     = $this->offerCycleCollectionFactory->create();
        $offerCycleCollection->addFieldToFilter('procurement_type_id',
            ['eq' => $procurementType]);
        $offerCycleCollection->addFieldToFilter('number_of_months', ['eq' => 12]);
        $ownedItem['offer_cycle_id']        = $offerCycleCollection->getFirstItem()->getId();
        if(isset($data['offer_duration'])){
            $ownedItem['offer_cycle_id']= $data['offer_duration'];
            $ownedItem['is_duration_overridden']=1;
        }
        $ownedItem['procurement_status_id'] = Status::PROCUREMENT_AWAITING_FULFILMENT;
        $ownedItem['auto_increment_id']     = $data['sku'];
        $ownedItem['is_brand']              = $data['is_brand'];
        $ownedItem['size']                  = $data['procurement_size_id'];
        $ownedItem['quality']               = $data['procurement_quality_id'];
        if ($data['is_recommended_price_overridden'] == 1) {
            $ownedItem['is_recommended_override'] = 1;
            $ownedItem['purchase_price']          = $data['overridden_recommended_price'];
        } else {
            $ownedItem['is_recommended_override'] = 0;
            $ownedItem['purchase_price']          = $data['recommended_price'];
        }
        if ($data['is_retail_price_overridden'] == 1) {
            $ownedItem['is_retail_override'] = 1;
            $ownedItem['sale_price']         = $data['overridden_retail_price'];
        } else {
            $ownedItem['is_retail_override'] = 0;
            $ownedItem['sale_price']         = $data['retail_price'];
        }
        $connection->update('procurement_owned', $ownedItem,"product_id = ".$data['product_id']);

    }

     public function updateSubContract($data)
    {

        $subContract                                = [];
        $category                                   = $this->categoryRepository->get($data['category_id']);
        $setId                                      = $category->getData('map_attribute');
        
        $this->updateProduct($data['product_id'],$data,$category);
        $connection                                 = $this->getConnection();
        $subContract['product_name']                = $data['product_name'];
        $subContract['attribute_set_id']            = $setId;
        $subContract['cleanout_id']                 = $data['entity_id'];
        $subContract['category_id']                = $data['category_id'];
         if(isset($data['image']))
        $subContract['image']                       = $data['image'];
        $procurementType                            = $data['type_id'];
        $subContract['pricing_type_id']             = \Ziffity\Procurement\Controller\Constants::PRICING_TYPE_WITH_OFFER;
        $subContract['procurement_type_id']         = $procurementType;
        $subContract['current_procurement_type_id'] = $procurementType;

        $offerCycleCollection = $this->offerCycleCollectionFactory->create();
        $offerCycleCollection->addFieldToFilter('procurement_type_id',
            ['eq' => $procurementType]);

        $period = \Ziffity\Cleanout\Helper\Data::$offerCycleId[$procurementType][$data['is_brand']];
    
        $offerCycleCollection->addFieldToFilter('offer_cycle_id',
            ['eq' => $period]);
        $subContract['offer_cycle_id']        = $offerCycleCollection->getFirstItem()->getId();
        
        if(isset($data['offer_duration'])){
            $subContract['offer_cycle_id']= $data['offer_duration'];
            $subContract['is_duration_overridden']=1;
        }
        $subContract['procurement_status_id'] = Status::PROCUREMENT_AWAITING_FULFILMENT;

        $subContract['auto_increment_id'] = $data['sku'];
        $subContract['is_brand']          = $data['is_brand'];
        $subContract['size']              = $data['procurement_size_id'];
        $subContract['quality']           = $data['procurement_quality_id'];

        if ($data['is_retail_price_overridden'] == 1) {
            $subContract['is_retail_override'] = 1;
            $subContract['consinged_price']    = $data['overridden_retail_price'];
            $subContract['list_price']         = $data['overridden_retail_price'];
        } else {
            $subContract['is_retail_override'] = 0;
            $subContract['consinged_price']    = $data['retail_price'];
            $subContract['list_price']         = $data['retail_price'];
        }
        if ($data['is_recommended_price_overridden'] == 1) {
            $subContract['is_recommended_override']  = 1;
            $subContract['estimated_apprisal_value'] = $data['overridden_recommended_price'];
        } else {
            $subContract['is_recommended_override']  = 0;
            $subContract['estimated_apprisal_value'] = $data['recommended_price'];
        }
    
        $connection->update('procurement_sub_contracts', $subContract,"product_id = ".$data['product_id']);

    }


    public function createSubContract($data)
    {

        $subContract                                = [];
        $this->masterContract->getByConsignerId($data['customer_id']);
        $masterContractId                           = $this->masterContract->getId();
        $category                                   = $this->categoryRepository->get($data['category_id']);
        $setId                                      = $category->getData('map_attribute');
        $productId                                  = $this->createProduct($data,
            $category);
        $connection                                 = $this->getConnection();
        $subContract['product_name']                = $data['product_name'];
        $subContract['attribute_set_id']            = $setId;
         if(isset($data['image']))
        $subContract['image']                       = $data['image'];
        $subContract['cleanout_id']                 = $data['entity_id'];
        $subContract['product_id']                  = $productId;
        $subContract['master_contract_id']          = $masterContractId;
        $procurementType                            = $data['type_id'];
        $subContract['pricing_type_id']             = \Ziffity\Procurement\Controller\Constants::PRICING_TYPE_WITH_OFFER;
        $subContract['procurement_type_id']         = $procurementType;
        $subContract['current_procurement_type_id'] = $procurementType;
         $subContract['category_id']                = $data['category_id'];
        $offerCycleCollection = $this->offerCycleCollectionFactory->create();
        $offerCycleCollection->addFieldToFilter('procurement_type_id',
            ['eq' => $procurementType]);

        $period = \Ziffity\Cleanout\Helper\Data::$offerCycleId[$procurementType][$data['is_brand']];

        $offerCycleCollection->addFieldToFilter('offer_cycle_id',
            ['eq' => $period]);
        $subContract['offer_cycle_id']        = $offerCycleCollection->getFirstItem()->getId();
        if(isset($data['offer_duration'])){
            $subContract['offer_cycle_id']= $data['offer_duration'];
            $subContract['is_duration_overridden']=1;

        }
        $subContract['procurement_status_id'] = Status::PROCUREMENT_AWAITING_FULFILMENT;

        $subContract['auto_increment_id'] = $data['sku'];
        $subContract['is_brand']          = $data['is_brand'];
        $subContract['size']              = $data['procurement_size_id'];
        $subContract['quality']           = $data['procurement_quality_id'];
        $subContract['source']            = ProcurementSource::BULK_PROCUREMENT_ID;

        if ($data['is_retail_price_overridden'] == 1) {
            $subContract['is_retail_override'] = 1;
            $subContract['consinged_price']    = $data['overridden_retail_price'];
            $subContract['list_price']         = $data['overridden_retail_price'];
        } else {
            $subContract['is_retail_override'] = 0;
            $subContract['consinged_price']    = $data['retail_price'];
            $subContract['list_price']         = $data['retail_price'];
        }
        if ($data['is_recommended_price_overridden'] == 1) {
            $subContract['is_recommended_override']  = 1;
            $subContract['estimated_apprisal_value'] = $data['overridden_recommended_price'];
        } else {
            $subContract['is_recommended_override']  = 0;
            $subContract['estimated_apprisal_value'] = $data['recommended_price'];
        }
        $subContract['store_code']    = $data['store_code'];
        $subContract['admin_user_id'] = $data['procurement_user_id'];
        $connection->insert('procurement_sub_contracts', $subContract);

        $sql = "UPDATE ".$connection->getTableName('procurement_sub_contracts')." sc
                SET  sc.entity_id = CONCAT_WS(' - ', master_contract_id,sub_contract_id)
            WHERE  sc.auto_increment_id = ?";
        $connection->query($sql, array($data['sku']));
    }

    public function createOwnedItem($data)
    {
        $ownedItem                                = [];
        $customerId                               = $data['customer_id'];
        $category                                 = $this->categoryRepository->get($data['category_id']);
        $setId                                    = $category->getData('map_attribute');
        $productId                                = $this->createProduct($data,
            $category);
        $connection                               = $this->getConnection();
        $ownedItem['product_name']                = $data['product_name'];
         $ownedItem['category_id']                = $data['category_id'];
        $ownedItem['product_id']                  = $productId;
        $ownedItem['attribute_set_id']            = $setId;
        $ownedItem['customer_id']                 = $customerId;
         if(isset($data['image']))
        $ownedItem['image']                       = $data['image'];
        $ownedItem['cleanout_id']                 = $data['entity_id'];
        $ownedItem['pricing_type_id']             = \Ziffity\Procurement\Controller\Constants::OWNED_PRICING_TYPE_WITH_OFFER;
        $procurementType                          = $data['type_id'];
        $ownedItem['procurement_type_id']         = $procurementType;
        $ownedItem['current_procurement_type_id'] = $procurementType;
        $offerCycleCollection                     = $this->offerCycleCollectionFactory->create();
        $offerCycleCollection->addFieldToFilter('procurement_type_id',
            ['eq' => $procurementType]);
        $offerCycleCollection->addFieldToFilter('number_of_months', ['eq' => 12]);

        $ownedItem['offer_cycle_id']        = $offerCycleCollection->getFirstItem()->getId();
        if(isset($data['offer_duration'])){
            $ownedItem['offer_cycle_id']= $data['offer_duration'];
            $ownedItem['is_duration_overridden']=1;
        }
        $ownedItem['procurement_status_id'] = Status::PROCUREMENT_AWAITING_FULFILMENT;
        $ownedItem['auto_increment_id']     = $data['sku'];
        $ownedItem['is_brand']              = $data['is_brand'];
        $ownedItem['size']                  = $data['procurement_size_id'];
        $ownedItem['quality']               = $data['procurement_quality_id'];
        $ownedItem['source']                = ProcurementSource::BULK_PROCUREMENT_ID;
        $ownedItem['store_code']            = $data['store_code'];
        $ownedItem['admin_user_id']         = $data['procurement_user_id'];
        if ($data['is_recommended_price_overridden'] == 1) {
            $ownedItem['is_recommended_override'] = 1;
            $ownedItem['purchase_price']          = $data['overridden_recommended_price'];
        } else {
            $ownedItem['is_recommended_override'] = 0;
            $ownedItem['purchase_price']          = $data['recommended_price'];
        }
        if ($data['is_retail_price_overridden'] == 1) {
            $ownedItem['is_retail_override'] = 1;
            $ownedItem['sale_price']         = $data['overridden_retail_price'];
        } else {
            $ownedItem['is_retail_override'] = 0;
            $ownedItem['sale_price']         = $data['retail_price'];
        }
        $connection->insert('procurement_owned', $ownedItem);


        $sql = "UPDATE ".$connection->getTableName('procurement_owned')." po
                SET  po.entity_id = CONCAT('O - ', procurement_owned_id)
            WHERE  po.auto_increment_id = ?";
        $connection->query($sql, array($data['sku']));
    }

    private function createProduct($data, $category)
    {
        
        $parentIds   = $category->getParentIds();
        $categoryIds = array_slice($parentIds, 3);
        $categoryIds[]=$category->getId();
        $product     = $this->productFactory->create();
        $qty         = 1;
        $price       = $this->getProductPrice($data);
        //$itemsCount ? $itemsCount : 1;
        $product->setSku($data['sku']); // Set your sku here
        $product->setName($data['product_name']); // Name of Product
        $product->setAttributeSetId($category->getData('map_attribute')); // Attribute set id
        $product->setStatus(\Magento\Catalog\Model\Product\Attribute\Source\Status::STATUS_DISABLED); // Status on product enabled/ disabled 1/0
        $product->setVisibility(\Magento\Catalog\Model\Product\Visibility::VISIBILITY_BOTH); // visibilty of product (catalog / search / catalog, search / Not visible individually)
        //$product->setTaxClassId(0); // Tax class id
        $product->setTypeId(\Magento\Catalog\Model\Product\Type::TYPE_SIMPLE); // type of product (simple/virtual/downloadable/configurable)
        $product->setPrice($price); // price of product
        $product->setOriginalPrice($price); // Original Price of product
        $product->setCategoryIds($categoryIds);
        $product->setIsSalable(true);
        $product->setUrlKey($data['sku']);
        if(isset($data['length']))
            $product->setLength($data['length']);

        if(isset($data['height']))
            $product->setHeight($data['height']);

        if(isset($data['width']))
            $product->setWidth($data['width']);
        
        if(isset($data['weight']))
            $product->setProcureWeight($data['weight']);
      
        $product->setStockData(
            array(
                'use_config_manage_stock' => 0,
                'manage_stock' => 1,
                'is_in_stock' => 1,
                'qty' => $qty
            )
        );
        $product->setPosLocation($data['store_code']);
        $product     = $this->productRepository->save($product);
        $this->stoctRepository->updateStock($product->getId(), 1, $data['store_code'],
            true, $qty);
        return $product->getId();
    }

    protected function getProductPrice($data)
    {
        $price = 0;
        if ($data['is_retail_price_overridden'] == 1) {
            $price = $data['overridden_retail_price'];
        } else {
            $price = $data['retail_price'];
        }
        return $price;
    }
}