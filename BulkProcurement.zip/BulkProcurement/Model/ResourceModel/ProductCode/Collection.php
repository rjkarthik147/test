<?php

namespace Ziffity\BulkProcurement\Model\ResourceModel\ProductCode;

use \Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection;

/**
 * Description of Collection
 *
 * @author Daiva
 */
class Collection extends AbstractCollection
{
	protected $_idFieldName = 'id';

    protected function _construct()
    {
        $this->_init('Ziffity\BulkProcurement\Model\ProductCode',
            'Ziffity\BulkProcurement\Model\ResourceModel\ProductCode');
    }
       /**
     * {@inheritdoc}
     */
    protected function _initSelect()
    {
        parent::_initSelect();
        $this->getSelect()->order("label ASC");
    }
}