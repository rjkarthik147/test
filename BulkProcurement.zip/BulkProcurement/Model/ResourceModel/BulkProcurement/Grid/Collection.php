<?php

namespace Ziffity\BulkProcurement\Model\ResourceModel\BulkProcurement\Grid;

use Ziffity\BulkProcurement\Model\ResourceModel\BulkProcurement\Collection as BulkProcurementCollection;
use Magento\Framework\Api\Search\SearchResultInterface;

/**
 * Description of Collection
 *
 * @author Daiva
 */
class Collection extends BulkProcurementCollection implements SearchResultInterface
{
    protected $_helper;
    protected $_idFieldName = 'entity_id';

    /**
     * Resource initialization
     * @return $this
     */
    public function __construct(
    \Magento\Framework\Data\Collection\EntityFactoryInterface $entityFactory,
    \Psr\Log\LoggerInterface $logger,
    \Magento\Framework\Data\Collection\Db\FetchStrategyInterface $fetchStrategy,
    \Magento\Framework\Event\ManagerInterface $eventManager,
    \Ziffity\Procurement\Helper\Data $helper, $mainTable, $eventPrefix,
    $eventObject, $resourceModel,
    $model = 'Magento\Framework\View\Element\UiComponent\DataProvider\Document',
    $connection = null,
    \Magento\Framework\Model\ResourceModel\Db\AbstractDb $resource = null
    )
    {

        $this->_helper      = $helper;
        parent::__construct(
            $entityFactory, $logger, $fetchStrategy, $eventManager,
             $connection, $resource
        );
        $this->_eventPrefix = $eventPrefix;
        $this->_eventObject = $eventObject;
        $this->_init($model, $resourceModel);
        $this->setMainTable($mainTable);
    }

    public function getAggregations()
    {
        return $this->aggregations;
    }

    public function getSearchCriteria()
    {
        return null;
    }

    public function getTotalCount()
    {
        return $this->getSize();
    }

    public function setAggregations($aggregations)
    {
        $this->aggregations = $aggregations;
    }

    public function setItems(array $items = null)
    {
        return $this;
    }

    public function setSearchCriteria(\Magento\Framework\Api\SearchCriteriaInterface $searchCriteria)
    {
        return $this;
    }

    public function setTotalCount($totalCount)
    {
        return $this;
    }

    protected function _initSelect()
    {
        parent::_initSelect();

        $posCode = '';
        $useId   = $this->_helper->getUserId();


        $hasAllPermission = $this->_helper->hasAllPermissions($useId);

        $this->getSelect()->reset(\Zend_Db_Select::COLUMNS)->columns(
            ['submitted_at'=>'submitted_at','entity_id' => 'entity_id',
                 'location' => 'store_code',
                'number_of_items' => 'number_of_items',
                'status' => 'status_id',
                'pickup_date' => 'pickup_date'
        ]);
         $this->getSelect()->join(array('customer' => 'customer_entity'), 'customer.entity_id=main_table.customer_id', array('firstname', 'lastname'))
                ->columns(new \Zend_Db_Expr("CONCAT(`customer`.`firstname`, ' ',`customer`.`lastname`) AS procured_from"))->where('main_table.status_id != 0');
        
        if ($hasAllPermission == false) {
            $posCode = $this->_helper->getPosCodebyUserId($useId);

            $this->getSelect()->where('store_code = ?', $posCode);
        } 
        $unionSelect = clone $this->getSelect();        
        $this->getSelect()->reset()->from($unionSelect);
    
        return $this;
    }
}