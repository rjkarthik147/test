<?php

namespace Ziffity\BulkProcurement\Model\ResourceModel;

use \Magento\Framework\Model\ResourceModel\Db\AbstractDb;

/**
 * Description of BulkProcurementItem
 *
 * @author Daiva
 */
class BulkProcurementItem extends AbstractDb
{

    protected function _construct()
    {
        $this->_init('bulk_procurement_items', 'id');
    }
}