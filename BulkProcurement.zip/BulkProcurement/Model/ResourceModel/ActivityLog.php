<?php

namespace Ziffity\BulkProcurement\Model\ResourceModel;

use \Magento\Framework\Model\ResourceModel\Db\AbstractDb;

/**
 * Description of ActivityLog
 *
 * @author Daiva
 */
class ActivityLog extends AbstractDb
{

    protected function _construct()
    {
        $this->_init('bulk_procurement_activity_logs', 'activity_log_id');
    }
}