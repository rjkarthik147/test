<?php

namespace Ziffity\BulkProcurement\Model\ResourceModel;

use \Magento\Framework\Model\ResourceModel\Db\AbstractDb;

/**
 * Description of BulkProcurement
 *
 * @author Daiva
 */
class BulkProcurement extends AbstractDb
{

    protected function _construct()
    {
        $this->_init('bulk_procurements', 'entity_id');
    }
}