<?php

namespace Ziffity\BulkProcurement\Model;

use \Magento\Framework\Model\AbstractModel;
use Ziffity\BulkProcurement\Api\Data\ProductCodeInterface;

/**
 * Description of ProductCode
 *
 * @author Daiva
 */
class ProductCode extends AbstractModel implements ProductCodeInterface
{
	/**
     * Prefix of model events names
     *
     * @var string
     */
	protected $eventPrefix = 'bulkprocurement';
	/**
     * Name of the event object
     *
     * @var string
     */
    protected $_eventObject = 'productcode'; // parent value is 'object'
    /**
     * Name of object id field
     *
     * @var string
     */
    protected $id_FieldName = ProductCodeInterface::ID; // parent value is 'id'


    protected function _construct()
    {
        $this->_init('Ziffity\BulkProcurement\Model\ResourceModel\ProductCode');
    }

    /*public function getId() {
    	return (string) $this->getData(static::ID);
    }*/
}