<?php

namespace Ziffity\BulkProcurement\Setup;

use Magento\Framework\Setup\InstallSchemaInterface;
use Magento\Framework\Setup\ModuleContextInterface;
use Magento\Framework\Setup\SchemaSetupInterface;
use Magento\Framework\DB\Ddl\Table;

class InstallSchema implements InstallSchemaInterface
{

    /**
     * Installs DB schema for a module
     *
     * @param SchemaSetupInterface $setup
     * @param ModuleContextInterface $context
     * @return void
     */
    public function install(SchemaSetupInterface $setup,
                            ModuleContextInterface $context)
    {
        $installer = $setup;
        $installer->startSetup();

        /**
         * Create table 'Bulk Procurements'
         */
        $tableName    = $installer->getTable('bulk_procurements');
        $tableComment = 'Bulk Procurements';
        $columns      = array(
            'entity_id' => array(
                'type' => Table::TYPE_INTEGER,
                'size' => null,
                'options' => array('identity' => true, 'unsigned' => true, 'nullable' => false,
                    'primary' => true),
                'comment' => 'Bulk Procurement Id',
            ),

            'status_id' => array(
                'type' => Table::TYPE_INTEGER,
                'size' => null,
                'options' => array('unsigned' => true),
                'comment' => 'Bulk Procurement Status Id',
            ),
              'number_of_items' => array(
                'type' => Table::TYPE_INTEGER,
                'size' => null,
                'options' => array('unsigned' => true),
                'comment' => 'Number of Items',
            ),
             'store_code' => array(
                'type' => Table::TYPE_INTEGER,
                'size' => 11,
                'options' => array('unsigned' => true),
                'comment' => 'Store Code',
            ),
           'customer_id' => array(
                'type' => Table::TYPE_INTEGER,
                'size' => null,
                'options' => array('unsigned' => true),
                'comment' => 'Customer Id',
            ),

            'pickup_date' => array(
                'type' => Table::TYPE_DATE,
                'size' => null,
                'options' => array('nullable' => false),
                'comment' => 'Pickup Date',
            ),
            'pickup_time_from' => array(
                'type' => Table::TYPE_TEXT,
                'size' => null,
                'options' => array('nullable' => false, 'default' => ''),
                'comment' => 'Pickup Time From',
            ),
            'pickup_time_to' => array(
                'type' => Table::TYPE_TEXT,
                'size' => null,
                'options' => array('nullable' => false, 'default' => ''),
                'comment' => 'Pickup Time To',
            ),
            'is_scheduled' => array(
                'type' => Table::TYPE_SMALLINT,
                'size' => null,
                'options' => array('unsigned' => true),
                'comment' => 'Is Scheduled',
            ),
            'is_product_arrived' => array(
                'type' => Table::TYPE_SMALLINT,
                'size' => null,
                'options' => array('unsigned' => true),
                'comment' => 'Is Product Arrived',
            ),
            'arrived_date' => array(
                'type' => Table::TYPE_DATETIME,
                'size' => null,
                'options' => array(),
                'comment' => 'Arrived Date',
            ),
            'created_at' => array(
                'type' => \Magento\Framework\DB\Ddl\Table::TYPE_TIMESTAMP,
                'size' => null,
                'options' => array('nullable' => false, 'default' => \Magento\Framework\DB\Ddl\Table::TIMESTAMP_INIT),
                'comment' => 'Created At',
            ),
            'philanthropic_id' => array(
                'type' => Table::TYPE_INTEGER,
                'size' => null,
                'options' => array('unsigned' => true),
                'comment' => 'Philanthropic Id',
            ),
             'taxable_income_brackets_id' => array(
                'type' => Table::TYPE_INTEGER,
                'size' => null,
                'options' => array('unsigned' => true),
                'comment' => 'Taxable Income Brackets Id',
            ),
              'procurement_user_id' => array(
                'type' => Table::TYPE_INTEGER,
                'size' => null,
                'options' => array('unsigned' => true),
                'comment' => 'Procurement user id',
            ),
                'filers_type_id' => array(
                'type' => Table::TYPE_INTEGER,
                'size' => null,
                'options' => array('unsigned' => true,'nullable' => false),
                 'default' => '0',
                'comment' => 'Filers Type Id',
            ),

        );

        $indexes = array(
           
        );

        $foreignKeys = array(
            'customer_id' => array('ref_table' => 'customer_entity', 'ref_column' => 'entity_id',
                'on_delete' => Table::ACTION_SET_NULL),
            'procurement_user_id' => array('ref_table' => 'procurement_user', 'ref_column' => 'procurator_id',
                'on_delete' => Table::ACTION_SET_NULL),
           'philanthropic_id' => array('ref_table' => 'philanthropic_organizations',
                'ref_column' => 'entity_id', 'on_delete' => \Magento\Framework\DB\Ddl\Table::ACTION_SET_NULL),
            'store_code' => array('ref_table' => 'pointofsale',
                'ref_column' => 'place_id', 'on_delete' => \Magento\Framework\DB\Ddl\Table::ACTION_SET_NULL),
             'taxable_income_brackets_id' => array('ref_table' => 'income_brackets_rates',
                'ref_column' => 'taxable_income_brackets_id', 'on_delete' => \Magento\Framework\DB\Ddl\Table::ACTION_SET_NULL)

            );


        // Table creation
        $table = $installer->getConnection()->newTable($tableName);

        // Columns creation
        foreach ($columns AS $name => $values) {
            $table->addColumn(
                $name, $values['type'], $values['size'], $values['options'],
                $values['comment']
            );
        }

        // Indexes creation
        foreach ($indexes AS $index => $values) {
            $table->addIndex(
                $installer->getIdxName($tableName, [$index], $values['type']),
                [$index], ['type' => $values['type']]
            );
        }

        // Foreign keys creation
        foreach ($foreignKeys AS $column => $foreignKey) {
            $table->addForeignKey(
                $installer->getFkName($tableName, $column,
                    $foreignKey['ref_table'], $foreignKey['ref_column']),
                $column, $foreignKey['ref_table'], $foreignKey['ref_column'],
                $foreignKey['on_delete']
            );
        }

        // Table comment
        $table->setComment($tableComment);

        // Execute SQL to create the table
        $installer->getConnection()->createTable($table);


        /**
         * Create table 'Bulk Procurement Items'
         */
        $tableName    = $installer->getTable('bulk_procurement_items');
        $tableComment = 'Bulk Procurement Items';
        $columns      = array(
            'id' => array(
                'type' => Table::TYPE_INTEGER,
                'size' => null,
                'options' => array('identity' => true, 'unsigned' => true, 'nullable' => false,
                    'primary' => true),
                'comment' => 'Bulk Procurement Item Id',
            ),
            'entity_id' => array(
                'type' => Table::TYPE_INTEGER,
                'size' => null,
                'options' => array('nullable' => false,'unsigned' => true),
                'comment' => 'Entity Id',
            ),
            'type_id' => array(
                'type' => Table::TYPE_INTEGER,
                'size' => null,
                'options' => array('nullable' => false,'unsigned' => true),
                'comment' => 'Procurement Type Id',
            ),
             'product_name' => array(
                'type' => Table::TYPE_TEXT,
                'size' => 255,
                'options' => array('nullable' => false, 'default' => ''),
                'comment' => 'Product Name',
            ),
            'category_id' => array(
                'type' => Table::TYPE_INTEGER,
                'size' => null,
                'options' => array('unsigned' => true),
                'comment' => 'Entity Id',
            ),
             'is_brand' => array(
                'type' => Table::TYPE_BOOLEAN,
                'size' => null,
                'options' => ['nullable' => false, 'default' => 0],
                'comment' => 'Is Brand',
            ),
          'procurement_quality_id' => array(
                'type' => Table::TYPE_INTEGER,
                'size' => null,
                'options' => array('unsigned' => true),
                'comment' => 'Procurement Quality_id Id',
            ),
             'procurement_size_id' => array(
                'type' => Table::TYPE_INTEGER,
                'size' => null,
                'options' => array('unsigned' => true),
                'comment' => 'Cleanout Procurement Type Id',
            ),
         
           'qty' => array(
                'type' => Table::TYPE_SMALLINT,
                'size' => null,
                'options' => array('unsigned' => true, 'nullable' => false, 'default' => '0'),
                'comment' => 'Qty',
            ),
              'recommended_price' => array(
                'type' => Table::TYPE_DECIMAL,
                'size' => '12,2',
                'options' => array('nullable' => false, 'default' => '0.00'),
                'comment' => 'Recommended Price',
            ),
             'is_recommended_price_overridden' => array(
                'type' => Table::TYPE_BOOLEAN,
                'size' => null,
                'options' => ['nullable' => false, 'default' => 0],
                'comment' => 'Is Recommended Price Overridden',
            ),
               'overridden_recommended_price' => array(
                'type' => Table::TYPE_DECIMAL,
                'size' => '12,2',
                'options' => array('nullable' => false, 'default' => '0.00'),
                'comment' => 'Overridden Recommended Price',
            ),
            'retail_price' => array(
                'type' => Table::TYPE_DECIMAL,
                'size' => '12,2',
                'options' => array('nullable' => false, 'default' => '0.00'),
                'comment' => 'Retail Price',
            ),
             'is_retail_price_overridden' => array(
                'type' => Table::TYPE_BOOLEAN,
                'size' => null,
                'options' => ['nullable' => false, 'default' => 0],
                'comment' => 'Is Retail Price Overridden',
            ),
               'overridden_retail_price' => array(
                'type' => Table::TYPE_DECIMAL,
                'size' => '12,2',
                'options' => array('nullable' => false, 'default' => '0.00'),
                'comment' => 'Overridden Retail Price',
            ),
            'sell_individually' => array(
                'type' => Table::TYPE_BOOLEAN,
                'size' => null,
                'options' => ['nullable' => false, 'default' => 0],
                'comment' => 'Sell it as Individually',
            ),

        );


        $foreignKeys = array(
               'entity_id' => array('ref_table' => 'bulk_procurements', 'ref_column' => 'entity_id',
                'on_delete' => Table::ACTION_CASCADE),
               'category_id' => array('ref_table' => 'catalog_category_entity', 'ref_column' => 'entity_id',
                'on_delete' => Table::ACTION_SET_NULL),
            'type_id' => array('ref_table' => 'procurement_types', 'ref_column' => 'procurement_type_id',
                'on_delete' => Table::ACTION_CASCADE),
            'procurement_quality_id' => array('ref_table' => 'procurement_quality', 'ref_column' => 'id',
                'on_delete' => \Magento\Framework\DB\Ddl\Table::ACTION_SET_NULL),
              'procurement_size_id' => array('ref_table' => 'procurement_size', 'ref_column' => 'id',
                'on_delete' => \Magento\Framework\DB\Ddl\Table::ACTION_SET_NULL),
        );

        // Table creation
        $table = $installer->getConnection()->newTable($tableName);

        // Columns creation
        foreach ($columns AS $name => $values) {
            $table->addColumn(
                $name, $values['type'], $values['size'], $values['options'],
                $values['comment']
            );
        }


        // Foreign keys creation
        foreach ($foreignKeys AS $column => $foreignKey) {
            $table->addForeignKey(
                $installer->getFkName($tableName, $column,
                    $foreignKey['ref_table'], $foreignKey['ref_column']),
                $column, $foreignKey['ref_table'], $foreignKey['ref_column'],
                $foreignKey['on_delete']
            );
        }

        // Table comment
        $table->setComment($tableComment);

        // Execute SQL to create the table
        $installer->getConnection()->createTable($table);



        /**
         * Create table 'Activity Logs'
         */
        $tableName    = $installer->getTable('bulk_procurement_activity_logs');
        $tableComment = 'Bulk Procurement Activity Logs Information';
        $columns      = array(
            'activity_log_id' => array(
                'type' => Table::TYPE_INTEGER,
                'size' => null,
                'options' => array('identity' => true, 'unsigned' => true, 'nullable' => false,
                    'primary' => true),
                'comment' => 'Activity Log Id',
            ),
            'entity_id' => array(
                'type' => Table::TYPE_INTEGER,
                'size' => null,
                'options' => array('nullable' => false,'unsigned' => true),
                'comment' => 'Entity Id',
            ),
            'action' => array(
                'type' => Table::TYPE_TEXT,
                'size' => 255,
                'options' => array('nullable' => false, 'default' => ''),
                'comment' => 'Action',
            ),
            'performer' => array(
                'type' => Table::TYPE_INTEGER,
                'size' => null,
                'options' => array(),
                'comment' => 'Action performer Id',
            ),
            'event_date' => array(
                'type' => \Magento\Framework\DB\Ddl\Table::TYPE_TIMESTAMP,
                'size' => null,
                'options' => array('nullable' => false, 'default' => \Magento\Framework\DB\Ddl\Table::TIMESTAMP_INIT_UPDATE),
                'comment' => 'Event Date',
            )

        );


        $foreignKeys = array(
               'entity_id' => array('ref_table' => 'cleanout_events', 'ref_column' => 'entity_id',
                'on_delete' => Table::ACTION_CASCADE)
        );

        // Table creation
        $table = $installer->getConnection()->newTable($tableName);

        // Columns creation
        foreach ($columns AS $name => $values) {
            $table->addColumn(
                $name, $values['type'], $values['size'], $values['options'],
                $values['comment']
            );
        }


        // Foreign keys creation
        foreach ($foreignKeys AS $column => $foreignKey) {
            $table->addForeignKey(
                $installer->getFkName($tableName, $column,
                    $foreignKey['ref_table'], $foreignKey['ref_column']),
                $column, $foreignKey['ref_table'], $foreignKey['ref_column'],
                $foreignKey['on_delete']
            );
        }

        // Table comment
        $table->setComment($tableComment);

        // Execute SQL to create the table
        $installer->getConnection()->createTable($table);



        /**
         * Create table 'Product Codes'
         */
        $tableName    = $installer->getTable('product_codes');
        $tableComment = 'Product Codes';
        $columns      = array(
            'id' => array(
                'type' => Table::TYPE_INTEGER,
                'size' => null,
                'options' => array('identity' => true, 'unsigned' => true, 'nullable' => false,
                    'primary' => true),
                'comment' => 'Product Code Id',
            ),
            'category_id' => array(
                'type' => Table::TYPE_INTEGER,
                'size' => null,
                'options' => array('unsigned' => true),
                'comment' => 'Entity Id',
            ),
            'label' => array(
                'type' => Table::TYPE_TEXT,
                'size' => 255,
                'options' => array('nullable' => false, 'default' => ''),
                'comment' => 'Label',
            )

        );


        $foreignKeys = array(
                'category_id' => array('ref_table' => 'catalog_category_entity', 'ref_column' => 'entity_id',
                'on_delete' => Table::ACTION_SET_NULL),
        );

        // Table creation
        $table = $installer->getConnection()->newTable($tableName);

        // Columns creation
        foreach ($columns AS $name => $values) {
            $table->addColumn(
                $name, $values['type'], $values['size'], $values['options'],
                $values['comment']
            );
        }


        // Foreign keys creation
        foreach ($foreignKeys AS $column => $foreignKey) {
            $table->addForeignKey(
                $installer->getFkName($tableName, $column,
                    $foreignKey['ref_table'], $foreignKey['ref_column']),
                $column, $foreignKey['ref_table'], $foreignKey['ref_column'],
                $foreignKey['on_delete']
            );
        }

        // Table comment
        $table->setComment($tableComment);

        // Execute SQL to create the table
        $installer->getConnection()->createTable($table);


        /**
         * Add field to Procurement Types
         */

         $tableName = $installer->getTable('procurement_types');
            $connection = $setup->getConnection();
            if ($connection->isTableExists($tableName) == true) {
                // Declare data
                $columns = [
                    'used_for_bulk' => [
                        'type' => Table::TYPE_BOOLEAN,
                        'size' => null,
                        'options' => ['nullable' => false, 'default' => 0],
                        'comment' => 'Is Used for Bulk Procurement',
                    ]
                ];

               
                foreach ($columns as $name => $definition) {
                    $connection->addColumn($tableName, $name, $definition);
                }

                $connection->dropColumn($tableName, 'aggrement_link');
            }

    }
}