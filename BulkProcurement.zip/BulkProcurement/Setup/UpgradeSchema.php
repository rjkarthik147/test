<?php

namespace Ziffity\BulkProcurement\Setup;

use Magento\Framework\Setup\UpgradeSchemaInterface;
use Magento\Framework\Setup\ModuleContextInterface;
use Magento\Framework\Setup\SchemaSetupInterface;
use Magento\Framework\DB\Ddl\Table;

class UpgradeSchema implements UpgradeSchemaInterface
{

    /**
     * {@inheritdoc}
     */
    public function upgrade(
    SchemaSetupInterface $setup, ModuleContextInterface $context
    )
    {
        $setup->startSetup();
        if (version_compare($context->getVersion(), '0.0.2', '<')) {
            $tableName = $setup->getTable('bulk_procurement_items');

            if ($setup->getConnection()->isTableExists($tableName) == true) {
                $columns = [
                     'comments' => [
                        'type' => Table::TYPE_TEXT,
                        'size' => 255,
                        'options' => ['nullable' => false, 'default' => ''],
                        'comment' => 'Comments'
                    ],
                    'sku' => [
                        'type' => Table::TYPE_TEXT,
                        'size' => 255,
                        'options' => ['nullable' => false, 'default' => ''],
                        'comment' => 'Sku',
                        'after' => 'entity_id',
                    ],
                    'image' => [
                        'type' => Table::TYPE_TEXT,
                        'size' => 255,
                        'options' => ['nullable' => false, 'default' => ''],
                        'comment' => 'Image',
                    ]
                ];
                $foreignKeys = array(
                    'category_id' => array('ref_table' => 'product_codes',
                        'ref_column' => 'category_id',
                        'on_delete' => Table::ACTION_SET_NULL));
                $connection = $setup->getConnection();
                foreach ($columns as $name => $definition) {
                    $connection->addColumn($tableName, $name, $definition);
                }
             
                $connection->dropForeignKey($tableName,"BULK_PROCUREMENT_ITEMS_CTGR_ID_CAT_CTGR_ENTT_ENTT_ID");

                    foreach ($foreignKeys AS $column => $foreignKey) {
                    $connection->addForeignKey(
                        $setup->getFkName($tableName, $column,
                            $foreignKey['ref_table'], $foreignKey['ref_column']),
                        $tableName, $column, $foreignKey['ref_table'],
                        $foreignKey['ref_column'], $foreignKey['on_delete']
                    );
                }
            }

            $tableName = $setup->getTable('procurement_sub_contracts');

            if ($setup->getConnection()->isTableExists($tableName) == true) {
                $columns = [
                    'bulk_item_id' => [
                        'type' => Table::TYPE_INTEGER,
                        'size' => null,'unsigned' => true,
                        'comment' => 'Bulk Procurement Items Id'
                    ],
                    'source' => [
                        'type' => Table::TYPE_INTEGER,
                        'size' => null,
                        'nullable' => false,
                        'default' => 1,
                        'comment' => 'Source',
                    ]
                ];

                $foreignKeys = array(
                    'bulk_item_id' => array('ref_table' => 'bulk_procurement_items',
                        'ref_column' => 'id',
                        'on_delete' => Table::ACTION_SET_NULL));
                $connection  = $setup->getConnection();
                foreach ($columns as $name => $definition) {
                    $connection->addColumn($tableName, $name, $definition);
                }
                // Foreign keys creation
                foreach ($foreignKeys AS $column => $foreignKey) {
                    $connection->addForeignKey(
                        $setup->getFkName($tableName, $column,
                            $foreignKey['ref_table'], $foreignKey['ref_column']),
                        $tableName, $column, $foreignKey['ref_table'],
                        $foreignKey['ref_column'], $foreignKey['on_delete']
                    );
                }
            }

             $tableName = $setup->getTable('procurement_owned');

            if ($setup->getConnection()->isTableExists($tableName) == true) {
                $columns = [
                    'bulk_item_id' => [
                        'type' => Table::TYPE_INTEGER,
                        'size' => null,'unsigned' => true,
                        'comment' => 'Bulk Procurement Items Id'
                    ],
                    'source' => [
                        'type' => Table::TYPE_INTEGER,
                        'size' => null,
                        'nullable' => false,
                        'default' => 1,
                        'comment' => 'Source',
                    ]
                ];

 
                $connection  = $setup->getConnection();
                foreach ($columns as $name => $definition) {
                    $connection->addColumn($tableName, $name, $definition);
                }

            }
        }
        if (version_compare($context->getVersion(), '0.0.3', '<')) {
            $tableName = $setup->getTable('bulk_procurements');
            $columns = [
                'submitted_at' => [                
                    'type' => Table::TYPE_DATETIME,
                    'size' => null,
                    'options' => array(),
                    'comment' => 'Submitted Date',
                ] 
            ];


            $connection  = $setup->getConnection();
            foreach ($columns as $name => $definition) {
                $connection->addColumn($tableName, $name, $definition);
            }
        }
        if (version_compare($context->getVersion(), '0.0.4', '<')) {
            $tableName = $setup->getTable('procurement_sub_contracts');

            if ($setup->getConnection()->isTableExists($tableName) == true) {
                $columns = [
                    'is_duration_overridden' => [
                        'type' => Table::TYPE_INTEGER,
                        'size' => null,
                        'nullable' => false,
                        'default' => 0,
                        'comment' => 'Is Duration Overridden',
                    ]
                ];

                
                $connection  = $setup->getConnection();
                foreach ($columns as $name => $definition) {
                    $connection->addColumn($tableName, $name, $definition);
                }
            }
            $tableName = $setup->getTable('procurement_owned');

            if ($setup->getConnection()->isTableExists($tableName) == true) {
                $columns = [
                    'is_duration_overridden' => [
                        'type' => Table::TYPE_INTEGER,
                        'size' => null,
                        'nullable' => false,
                        'default' => 0,
                        'comment' => 'Is Duration Overridden',
                    ]
                ];


                $connection  = $setup->getConnection();
                foreach ($columns as $name => $definition) {
                    $connection->addColumn($tableName, $name, $definition);
                }

            }
        }
        $setup->endSetup();
    }
}