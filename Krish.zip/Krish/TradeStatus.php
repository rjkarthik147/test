<?php
namespace Ziffity\TradeAccount\Model\Customer\Attribute\Source;
class TradeStatus extends \Magento\Eav\Model\Entity\Attribute\Source\AbstractSource {
    public function getAllOptions() {
        if ($this->_options === null) {
            $this->_options = [
                ['value' => '0', 'label' => __('Not Applicable')],
                ['value' => '1', 'label' => __('Pending')],
                ['value' => '2', 'label' => __('Approved')],
                ['value' => '3', 'label' => __('Rejected')]
            ];
        }
        return $this->_options;
    }
}
