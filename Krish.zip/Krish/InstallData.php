<?php

namespace Ziffity\TradeAccount\Setup;

use Magento\Customer\Model\Customer;
use Magento\Framework\Setup\InstallDataInterface;
use Magento\Framework\Setup\ModuleContextInterface;
use Magento\Customer\Setup\CustomerSetupFactory;
use Magento\Framework\Setup\ModuleDataSetupInterface;
/**
 * @SuppressWarnings(PHPMD)
 */
class InstallData implements InstallDataInterface {

    private $customerSetupFactory;

    /**
     * Constructor
     *
     * @param \Magento\Customer\Setup\CustomerSetupFactory $customerSetupFactory
     */
    public function __construct(
    CustomerSetupFactory $customerSetupFactory
    ) {
        $this->customerSetupFactory = $customerSetupFactory;
    }

    public function install(ModuleDataSetupInterface $setup, 
                            ModuleContextInterface $context ) {
        $customerSetup = $this->customerSetupFactory->create(['setup' => $setup]);
        $customerSetup->addAttribute('customer', 'firm_name', [
            'type' => 'varchar',
            'label' => 'Firm Name',
            'input' => 'text',
            'source' => '',
            'required' => false,
            'visible' => true,
            'position' => 333,
            'system' => false,
            'backend' => ''
        ]);
        $attribute = $customerSetup->getEavConfig()->getAttribute('customer', 'firm_name')
                ->addData(['used_in_forms' => [
                'adminhtml_customer',
                'customer_account_create',
                'customer_account_edit'
        ]]);
        $attribute->save();
        $customerSetup->addAttribute('customer', 'has_website', [
            'type' => 'int',
            'label' => 'Has Website',
            'input' => 'boolean',
            'source' => '',
            'required' => false,
            'visible' => true,
            'position' => 343,
            'system' => false,
            'backend' => ''
        ]);
        $attribute = $customerSetup->getEavConfig()->getAttribute('customer', 'has_website')
                ->addData(['used_in_forms' => [
                'adminhtml_customer',
                'customer_account_create',
                'customer_account_edit'
        ]]);
        $attribute->save();
        $customerSetup->addAttribute('customer', 'firm_website', [
            'type' => 'varchar',
            'label' => 'Firm Website',
            'input' => 'text',
            'source' => '',
            'required' => false,
            'visible' => true,
            'position' => 353,
            'system' => false,
            'backend' => ''
        ]);
        $attribute = $customerSetup->getEavConfig()->getAttribute('customer', 'firm_website')
                ->addData(['used_in_forms' => [
                'adminhtml_customer',
                'customer_account_create',
                'customer_account_edit'
        ]]);
        $attribute->save();
        $customerSetup->addAttribute('customer', 'firm_speciality', [
            'type' => 'varchar',
            'label' => 'Firm Speciality',
            'input' => 'select',
            'source' => 'Ziffity\TradeAccount\Model\Customer\Attribute\Source\FirmSpeciality',
            'required' => false,
            'visible' => true,
            'position' => 363,
            'system' => false,
            'backend' => ''
        ]);
        $attribute = $customerSetup->getEavConfig()->getAttribute('customer', 'firm_speciality')
                ->addData(['used_in_forms' => [
                'adminhtml_customer',
                'customer_account_create',
                'customer_account_edit'
        ]]);
        $attribute->save();
        $customerSetup->addAttribute('customer', 'firm_contact', [
            'type' => 'varchar',
            'label' => 'Firm Contact',
            'input' => 'text',
            'required' => false,
            'source' => '',
            'visible' => true,
            'position' => 373,
            'system' => false,
            'backend' => ''
        ]);
        $attribute = $customerSetup->getEavConfig()->getAttribute('customer', 'firm_contact')
                ->addData(['used_in_forms' => [
                'adminhtml_customer',
                'customer_account_create',
                'customer_account_edit'
        ]]);
        $attribute->save();
        $customerSetup->addAttribute('customer', 'firm_role', [
            'type' => 'varchar',
            'label' => 'Firm Role',
            'input' => 'select',
            'source' => 'Ziffity\TradeAccount\Model\Customer\Attribute\Source\FirmRole',
            'required' => false,
            'visible' => true,
            'position' => 383,
            'system' => false,
            'backend' => ''
        ]);
        $attribute = $customerSetup->getEavConfig()->getAttribute('customer', 'firm_role')
                ->addData(['used_in_forms' => [
                'adminhtml_customer',
                'customer_account_create',
                'customer_account_edit'
        ]]);
        $attribute->save();
        $customerSetup->addAttribute('customer', 'firm_size', [
            'type' => 'varchar',
            'label' => 'Firm Size',
            'input' => 'select',
            'source' => 'Ziffity\TradeAccount\Model\Customer\Attribute\Source\FirmSize',
            'required' => false,
            'visible' => true,
            'position' => 393,
            'system' => false,
            'backend' => ''
        ]);
        $attribute = $customerSetup->getEavConfig()->getAttribute('customer', 'firm_size')
                ->addData(['used_in_forms' => [
                'adminhtml_customer',
                'customer_account_create',
                'customer_account_edit'
        ]]);
        $attribute->save();
        $customerSetup->addAttribute('customer', 'firm_address', [
            'type' => 'text',
            'label' => 'Firm Address',
            'input' => 'textarea',
            'source' => '',
            'required' => false,
            'visible' => false,
            'position' => 433,
            'system' => false,
            'backend' => ''
        ]);
        $attribute = $customerSetup->getEavConfig()->getAttribute('customer', 'firm_address')
                ->addData(['used_in_forms' => [
                'adminhtml_customer',
                'customer_account_create',
                'customer_account_edit'
        ]]);
        $attribute->save();
        $customerSetup->addAttribute('customer', 'firm_postal_code', [
            'type' => 'varchar',
            'label' => 'Firm Postal Code',
            'input' => 'text',
            'source' => '',
            'required' => false,
            'visible' => true,
            'position' => 453,
            'system' => false,
            'backend' => ''
        ]);
        $attribute = $customerSetup->getEavConfig()->getAttribute('customer', 'firm_postal_code')
                ->addData(['used_in_forms' => [
                'adminhtml_customer',
                'customer_account_create',
                'customer_account_edit'
        ]]);
        $attribute->save();
        $customerSetup->addAttribute('customer', 'firm_country', [
            'type' => 'varchar',
            'label' => 'Firm Country',
            'input' => 'select',
            'source' => 'Magento\Customer\Model\ResourceModel\Address\Attribute\Source\Country',
            'required' => false,
            'visible' => true,
            'position' => 463,
            'system' => false,
            'backend' => ''
        ]);
        $attribute = $customerSetup->getEavConfig()->getAttribute('customer', 'firm_country')
                ->addData(['used_in_forms' => [
                'adminhtml_customer',
                'customer_account_create',
                'customer_account_edit'
        ]]);
        $attribute->save();
        $customerSetup->addAttribute('customer', 'fedral_tax_id', [
            'type' => 'varchar',
            'label' => 'Fedral Tax Id',
            'input' => 'text',
            'source' => '',
            'required' => false,
            'visible' => true,
            'position' => 473,
            'system' => false,
            'backend' => ''
        ]);
        $attribute = $customerSetup->getEavConfig()->getAttribute('customer', 'fedral_tax_id')
                ->addData(['used_in_forms' => [
                'adminhtml_customer',
                'customer_account_create',
                'customer_account_edit'
        ]]);
        $attribute->save();
        $customerSetup->addAttribute('customer', 'trade_status', [
            'type' => 'int',
            'label' => 'Trade Status',
            'input' => 'select',
            'source' => 'Ziffity\TradeAccount\Model\Customer\Attribute\Source\TradeStatus',
            'required' => false,
            'visible' => true,
            'position' => 483,
            'system' => false,
            'default' => 0,
            'backend' => ''
        ]);
        $attribute = $customerSetup->getEavConfig()->getAttribute('customer', 'trade_status')
                ->addData(['used_in_forms' => [
                'adminhtml_customer',
                'customer_account_create',
                'customer_account_edit'
        ]]);
        $attribute->save();
    }

}
