<?php

namespace Commerceshop\Subtotalvalidation\Model;

class Quote extends \Magento\Quote\Model\Quote
{

    public function ValidateMinimumAmount($multishipping = false) {
        $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
        $customer = $objectManager->create('\Magento\Customer\Model\Session');
    	if(!$customer->isLoggedIn()){
    		return parent::ValidateMinimumAmount($multishipping = false);
    	}
    	else{
    	$emailId = $customer->getCustomer()->getEmail();
        $order =  $objectManager->create('\Magento\Sales\Model\OrderFactory')->create()->getCollection()
        ->addAttributeToSelect('customer_email')
        ->addFieldToFilter('customer_email',array('eq'=>$emailId))->getFirstItem();
	        if($order->getCustomerEmail())
	            return true;
	    	else{
	    		return parent::ValidateMinimumAmount($multishipping = false);
	    	}

    	}	
	}
}
