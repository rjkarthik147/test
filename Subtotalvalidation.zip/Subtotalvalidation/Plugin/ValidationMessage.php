<?php
     
    namespace Commerceshop\Subtotalvalidation\Plugin;
 
    class ValidationMessage
    {
        private $customerUrl;
        private $customer;

		public function __construct(
        \Magento\Customer\Model\Url $customerUrl,
        \Magento\Customer\Model\Session $customer
    ) {
        $this->customersession = $customer;  
        $this->_customerUrl = $customerUrl;
    }
       
       public function afterGetMessage(\Magento\Quote\Model\Quote\Validator\MinimumOrderAmount\ValidationMessage $subject, $minimumAmount) 
        {
            if($this->customersession->isLoggedIn()){
                $message = __('%1',$minimumAmount);
            }
            else{ 
            $customer_login = "<a href='".$this->_customerUrl->getLoginUrl()."'>and Please log in if you already have an account with us</a>";
            $message = __('%1 %2',$minimumAmount,$customer_login);
            }
            return $message;
    }
}