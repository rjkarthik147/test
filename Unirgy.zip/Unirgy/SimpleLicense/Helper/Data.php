<?php

class Unirgy_SimpleLicense_Helper_Data extends Mage_Core_Helper_Abstract
{
    public function checkUpdates()
    {

    }
}