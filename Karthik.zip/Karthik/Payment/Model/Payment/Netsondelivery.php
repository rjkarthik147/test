<?php


namespace Karthik\Payment\Model\Payment;

class Netsondelivery extends \Magento\Payment\Model\Method\AbstractMethod
{

    protected $_code = "netsondelivery";
    protected $_isOffline = true;

    public function isAvailable(
        \Magento\Quote\Api\Data\CartInterface $quote = null
    ) {
        return parent::isAvailable($quote);
    }
}
