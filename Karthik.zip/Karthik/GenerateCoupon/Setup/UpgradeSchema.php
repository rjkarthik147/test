<?php
namespace Karthik\GenerateCoupon\Setup;

use Magento\Framework\Setup\UpgradeSchemaInterface;
use Magento\Framework\Setup\ModuleContextInterface;
use Magento\Framework\Setup\SchemaSetupInterface;

class UpgradeSchema implements  UpgradeSchemaInterface
{
    public function upgrade(SchemaSetupInterface $setup,ModuleContextInterface $context)
    {
        $setup->startSetup();
        $quote = 'quote';
        $orderTable = 'sales_order';

        $setup->getConnection()
        ->addColumn(
            $setup->getTable($quote),
            'automatic_generated_coupon',
            [
            'type' => \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
            'length' => 255,
            'comment' =>'Auto Generated Coupon'
            ]
            );
        //Order table
        $setup->getConnection()
        ->addColumn(
            $setup->getTable($orderTable),
            'automatic_generated_coupon',
            [
            'type' => \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
            'length' => 255,
            'comment' =>'Auto Generated Coupon'
            ]
            );

        $setup->endSetup();
    }
}