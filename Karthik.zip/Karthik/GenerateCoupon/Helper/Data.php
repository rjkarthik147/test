<?php
namespace Karthik\GenerateCoupon\Helper;

class Data extends \Magento\Framework\App\Helper\AbstractHelper
{
}
