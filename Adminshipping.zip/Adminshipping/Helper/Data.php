<?php
namespace Commerceshop\Adminshipping\Helper;


class Data extends \Magento\Framework\App\Helper\AbstractHelper {

    /**
     * @var \Magento\Framework\App\Config\ScopeConfigInterface
     */
    //protected $scopeConfig;

    /**
     * @var \Magento\Framework\App\ResourceConnection
     */
    protected $resourceConnection;

    public function __construct(
        \Magento\Framework\App\Helper\Context $context,
       // \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig,
        \Magento\Framework\App\ResourceConnection $resourceConnection
    ) {
        //$this->scopeConfig = $scopeConfig;
        $this->resourceConnection = $resourceConnection;
        parent::__construct(
            $context
        );
    }


    function getMethodNames() {
        $_methods = $this->scopeConfig->getValue('carriers/adminshipping/name', \Magento\Store\Model\ScopeInterface::SCOPE_STORE);
        return $_methods = explode(',', $_methods);
    }

    function getServiceNames() {
        $_service = $this->scopeConfig->getValue('carriers/adminshipping/cname', \Magento\Store\Model\ScopeInterface::SCOPE_STORE);
        return $_service = explode(',', $_service);
    }

    function getCustomShippingMethodDescription($quoteId) {
        $read = $this->resourceConnection->getConnection('core_read');
        $value = $read->query("SELECT method_description FROM quote_shipping_rate AS SR INNER JOIN quote_address AS SA ON (SR.address_id=SA.address_id) INNER JOIN sales_order AS SO ON (SA.quote_id=SO.quote_id) WHERE SA.address_type='shipping' AND SR.code='adminshipping_adminshipping' AND SO.quote_id='" . $quoteId . "'");
        $row = $value->fetch();
        return $row['method_description'];
    }

    function isEnabled() {
        return $this->scopeConfig->getValue('carriers/customshipprice/active', \Magento\Store\Model\ScopeInterface::SCOPE_STORE);
    }

}
