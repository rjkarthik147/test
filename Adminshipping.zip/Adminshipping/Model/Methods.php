<?php
namespace Commerceshop\Adminshipping\Model;


class Methods {

    public function toOptionArray() {
        return array(
            array('value' => 'Fedex', 'label' => 'Fedex'),
            array('value' => 'UPS', 'label' => 'UPS'),
            array('value' => 'DHL', 'label' => 'DHL')
        );
    }

}
