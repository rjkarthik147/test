<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
namespace Commerceshop\Adminshipping\Model\AdminOrder;
/**
 * Description of Create
 *
 * @author innoppl
 */
class Create extends \Magento\Sales\Model\AdminOrder\Create {

 
    /**
     * Parse data retrieved from request
     *
     * @param   array $data
     * @return  \Magento\Sales\Model\AdminOrder\Create
     */
    public function importPostData($data) {
        //echo"<pre>";print_r($data);die();       
        if (is_array($data)) {
            $this->addData($data);
        } else {
            return $this;
        }

        if (isset($data['account'])) {
            $this->setAccountData($data['account']);
        }

        if (isset($data['comment'])) {
            $this->getQuote()->addData($data['comment']);
            if (empty($data['comment']['customer_note_notify'])) {
                $this->getQuote()->setCustomerNoteNotify(false);
            } else {
                $this->getQuote()->setCustomerNoteNotify(true);
            }
        }

        if (isset($data['billing_address'])) {
            $this->setBillingAddress($data['billing_address']);
        }

        if (isset($data['shipping_address'])) {
            $this->setShippingAddress($data['shipping_address']);
        }

        if (isset($data['shipping_method'])) {
            $this->setShippingMethod($data['shipping_method']);
        }

        if (isset($data['payment_method'])) {
            $this->setPaymentMethod($data['payment_method']);
        }

        $reinit_rates = false;

        if (isset($data['shipping_amount'])) {
            $shippingPrice = $this->_parseCustomPrice($data['shipping_amount']);
            //$this->getQuote()->getShippingAddress()->setShippingAmount($shippingPrice);
            $this->getSession()->setCustomshippriceAmount($shippingPrice);
            $reinit_rates = true;
        }

        if (isset($data['base_shipping_amount'])) {
            $baseShippingPrice = $this->_parseCustomPrice($data['base_shipping_amount']);
            //$this->getQuote()->getShippingAddress()->setBaseShippingAmount($baseShippingPrice, true);
            $this->getSession()->setCustomshippriceBaseAmount($baseShippingPrice);
            $reinit_rates = true;
        }

        if (isset($data['shipping_description'])) {
            //$this->getQuote()->getShippingAddress()->setShippingDescription($data['shipping_description']);
            $this->getSession()->setCustomshippriceDescription($data['shipping_description']);
            $reinit_rates = true;
        }

        if (isset($data['custom_shipping_account'])) {
            $this->getSession()->setCustomShippingAccount($data['custom_shipping_account']);
            $reinit_rates = true;
        }

        if (isset($data['custom_shipping_priority'])) {
            $this->getSession()->setCustomShippingPriority($data['custom_shipping_priority']);
            $reinit_rates = true;
        }

        // if (isset($data['custom_shipping_bZip'])) {
        //     $this->getSession()->setCustomShippingBzip($data['custom_shipping_bZip']);
        //     $reinit_rates = true;
        // }

        if (isset($data['custom-shipping-custom_title'])) {
            $this->getSession()->setCustomShippingCustomTitle($data['custom-shipping-custom_title']);
            $reinit_rates = true;
        }
        
        if (isset($data['coupon']['code'])) {
            $this->applyCoupon($data['coupon']['code']);
            $reinit_rates = true;
        }

        if ($reinit_rates) {
            $this->collectShippingRates();
            $this->getQuote()->getShippingAddress()->setCollectShippingRates(true);
            $this->collectRates();
            $this->getQuote()->collectTotals();
        }

        return $this;
    }


}
