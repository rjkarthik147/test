<?php
namespace Commerceshop\Adminshipping\Model;


class Carriers {

    public function toOptionArray() {
        return array(
            array('value' => 'Ground', 'label' => 'Ground'),
            array('value' => '3 Day Select', 'label' => '3 Day Select'),
            array('value' => '2nd Day Air', 'label' => '2nd Day Air'),
            array('value' => 'Next Day Air Saver', 'label' => 'Next Day Air Saver'),
            array('value' => 'Next Day Air', 'label' => 'Next Day Air'),
            array('value' => 'Next Day Air Early AM', 'label' => 'Next Day Air Early AM')
        );
    }

}
