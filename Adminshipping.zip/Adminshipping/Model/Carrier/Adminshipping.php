<?php


namespace Commerceshop\Adminshipping\Model\Carrier;

use Magento\Quote\Model\Quote\Address\RateRequest;
use Magento\Shipping\Model\Rate\Result;
use Magento\Checkout\Model\Session as CheckoutSession;

class Adminshipping extends \Magento\Shipping\Model\Carrier\AbstractCarrier implements
    \Magento\Shipping\Model\Carrier\CarrierInterface
{

    protected $_code = 'adminshipping';

    protected $_isFixed = false;

    protected $_rateResultFactory;

    protected $_rateMethodFactory;
    
    protected $generic;
    
    protected $_checkoutSession;

    /**
     * Constructor
     *
     * @param \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig
     * @param \Magento\Quote\Model\Quote\Address\RateResult\ErrorFactory $rateErrorFactory
     * @param \Psr\Log\LoggerInterface $logger
     * @param \Magento\Shipping\Model\Rate\ResultFactory $rateResultFactory
     * @param \Magento\Quote\Model\Quote\Address\RateResult\MethodFactory $rateMethodFactory
     * @param array $data
     */
    public function __construct(
        \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig,
        \Magento\Quote\Model\Quote\Address\RateResult\ErrorFactory $rateErrorFactory,
        \Psr\Log\LoggerInterface $logger,
             \Magento\Backend\Model\Session\Quote $generic,
        \Magento\Shipping\Model\Rate\ResultFactory $rateResultFactory,
        CheckoutSession $checkoutSession,
        \Magento\Quote\Model\Quote\Address\RateResult\MethodFactory $rateMethodFactory,

        array $data = []
    ) {
        $this->generic = $generic;
        $this->_rateResultFactory = $rateResultFactory;
        $this->_rateMethodFactory = $rateMethodFactory;
        $this->_checkoutSession = $checkoutSession;
        parent::__construct($scopeConfig, $rateErrorFactory, $logger, $data);
    }


    public function loggg($msg) {       
    $writer = new \Zend\Log\Writer\Stream(BP . '/var/log/shipping.log');       
    $logger = new \Zend\Log\Logger();        
    $logger -> addWriter($writer);       
    $logger -> info(print_r($msg, true));        
    }
    /**
     * {@inheritdoc}
     */
    public function collectRates(RateRequest $request)
    {
        
        if (!$this->getConfigFlag('active')) {
            return false;
        }

        $shippingPrice = $this->getConfigData('price');

        $result = $this->_rateResultFactory->create();

        
        $shippingPrice = $this->generic->getCustomshippriceAmount();
        $baseShippingPrice = $this->generic->getCustomshippriceBaseAmount();
        $description = $this->generic->getCustomshippriceDescription();

        $shippingPrice = $this->getFinalPriceWithHandlingFee($shippingPrice);

        $customShippingAc = $this->generic->getCustomShippingAccount();
        $customShippingPriority = $this->generic->getCustomShippingPriority();
        $customShippingBzip = $this->generic->getCustomShippingBzip();

        $shippingMethodDesc = serialize(array('custom_shipping_ac' => $customShippingAc, 'custom_shipping_priority' => $customShippingPriority, 'custom_shipping_b_zip' => $customShippingBzip));
       
         if($this->_checkoutSession->getCustomShippingTitle() && $this->_checkoutSession->getCustomShippingAmount())
         {
            $description =  $this->_checkoutSession->getCustomShippingTitle();
            $shippingPrice = $this->_checkoutSession->getCustomShippingAmount();
            $this->loggg($description);
            $this->loggg($shippingPrice);
        }
        
          if ($shippingPrice !== false) {
            $method = $this->_rateMethodFactory->create();

            $method->setCarrier($this->_code);
            $method->setCarrierTitle('Ship On My Account');

            $method->setMethod($this->_code);
            //$method->setMethodTitle($this->getConfigData('name'));
            //$method->setMethodTitle((strlen($description) > 0) ? $description : $this->getConfigData('name'));
            $method->setMethodTitle((strlen($description) > 0) ? $description : 'Ship On My Account');

            if ($request->getFreeShipping() === true || $request->getPackageQty() == $this->getFreeBoxes()) {
                $shippingPrice = '0.00';
            }

            $method->setPrice($shippingPrice);
            $method->setCost($shippingPrice);
            $method->setMethodDescription($shippingMethodDesc);

            $result->append($method);
        }
    

        return $result;
    }

    /**
     * getAllowedMethods
     *
     * @param array
     */
    public function getAllowedMethods()
    {
        return ['adminshipping' => $this->getConfigData('name')];
    }
}
