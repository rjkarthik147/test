<?php

namespace Commerceshop\Adminshipping\Plugin;
use \Magento\Checkout\Model\Session as CheckoutSession;

class Customshipping
{
    protected $_checkoutSession;

    public function __construct(
         CheckoutSession $checkoutSession
    ) {
        $this->_checkoutSession = $checkoutSession;
    }

    public function beforeSaveAddressInformation(
        \Magento\Checkout\Model\ShippingInformationManagement $subject,
        $cartId,
        \Magento\Checkout\Api\Data\ShippingInformationInterface $addressInformation
    ) {
         $extAttributes = $addressInformation->getExtensionAttributes();
         if(!empty($extAttributes)){
         $selectedShippingtitle = $extAttributes->getCustomShippingTitle();
         $selectedShippingamount = $extAttributes->getCustomShippingAmount();
         $this->_checkoutSession->setCustomShippingTitle($selectedShippingtitle);
         $this->_checkoutSession->setCustomShippingAmount($selectedShippingamount);
        	 }
	}
}
