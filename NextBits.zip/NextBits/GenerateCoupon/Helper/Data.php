<?php
namespace NextBits\GenerateCoupon\Helper;

class Data extends \Magento\Framework\App\Helper\AbstractHelper
{
        parent::__construct(
            $context
        );

}
